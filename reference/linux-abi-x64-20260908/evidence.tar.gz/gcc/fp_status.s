	.file	"ffi_fp_status.c"
	.text
	.p2align 4
	.globl	ffi_fp_divide
	.type	ffi_fp_divide, @function
ffi_fp_divide:
.LFB23:
	.cfi_startproc
	endbr64
	movsd	%xmm0, -16(%rsp)
	movsd	%xmm1, -8(%rsp)
	movsd	-16(%rsp), %xmm0
	movsd	-8(%rsp), %xmm1
	divsd	%xmm1, %xmm0
	ret
	.cfi_endproc
.LFE23:
	.size	ffi_fp_divide, .-ffi_fp_divide
	.ident	"GCC: (Ubuntu 15.2.0-16ubuntu1) 15.2.0"
	.section	.note.GNU-stack,"",@progbits
	.section	.note.gnu.property,"a"
	.align 8
	.long	1f - 0f
	.long	4f - 1f
	.long	5
0:
	.string	"GNU"
1:
	.align 8
	.long	0xc0000002
	.long	3f - 2f
2:
	.long	0x3
3:
	.align 8
4:
