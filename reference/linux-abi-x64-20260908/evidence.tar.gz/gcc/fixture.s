	.file	"ffi_test.c"
	.text
	.p2align 4
	.globl	ffi_test_0
	.type	ffi_test_0, @function
ffi_test_0:
.LFB15:
	.cfi_startproc
	endbr64
	ret
	.cfi_endproc
.LFE15:
	.size	ffi_test_0, .-ffi_test_0
	.p2align 4
	.globl	ffi_test_1
	.type	ffi_test_1, @function
ffi_test_1:
.LFB16:
	.cfi_startproc
	endbr64
	movl	$3, %eax
	ret
	.cfi_endproc
.LFE16:
	.size	ffi_test_1, .-ffi_test_1
	.p2align 4
	.globl	ffi_test_2
	.type	ffi_test_2, @function
ffi_test_2:
.LFB17:
	.cfi_startproc
	endbr64
	leal	(%rdi,%rsi), %eax
	ret
	.cfi_endproc
.LFE17:
	.size	ffi_test_2, .-ffi_test_2
	.p2align 4
	.globl	ffi_test_3
	.type	ffi_test_3, @function
ffi_test_3:
.LFB18:
	.cfi_startproc
	endbr64
	imull	%ecx, %edx
	addl	%esi, %edi
	leal	(%rdi,%rdx), %eax
	ret
	.cfi_endproc
.LFE18:
	.size	ffi_test_3, .-ffi_test_3
	.p2align 4
	.globl	ffi_test_4
	.type	ffi_test_4, @function
ffi_test_4:
.LFB19:
	.cfi_startproc
	endbr64
	movss	.LC0(%rip), %xmm0
	ret
	.cfi_endproc
.LFE19:
	.size	ffi_test_4, .-ffi_test_4
	.p2align 4
	.globl	ffi_test_5
	.type	ffi_test_5, @function
ffi_test_5:
.LFB20:
	.cfi_startproc
	endbr64
	movsd	.LC1(%rip), %xmm0
	ret
	.cfi_endproc
.LFE20:
	.size	ffi_test_5, .-ffi_test_5
	.p2align 4
	.globl	ffi_test_6
	.type	ffi_test_6, @function
ffi_test_6:
.LFB21:
	.cfi_startproc
	endbr64
	mulss	%xmm1, %xmm0
	cvtss2sd	%xmm0, %xmm0
	ret
	.cfi_endproc
.LFE21:
	.size	ffi_test_6, .-ffi_test_6
	.p2align 4
	.globl	ffi_test_7
	.type	ffi_test_7, @function
ffi_test_7:
.LFB22:
	.cfi_startproc
	endbr64
	mulsd	%xmm1, %xmm0
	ret
	.cfi_endproc
.LFE22:
	.size	ffi_test_7, .-ffi_test_7
	.p2align 4
	.globl	ffi_test_8
	.type	ffi_test_8, @function
ffi_test_8:
.LFB23:
	.cfi_startproc
	endbr64
	cvtss2sd	%xmm1, %xmm1
	cvtss2sd	%xmm3, %xmm3
	mulsd	%xmm0, %xmm1
	pxor	%xmm0, %xmm0
	mulsd	%xmm2, %xmm3
	cvtsi2sdl	%edi, %xmm0
	addsd	%xmm3, %xmm1
	addsd	%xmm1, %xmm0
	ret
	.cfi_endproc
.LFE23:
	.size	ffi_test_8, .-ffi_test_8
	.p2align 4
	.globl	ffi_test_9
	.type	ffi_test_9, @function
ffi_test_9:
.LFB24:
	.cfi_startproc
	endbr64
	addl	%esi, %edi
	addl	%edx, %edi
	addl	%ecx, %edi
	addl	%r8d, %edi
	leal	(%rdi,%r9), %eax
	addl	8(%rsp), %eax
	ret
	.cfi_endproc
.LFE24:
	.size	ffi_test_9, .-ffi_test_9
	.p2align 4
	.globl	ffi_test_10
	.type	ffi_test_10, @function
ffi_test_10:
.LFB25:
	.cfi_startproc
	endbr64
	movapd	%xmm0, %xmm2
	subl	%esi, %edi
	pxor	%xmm0, %xmm0
	cvtss2sd	%xmm1, %xmm1
	cvtsi2sdl	%edi, %xmm0
	subsd	%xmm2, %xmm0
	pxor	%xmm2, %xmm2
	cvtsi2sdl	%edx, %xmm2
	subsd	%xmm2, %xmm0
	subsd	%xmm1, %xmm0
	pxor	%xmm1, %xmm1
	cvtsi2sdl	%ecx, %xmm1
	subsd	%xmm1, %xmm0
	pxor	%xmm1, %xmm1
	cvtsi2sdl	%r8d, %xmm1
	subsd	%xmm1, %xmm0
	pxor	%xmm1, %xmm1
	cvtsi2sdl	%r9d, %xmm1
	subsd	%xmm1, %xmm0
	cvttsd2sil	%xmm0, %eax
	ret
	.cfi_endproc
.LFE25:
	.size	ffi_test_10, .-ffi_test_10
	.p2align 4
	.globl	ffi_test_11
	.type	ffi_test_11, @function
ffi_test_11:
.LFB26:
	.cfi_startproc
	endbr64
	imull	%esi, %edi
	sarq	$32, %rsi
	imull	%esi, %edx
	leal	(%rdi,%rdx), %eax
	ret
	.cfi_endproc
.LFE26:
	.size	ffi_test_11, .-ffi_test_11
	.p2align 4
	.globl	ffi_test_12
	.type	ffi_test_12, @function
ffi_test_12:
.LFB27:
	.cfi_startproc
	endbr64
	addl	%esi, %edi
	pxor	%xmm2, %xmm2
	cvtsi2ssl	%edi, %xmm2
	addss	%xmm0, %xmm2
	shufps	$85, %xmm0, %xmm0
	addss	%xmm0, %xmm2
	pxor	%xmm0, %xmm0
	cvtsi2ssl	%edx, %xmm0
	addss	%xmm1, %xmm2
	shufps	$85, %xmm1, %xmm1
	addss	%xmm1, %xmm2
	addss	%xmm0, %xmm2
	pxor	%xmm0, %xmm0
	cvtsi2ssl	%ecx, %xmm0
	addss	%xmm0, %xmm2
	pxor	%xmm0, %xmm0
	cvtsi2ssl	%r8d, %xmm0
	addss	%xmm0, %xmm2
	cvttss2sil	%xmm2, %eax
	ret
	.cfi_endproc
.LFE27:
	.size	ffi_test_12, .-ffi_test_12
	.p2align 4
	.globl	ffi_test_13
	.type	ffi_test_13, @function
ffi_test_13:
.LFB28:
	.cfi_startproc
	endbr64
	addl	%esi, %edi
	addl	%edx, %edi
	addl	%ecx, %edi
	addl	%r8d, %edi
	leal	(%rdi,%r9), %eax
	addl	8(%rsp), %eax
	addl	16(%rsp), %eax
	addl	24(%rsp), %eax
	addl	32(%rsp), %eax
	addl	40(%rsp), %eax
	ret
	.cfi_endproc
.LFE28:
	.size	ffi_test_13, .-ffi_test_13
	.p2align 4
	.globl	ffi_test_14
	.type	ffi_test_14, @function
ffi_test_14:
.LFB29:
	.cfi_startproc
	endbr64
	salq	$32, %rsi
	movl	%edi, %eax
	orq	%rsi, %rax
	ret
	.cfi_endproc
.LFE29:
	.size	ffi_test_14, .-ffi_test_14
	.section	.rodata.str1.1,"aMS",@progbits,1
.LC2:
	.string	"foo"
.LC3:
	.string	"bar"
	.text
	.p2align 4
	.globl	ffi_test_15
	.type	ffi_test_15, @function
ffi_test_15:
.LFB30:
	.cfi_startproc
	endbr64
	subq	$8, %rsp
	.cfi_def_cfa_offset 16
	call	strcmp@PLT
	leaq	.LC2(%rip), %rdx
	testl	%eax, %eax
	leaq	.LC3(%rip), %rax
	cmovne	%rdx, %rax
	addq	$8, %rsp
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE30:
	.size	ffi_test_15, .-ffi_test_15
	.p2align 4
	.globl	ffi_test_16
	.type	ffi_test_16, @function
ffi_test_16:
.LFB31:
	.cfi_startproc
	endbr64
	movq	%rsi, (%rdi)
	movq	%rdi, %rax
	movq	%rdx, 8(%rdi)
	movq	%rcx, 16(%rdi)
	ret
	.cfi_endproc
.LFE31:
	.size	ffi_test_16, .-ffi_test_16
	.p2align 4
	.globl	ffi_test_large_return
	.type	ffi_test_large_return, @function
ffi_test_large_return:
.LFB32:
	.cfi_startproc
	endbr64
	addq	%rdx, %rsi
	movq	24(%rsp), %rax
	addq	%r9, %r8
	addq	16(%rsp), %rax
	addq	%rcx, %rsi
	addq	32(%rsp), %rax
	addq	8(%rsp), %r8
	movq	%rax, 16(%rdi)
	movq	%rdi, %rax
	movq	%rsi, (%rdi)
	movq	%r8, 8(%rdi)
	ret
	.cfi_endproc
.LFE32:
	.size	ffi_test_large_return, .-ffi_test_large_return
	.p2align 4
	.globl	ffi_test_large_return_callback
	.type	ffi_test_large_return_callback, @function
ffi_test_large_return_callback:
.LFB33:
	.cfi_startproc
	endbr64
	subq	$40, %rsp
	.cfi_def_cfa_offset 48
	movl	$5, %r9d
	movl	$4, %r8d
	movl	$3, %ecx
	movq	%fs:40, %rax
	movq	%rax, 24(%rsp)
	movq	%rdi, %rax
	movq	%rsp, %rdi
	pushq	$9
	.cfi_def_cfa_offset 56
	movl	$2, %edx
	pushq	$8
	.cfi_def_cfa_offset 64
	movl	$1, %esi
	pushq	$7
	.cfi_def_cfa_offset 72
	pushq	$6
	.cfi_def_cfa_offset 80
	call	*%rax
	movq	40(%rsp), %rax
	addq	32(%rsp), %rax
	addq	48(%rsp), %rax
	addq	$32, %rsp
	.cfi_def_cfa_offset 48
	movq	24(%rsp), %rdx
	subq	%fs:40, %rdx
	jne	.L26
	addq	$40, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 8
	ret
.L26:
	.cfi_restore_state
	call	__stack_chk_fail@PLT
	.cfi_endproc
.LFE33:
	.size	ffi_test_large_return_callback, .-ffi_test_large_return_callback
	.p2align 4
	.globl	ffi_test_17
	.type	ffi_test_17, @function
ffi_test_17:
.LFB34:
	.cfi_startproc
	endbr64
	movl	%edi, %eax
	ret
	.cfi_endproc
.LFE34:
	.size	ffi_test_17, .-ffi_test_17
	.p2align 4
	.globl	ffi_test_18
	.type	ffi_test_18, @function
ffi_test_18:
.LFB142:
	.cfi_startproc
	endbr64
	imull	%ecx, %edx
	addl	%esi, %edi
	leal	(%rdi,%rdx), %eax
	ret
	.cfi_endproc
.LFE142:
	.size	ffi_test_18, .-ffi_test_18
	.p2align 4
	.globl	ffi_test_19
	.type	ffi_test_19, @function
ffi_test_19:
.LFB144:
	.cfi_startproc
	endbr64
	movq	%rsi, (%rdi)
	movq	%rdi, %rax
	movq	%rdx, 8(%rdi)
	movq	%rcx, 16(%rdi)
	ret
	.cfi_endproc
.LFE144:
	.size	ffi_test_19, .-ffi_test_19
	.p2align 4
	.globl	ffi_test_20
	.type	ffi_test_20, @function
ffi_test_20:
.LFB37:
	.cfi_startproc
	endbr64
	ret
	.cfi_endproc
.LFE37:
	.size	ffi_test_20, .-ffi_test_20
	.p2align 4
	.globl	ffi_test_21
	.type	ffi_test_21, @function
ffi_test_21:
.LFB38:
	.cfi_startproc
	endbr64
	movq	%rdi, %rax
	imulq	%rsi, %rax
	ret
	.cfi_endproc
.LFE38:
	.size	ffi_test_21, .-ffi_test_21
	.p2align 4
	.globl	ffi_test_22
	.type	ffi_test_22, @function
ffi_test_22:
.LFB39:
	.cfi_startproc
	endbr64
	movq	%rsi, %rax
	movq	%rdx, %rcx
	cqto
	idivq	%rcx
	addq	%rdi, %rax
	ret
	.cfi_endproc
.LFE39:
	.size	ffi_test_22, .-ffi_test_22
	.p2align 4
	.globl	ffi_test_23
	.type	ffi_test_23, @function
ffi_test_23:
.LFB40:
	.cfi_startproc
	endbr64
	movss	(%rdi), %xmm0
	movss	4(%rdi), %xmm1
	mulss	(%rsi), %xmm0
	mulss	4(%rsi), %xmm1
	addss	%xmm1, %xmm0
	movss	8(%rdi), %xmm1
	mulss	8(%rsi), %xmm1
	addss	%xmm1, %xmm0
	ret
	.cfi_endproc
.LFE40:
	.size	ffi_test_23, .-ffi_test_23
	.p2align 4
	.globl	ffi_test_24
	.type	ffi_test_24, @function
ffi_test_24:
.LFB41:
	.cfi_startproc
	endbr64
	movl	$1, %eax
	ret
	.cfi_endproc
.LFE41:
	.size	ffi_test_24, .-ffi_test_24
	.p2align 4
	.globl	ffi_test_25
	.type	ffi_test_25, @function
ffi_test_25:
.LFB42:
	.cfi_startproc
	endbr64
	movl	$513, %eax
	ret
	.cfi_endproc
.LFE42:
	.size	ffi_test_25, .-ffi_test_25
	.p2align 4
	.globl	ffi_test_26
	.type	ffi_test_26, @function
ffi_test_26:
.LFB43:
	.cfi_startproc
	endbr64
	movl	$197121, %eax
	ret
	.cfi_endproc
.LFE43:
	.size	ffi_test_26, .-ffi_test_26
	.p2align 4
	.globl	ffi_test_27
	.type	ffi_test_27, @function
ffi_test_27:
.LFB44:
	.cfi_startproc
	endbr64
	movl	$67305985, %eax
	ret
	.cfi_endproc
.LFE44:
	.size	ffi_test_27, .-ffi_test_27
	.p2align 4
	.globl	ffi_test_28
	.type	ffi_test_28, @function
ffi_test_28:
.LFB45:
	.cfi_startproc
	endbr64
	movabsq	$21542142465, %rax
	ret
	.cfi_endproc
.LFE45:
	.size	ffi_test_28, .-ffi_test_28
	.p2align 4
	.globl	ffi_test_29
	.type	ffi_test_29, @function
ffi_test_29:
.LFB46:
	.cfi_startproc
	endbr64
	movabsq	$6618611909121, %rax
	ret
	.cfi_endproc
.LFE46:
	.size	ffi_test_29, .-ffi_test_29
	.p2align 4
	.globl	ffi_test_30
	.type	ffi_test_30, @function
ffi_test_30:
.LFB47:
	.cfi_startproc
	endbr64
	movabsq	$1976943448883713, %rax
	ret
	.cfi_endproc
.LFE47:
	.size	ffi_test_30, .-ffi_test_30
	.p2align 4
	.globl	ffi_test_31
	.type	ffi_test_31, @function
ffi_test_31:
.LFB48:
	.cfi_startproc
	endbr64
	addl	%esi, %edi
	addl	%edx, %edi
	addl	%ecx, %edi
	addl	%r8d, %edi
	leal	(%rdi,%r9), %eax
	addl	8(%rsp), %eax
	addl	16(%rsp), %eax
	addl	24(%rsp), %eax
	addl	32(%rsp), %eax
	addl	40(%rsp), %eax
	addl	48(%rsp), %eax
	addl	56(%rsp), %eax
	addl	64(%rsp), %eax
	addl	72(%rsp), %eax
	addl	80(%rsp), %eax
	addl	88(%rsp), %eax
	addl	96(%rsp), %eax
	addl	104(%rsp), %eax
	addl	112(%rsp), %eax
	addl	120(%rsp), %eax
	addl	128(%rsp), %eax
	addl	136(%rsp), %eax
	addl	144(%rsp), %eax
	addl	152(%rsp), %eax
	addl	160(%rsp), %eax
	addl	168(%rsp), %eax
	addl	176(%rsp), %eax
	addl	184(%rsp), %eax
	addl	192(%rsp), %eax
	addl	200(%rsp), %eax
	addl	208(%rsp), %eax
	addl	216(%rsp), %eax
	addl	224(%rsp), %eax
	addl	232(%rsp), %eax
	addl	240(%rsp), %eax
	addl	248(%rsp), %eax
	addl	256(%rsp), %eax
	addl	264(%rsp), %eax
	addl	272(%rsp), %eax
	addl	280(%rsp), %eax
	addl	288(%rsp), %eax
	ret
	.cfi_endproc
.LFE48:
	.size	ffi_test_31, .-ffi_test_31
	.p2align 4
	.globl	ffi_test_31_point_5
	.type	ffi_test_31_point_5, @function
ffi_test_31_point_5:
.LFB49:
	.cfi_startproc
	endbr64
	addss	%xmm1, %xmm0
	addss	%xmm2, %xmm0
	addss	%xmm3, %xmm0
	addss	%xmm4, %xmm0
	addss	%xmm5, %xmm0
	addss	%xmm6, %xmm0
	addss	%xmm7, %xmm0
	addss	8(%rsp), %xmm0
	addss	16(%rsp), %xmm0
	addss	24(%rsp), %xmm0
	addss	32(%rsp), %xmm0
	addss	40(%rsp), %xmm0
	addss	48(%rsp), %xmm0
	addss	56(%rsp), %xmm0
	addss	64(%rsp), %xmm0
	addss	72(%rsp), %xmm0
	addss	80(%rsp), %xmm0
	addss	88(%rsp), %xmm0
	addss	96(%rsp), %xmm0
	addss	104(%rsp), %xmm0
	addss	112(%rsp), %xmm0
	addss	120(%rsp), %xmm0
	addss	128(%rsp), %xmm0
	addss	136(%rsp), %xmm0
	addss	144(%rsp), %xmm0
	addss	152(%rsp), %xmm0
	addss	160(%rsp), %xmm0
	addss	168(%rsp), %xmm0
	addss	176(%rsp), %xmm0
	addss	184(%rsp), %xmm0
	addss	192(%rsp), %xmm0
	addss	200(%rsp), %xmm0
	addss	208(%rsp), %xmm0
	addss	216(%rsp), %xmm0
	addss	224(%rsp), %xmm0
	addss	232(%rsp), %xmm0
	addss	240(%rsp), %xmm0
	addss	248(%rsp), %xmm0
	addss	256(%rsp), %xmm0
	addss	264(%rsp), %xmm0
	addss	272(%rsp), %xmm0
	ret
	.cfi_endproc
.LFE49:
	.size	ffi_test_31_point_5, .-ffi_test_31_point_5
	.p2align 4
	.globl	ffi_test_32
	.type	ffi_test_32, @function
ffi_test_32:
.LFB50:
	.cfi_startproc
	endbr64
	addsd	%xmm1, %xmm0
	pxor	%xmm1, %xmm1
	cvtsi2sdl	%edi, %xmm1
	mulsd	%xmm1, %xmm0
	ret
	.cfi_endproc
.LFE50:
	.size	ffi_test_32, .-ffi_test_32
	.p2align 4
	.globl	ffi_test_33
	.type	ffi_test_33, @function
ffi_test_33:
.LFB51:
	.cfi_startproc
	endbr64
	movdqa	%xmm0, %xmm1
	shufps	$85, %xmm0, %xmm0
	addss	%xmm0, %xmm1
	pxor	%xmm0, %xmm0
	cvtsi2ssl	%edi, %xmm0
	mulss	%xmm1, %xmm0
	cvtss2sd	%xmm0, %xmm0
	ret
	.cfi_endproc
.LFE51:
	.size	ffi_test_33, .-ffi_test_33
	.p2align 4
	.globl	ffi_test_34
	.type	ffi_test_34, @function
ffi_test_34:
.LFB52:
	.cfi_startproc
	endbr64
	movq	%rdi, %rax
	pxor	%xmm0, %xmm0
	movd	%edi, %xmm1
	sarq	$32, %rax
	cvtsi2ssl	%eax, %xmm0
	addss	%xmm1, %xmm0
	pxor	%xmm1, %xmm1
	cvtsi2ssl	%esi, %xmm1
	mulss	%xmm1, %xmm0
	cvtss2sd	%xmm0, %xmm0
	ret
	.cfi_endproc
.LFE52:
	.size	ffi_test_34, .-ffi_test_34
	.p2align 4
	.globl	ffi_test_35
	.type	ffi_test_35, @function
ffi_test_35:
.LFB53:
	.cfi_startproc
	endbr64
	movq	%rdi, %rax
	pxor	%xmm0, %xmm0
	shrq	$32, %rax
	addl	%edi, %eax
	imull	%esi, %eax
	cvtsi2sdl	%eax, %xmm0
	ret
	.cfi_endproc
.LFE53:
	.size	ffi_test_35, .-ffi_test_35
	.p2align 4
	.globl	ffi_test_36
	.type	ffi_test_36, @function
ffi_test_36:
.LFB54:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE54:
	.size	ffi_test_36, .-ffi_test_36
	.p2align 4
	.globl	ffi_test_36_point_5
	.type	ffi_test_36_point_5, @function
ffi_test_36_point_5:
.LFB55:
	.cfi_startproc
	endbr64
	movl	$0, global_var(%rip)
	ret
	.cfi_endproc
.LFE55:
	.size	ffi_test_36_point_5, .-ffi_test_36_point_5
	.p2align 4
	.globl	ffi_test_37
	.type	ffi_test_37, @function
ffi_test_37:
.LFB56:
	.cfi_startproc
	endbr64
	subq	$8, %rsp
	.cfi_def_cfa_offset 16
	movq	%rdi, %rax
	movl	global_var(%rip), %edi
	leal	(%rdi,%rdi), %esi
	leal	(%rsi,%rdi), %edx
	call	*%rax
	movl	%eax, global_var(%rip)
	addq	$8, %rsp
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE56:
	.size	ffi_test_37, .-ffi_test_37
	.p2align 4
	.globl	ffi_test_38
	.type	ffi_test_38, @function
ffi_test_38:
.LFB57:
	.cfi_startproc
	endbr64
	movq	%rdi, %rax
	imulq	%rsi, %rax
	ret
	.cfi_endproc
.LFE57:
	.size	ffi_test_38, .-ffi_test_38
	.section	.rodata.str1.1
.LC7:
	.string	"vm/ffi_test.c"
.LC8:
	.string	"a == b"
	.section	.text.unlikely,"ax",@progbits
.LCOLDB9:
	.text
.LHOTB9:
	.p2align 4
	.globl	ffi_test_39
	.type	ffi_test_39, @function
ffi_test_39:
.LFB58:
	.cfi_startproc
	endbr64
	subq	$8, %rsp
	.cfi_def_cfa_offset 16
	cmpq	%rsi, %rdi
	jne	.L55
	movss	16(%rsp), %xmm0
	addss	20(%rsp), %xmm0
	addss	24(%rsp), %xmm0
	addss	28(%rsp), %xmm0
	addss	32(%rsp), %xmm0
	addss	36(%rsp), %xmm0
	addq	$8, %rsp
	.cfi_def_cfa_offset 8
	cvttss2sil	%xmm0, %eax
	ret
	.cfi_endproc
	.section	.text.unlikely
	.cfi_startproc
	.type	ffi_test_39.cold, @function
ffi_test_39.cold:
.LFSB58:
.L55:
	.cfi_def_cfa_offset 16
	leaq	__PRETTY_FUNCTION__.0(%rip), %rcx
	movl	$229, %edx
	leaq	.LC7(%rip), %rsi
	leaq	.LC8(%rip), %rdi
	call	__assert_fail@PLT
	.cfi_endproc
.LFE58:
	.text
	.size	ffi_test_39, .-ffi_test_39
	.section	.text.unlikely
	.size	ffi_test_39.cold, .-ffi_test_39.cold
.LCOLDE9:
	.text
.LHOTE9:
	.p2align 4
	.globl	ffi_test_40
	.type	ffi_test_40, @function
ffi_test_40:
.LFB59:
	.cfi_startproc
	endbr64
	ret
	.cfi_endproc
.LFE59:
	.size	ffi_test_40, .-ffi_test_40
	.p2align 4
	.globl	ffi_test_41
	.type	ffi_test_41, @function
ffi_test_41:
.LFB60:
	.cfi_startproc
	endbr64
	movl	%edi, %edi
	movl	%edi, %eax
	ret
	.cfi_endproc
.LFE60:
	.size	ffi_test_41, .-ffi_test_41
	.p2align 4
	.globl	ffi_test_42
	.type	ffi_test_42, @function
ffi_test_42:
.LFB61:
	.cfi_startproc
	endbr64
	unpcklps	%xmm1, %xmm0
	ret
	.cfi_endproc
.LFE61:
	.size	ffi_test_42, .-ffi_test_42
	.p2align 4
	.globl	ffi_test_43
	.type	ffi_test_43, @function
ffi_test_43:
.LFB62:
	.cfi_startproc
	endbr64
	salq	$32, %rdi
	movd	%xmm0, %eax
	orq	%rdi, %rax
	ret
	.cfi_endproc
.LFE62:
	.size	ffi_test_43, .-ffi_test_43
	.p2align 4
	.globl	ffi_test_44
	.type	ffi_test_44, @function
ffi_test_44:
.LFB63:
	.cfi_startproc
	endbr64
	movabsq	$4607182418800017408, %rax
	movq	%rax, %xmm0
	movabsq	$4611686018427387904, %rax
	movq	%rax, %xmm1
	ret
	.cfi_endproc
.LFE63:
	.size	ffi_test_44, .-ffi_test_44
	.p2align 4
	.globl	ffi_test_45
	.type	ffi_test_45, @function
ffi_test_45:
.LFB64:
	.cfi_startproc
	endbr64
	pxor	%xmm0, %xmm0
	movl	$0x00000000, -4(%rsp)
	cvtsi2ssl	%edi, %xmm0
	movss	%xmm0, -8(%rsp)
	movq	-8(%rsp), %xmm0
	ret
	.cfi_endproc
.LFE64:
	.size	ffi_test_45, .-ffi_test_45
	.p2align 4
	.globl	ffi_test_46
	.type	ffi_test_46, @function
ffi_test_46:
.LFB65:
	.cfi_startproc
	endbr64
	pxor	%xmm0, %xmm0
	pxor	%xmm1, %xmm1
	cvtsi2sdl	%edi, %xmm0
	ret
	.cfi_endproc
.LFE65:
	.size	ffi_test_46, .-ffi_test_46
	.p2align 4
	.globl	ffi_test_47
	.type	ffi_test_47, @function
ffi_test_47:
.LFB66:
	.cfi_startproc
	endbr64
	addsd	%xmm1, %xmm1
	addsd	%xmm2, %xmm2
	movdqa	%xmm0, %xmm3
	shufps	$85, %xmm0, %xmm0
	cvtss2sd	%xmm3, %xmm3
	cvtss2sd	%xmm0, %xmm0
	addsd	%xmm3, %xmm1
	addsd	%xmm0, %xmm2
	cvtsd2ss	%xmm1, %xmm1
	cvtsd2ss	%xmm2, %xmm2
	movss	%xmm1, -8(%rsp)
	movss	%xmm2, -4(%rsp)
	movq	-8(%rsp), %xmm0
	ret
	.cfi_endproc
.LFE66:
	.size	ffi_test_47, .-ffi_test_47
	.p2align 4
	.globl	ffi_test_48
	.type	ffi_test_48, @function
ffi_test_48:
.LFB67:
	.cfi_startproc
	endbr64
	movl	%esi, %eax
	sarl	$16, %eax
	ret
	.cfi_endproc
.LFE67:
	.size	ffi_test_48, .-ffi_test_48
	.p2align 4
	.globl	ffi_test_49
	.type	ffi_test_49, @function
ffi_test_49:
.LFB68:
	.cfi_startproc
	endbr64
	leal	1(%rdi), %eax
	ret
	.cfi_endproc
.LFE68:
	.size	ffi_test_49, .-ffi_test_49
	.p2align 4
	.globl	ffi_test_50
	.type	ffi_test_50, @function
ffi_test_50:
.LFB69:
	.cfi_startproc
	endbr64
	leal	1(%rdi,%rsi), %eax
	ret
	.cfi_endproc
.LFE69:
	.size	ffi_test_50, .-ffi_test_50
	.p2align 4
	.globl	ffi_test_51
	.type	ffi_test_51, @function
ffi_test_51:
.LFB70:
	.cfi_startproc
	endbr64
	addl	%esi, %edi
	leal	1(%rdi,%rdx), %eax
	ret
	.cfi_endproc
.LFE70:
	.size	ffi_test_51, .-ffi_test_51
	.p2align 4
	.globl	ffi_test_52
	.type	ffi_test_52, @function
ffi_test_52:
.LFB71:
	.cfi_startproc
	endbr64
	movaps	%xmm0, %xmm1
	pxor	%xmm0, %xmm0
	cvtsi2ssl	%edi, %xmm0
	addss	%xmm1, %xmm0
	pxor	%xmm1, %xmm1
	cvtsi2ssl	%esi, %xmm1
	addss	%xmm1, %xmm0
	addss	.LC12(%rip), %xmm0
	cvttss2sil	%xmm0, %eax
	ret
	.cfi_endproc
.LFE71:
	.size	ffi_test_52, .-ffi_test_52
	.p2align 4
	.globl	ffi_test_53
	.type	ffi_test_53, @function
ffi_test_53:
.LFB72:
	.cfi_startproc
	endbr64
	movaps	%xmm0, %xmm1
	pxor	%xmm0, %xmm0
	cvtsi2ssl	%edi, %xmm0
	addss	%xmm1, %xmm0
	pxor	%xmm1, %xmm1
	cvtsi2ssl	%esi, %xmm1
	addss	%xmm1, %xmm0
	pxor	%xmm1, %xmm1
	cvtsi2ssl	%edx, %xmm1
	addss	%xmm1, %xmm0
	addss	.LC12(%rip), %xmm0
	cvttss2sil	%xmm0, %eax
	ret
	.cfi_endproc
.LFE72:
	.size	ffi_test_53, .-ffi_test_53
	.p2align 4
	.globl	ffi_test_54
	.type	ffi_test_54, @function
ffi_test_54:
.LFB73:
	.cfi_startproc
	endbr64
	movq	%rdi, %rax
	shrq	$32, %rax
	addl	%edi, %eax
	leal	1(%rax,%rsi), %eax
	ret
	.cfi_endproc
.LFE73:
	.size	ffi_test_54, .-ffi_test_54
	.p2align 4
	.globl	ffi_test_55
	.type	ffi_test_55, @function
ffi_test_55:
.LFB74:
	.cfi_startproc
	endbr64
	movq	%rdi, %rax
	shrq	$32, %rax
	addl	%edi, %eax
	addl	%esi, %eax
	leal	1(%rax,%rdx), %eax
	ret
	.cfi_endproc
.LFE74:
	.size	ffi_test_55, .-ffi_test_55
	.p2align 4
	.globl	ffi_test_56
	.type	ffi_test_56, @function
ffi_test_56:
.LFB75:
	.cfi_startproc
	endbr64
	movq	%rdi, %rax
	shrq	$32, %rax
	addl	%edi, %eax
	addl	%esi, %eax
	addl	%edx, %eax
	leal	1(%rax,%rcx), %eax
	ret
	.cfi_endproc
.LFE75:
	.size	ffi_test_56, .-ffi_test_56
	.p2align 4
	.globl	ffi_test_57
	.type	ffi_test_57, @function
ffi_test_57:
.LFB76:
	.cfi_startproc
	endbr64
	movl	%edi, %edx
	leal	(%rdi,%rsi), %eax
	subl	%esi, %edx
	salq	$32, %rdx
	orq	%rdx, %rax
	ret
	.cfi_endproc
.LFE76:
	.size	ffi_test_57, .-ffi_test_57
	.p2align 4
	.globl	ffi_test_58
	.type	ffi_test_58, @function
ffi_test_58:
.LFB77:
	.cfi_startproc
	endbr64
	movl	%esi, %eax
	subl	%edx, %eax
	salq	$32, %rax
	movq	%rax, %rdx
	leal	(%rdi,%rsi), %eax
	orq	%rdx, %rax
	ret
	.cfi_endproc
.LFE77:
	.size	ffi_test_58, .-ffi_test_58
	.p2align 4
	.globl	ffi_test_59
	.type	ffi_test_59, @function
ffi_test_59:
.LFB78:
	.cfi_startproc
	endbr64
	movq	%rdi, %rax
	ret
	.cfi_endproc
.LFE78:
	.size	ffi_test_59, .-ffi_test_59
	.p2align 4
	.globl	ffi_test_60
	.type	ffi_test_60, @function
ffi_test_60:
.LFB79:
	.cfi_startproc
	endbr64
	movq	%rdi, %rax
	ret
	.cfi_endproc
.LFE79:
	.size	ffi_test_60, .-ffi_test_60
	.p2align 4
	.globl	ffi_test_61
	.type	ffi_test_61, @function
ffi_test_61:
.LFB80:
	.cfi_startproc
	endbr64
	xorl	%edx, %edx
	movl	$1, %eax
	ret
	.cfi_endproc
.LFE80:
	.size	ffi_test_61, .-ffi_test_61
	.p2align 4
	.globl	ffi_test_62
	.type	ffi_test_62, @function
ffi_test_62:
.LFB81:
	.cfi_startproc
	endbr64
	movabsq	$1311768467750121387, %rax
	ret
	.cfi_endproc
.LFE81:
	.size	ffi_test_62, .-ffi_test_62
	.p2align 4
	.globl	ffi_test_63
	.type	ffi_test_63, @function
ffi_test_63:
.LFB82:
	.cfi_startproc
	endbr64
	movabsq	$-6066929601824707635, %rax
	movabsq	$1311768467302729063, %rdx
	ret
	.cfi_endproc
.LFE82:
	.size	ffi_test_63, .-ffi_test_63
	.p2align 4
	.globl	ffi_test_64
	.type	ffi_test_64, @function
ffi_test_64:
.LFB83:
	.cfi_startproc
	endbr64
	subq	$88, %rsp
	.cfi_def_cfa_offset 96
	movq	%rsi, 40(%rsp)
	movq	%rdx, 48(%rsp)
	movq	%rcx, 56(%rsp)
	movq	%r8, 64(%rsp)
	movq	%r9, 72(%rsp)
	movq	%fs:40, %rax
	movq	%rax, 24(%rsp)
	xorl	%eax, %eax
	leaq	96(%rsp), %rax
	movl	$8, (%rsp)
	movq	%rax, 8(%rsp)
	leaq	32(%rsp), %rax
	movq	%rax, 16(%rsp)
	testl	%edi, %edi
	jle	.L89
	movq	%rax, %r9
	movl	$8, %esi
	leaq	96(%rsp), %rcx
	xorl	%eax, %eax
	xorl	%edx, %edx
	.p2align 5
	.p2align 4
	.p2align 3
.L83:
	cmpl	$47, %esi
	ja	.L85
	movl	%esi, %r8d
	addl	$1, %eax
	addl	$8, %esi
	addl	(%r9,%r8), %edx
	cmpl	%eax, %edi
	jne	.L83
.L81:
	movq	24(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L94
	movl	%edx, %eax
	addq	$88, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 8
	ret
.L85:
	.cfi_restore_state
	leal	1(%rax), %esi
	addl	(%rcx), %edx
	cmpl	%esi, %edi
	je	.L81
.L95:
	addl	$2, %eax
	addl	8(%rcx), %edx
	cmpl	%eax, %edi
	je	.L81
	leal	1(%rax), %esi
	addq	$16, %rcx
	addl	(%rcx), %edx
	cmpl	%esi, %edi
	jne	.L95
	jmp	.L81
	.p2align 4,,10
	.p2align 3
.L89:
	xorl	%edx, %edx
	jmp	.L81
.L94:
	call	__stack_chk_fail@PLT
	.cfi_endproc
.LFE83:
	.size	ffi_test_64, .-ffi_test_64
	.p2align 4
	.globl	ffi_test_65
	.type	ffi_test_65, @function
ffi_test_65:
.LFB84:
	.cfi_startproc
	endbr64
	subq	$168, %rsp
	.cfi_def_cfa_offset 176
	testb	%al, %al
	je	.L97
	movaps	%xmm0, 32(%rsp)
	movaps	%xmm1, 48(%rsp)
	movaps	%xmm2, 64(%rsp)
	movaps	%xmm3, 80(%rsp)
	movaps	%xmm4, 96(%rsp)
	movaps	%xmm5, 112(%rsp)
	movaps	%xmm6, 128(%rsp)
	movaps	%xmm7, 144(%rsp)
.L97:
	movq	%fs:40, %rax
	movq	%rax, 24(%rsp)
	xorl	%eax, %eax
	leaq	-16(%rsp), %r8
	leaq	176(%rsp), %rax
	movl	$48, 4(%rsp)
	movq	%rax, 8(%rsp)
	movq	%r8, 16(%rsp)
	testl	%edi, %edi
	jle	.L105
	movq	%rax, %rdx
	movl	$48, %ecx
	pxor	%xmm0, %xmm0
	xorl	%eax, %eax
	.p2align 5
	.p2align 4
	.p2align 3
.L99:
	cmpl	$175, %ecx
	ja	.L101
	movl	%ecx, %esi
	addl	$1, %eax
	addl	$16, %ecx
	addsd	(%r8,%rsi), %xmm0
	cmpl	%eax, %edi
	jne	.L99
.L96:
	movq	24(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L110
	addq	$168, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 8
	ret
.L101:
	.cfi_restore_state
	leal	1(%rax), %ecx
	addsd	(%rdx), %xmm0
	cmpl	%ecx, %edi
	je	.L96
.L111:
	addl	$2, %eax
	addsd	8(%rdx), %xmm0
	cmpl	%eax, %edi
	je	.L96
	leal	1(%rax), %ecx
	addq	$16, %rdx
	addsd	(%rdx), %xmm0
	cmpl	%ecx, %edi
	jne	.L111
	jmp	.L96
	.p2align 4,,10
	.p2align 3
.L105:
	pxor	%xmm0, %xmm0
	jmp	.L96
.L110:
	call	__stack_chk_fail@PLT
	.cfi_endproc
.LFE84:
	.size	ffi_test_65, .-ffi_test_65
	.p2align 4
	.globl	ffi_test_66
	.type	ffi_test_66, @function
ffi_test_66:
.LFB85:
	.cfi_startproc
	endbr64
	addq	%r8, %rcx
	addq	8(%rsp), %rcx
	addq	16(%rsp), %rcx
	addq	%rdx, %rcx
	addq	%rsi, %rcx
	leaq	(%rcx,%rdi), %rax
	ret
	.cfi_endproc
.LFE85:
	.size	ffi_test_66, .-ffi_test_66
	.p2align 4
	.globl	ffi_test_67
	.type	ffi_test_67, @function
ffi_test_67:
.LFB86:
	.cfi_startproc
	endbr64
	addq	%r8, %rcx
	addq	8(%rsp), %rcx
	addq	16(%rsp), %rcx
	leaq	(%rcx,%r9,2), %rax
	addq	%rdx, %rax
	addq	%rsi, %rax
	addq	%rdi, %rax
	ret
	.cfi_endproc
.LFE86:
	.size	ffi_test_67, .-ffi_test_67
	.p2align 4
	.globl	ffi_test_68
	.type	ffi_test_68, @function
ffi_test_68:
.LFB87:
	.cfi_startproc
	endbr64
	addq	%r8, %rcx
	addq	8(%rsp), %rcx
	addq	16(%rsp), %rcx
	addq	24(%rsp), %rcx
	addq	32(%rsp), %rcx
	addq	40(%rsp), %rcx
	addq	%rdx, %rcx
	addq	%rsi, %rcx
	leaq	(%rcx,%rdi), %rax
	ret
	.cfi_endproc
.LFE87:
	.size	ffi_test_68, .-ffi_test_68
	.p2align 4
	.globl	ffi_test_69
	.type	ffi_test_69, @function
ffi_test_69:
.LFB88:
	.cfi_startproc
	endbr64
	leaq	(%rcx,%r8), %rax
	addq	16(%rsp), %rax
	addq	24(%rsp), %rax
	cvttss2siq	8(%rsp), %rcx
	addq	32(%rsp), %rax
	addq	40(%rsp), %rax
	addq	%rcx, %rax
	addq	%rdx, %rax
	addq	%rsi, %rax
	addq	%rdi, %rax
	ret
	.cfi_endproc
.LFE88:
	.size	ffi_test_69, .-ffi_test_69
	.p2align 4
	.globl	ffi_test_70
	.type	ffi_test_70, @function
ffi_test_70:
.LFB89:
	.cfi_startproc
	endbr64
	movq	16(%rsp), %rax
	addq	8(%rsp), %rax
	addq	24(%rsp), %rax
	addq	32(%rsp), %rax
	addq	40(%rsp), %rax
	addq	48(%rsp), %rax
	addq	%rdi, %rax
	addq	%rsi, %rax
	ret
	.cfi_endproc
.LFE89:
	.size	ffi_test_70, .-ffi_test_70
	.p2align 4
	.globl	bug1021_test_1
	.type	bug1021_test_1, @function
bug1021_test_1:
.LFB90:
	.cfi_startproc
	endbr64
	imull	%esi, %esi
	movslq	%esi, %rsi
	leaq	(%rdi,%rsi), %rax
	ret
	.cfi_endproc
.LFE90:
	.size	bug1021_test_1, .-bug1021_test_1
	.p2align 4
	.globl	bug1021_test_2
	.type	bug1021_test_2, @function
bug1021_test_2:
.LFB91:
	.cfi_startproc
	endbr64
	movsbl	(%rsi), %eax
	ret
	.cfi_endproc
.LFE91:
	.size	bug1021_test_2, .-bug1021_test_2
	.p2align 4
	.globl	bug1021_test_3
	.type	bug1021_test_3, @function
bug1021_test_3:
.LFB92:
	.cfi_startproc
	endbr64
	movslq	%edi, %rax
	ret
	.cfi_endproc
.LFE92:
	.size	bug1021_test_3, .-bug1021_test_3
	.p2align 4
	.globl	ffi_test_small_floats_available
	.type	ffi_test_small_floats_available, @function
ffi_test_small_floats_available:
.LFB93:
	.cfi_startproc
	endbr64
	xorl	%eax, %eax
	ret
	.cfi_endproc
.LFE93:
	.size	ffi_test_small_floats_available, .-ffi_test_small_floats_available
	.p2align 4
	.globl	abi_narrow
	.type	abi_narrow, @function
abi_narrow:
.LFB94:
	.cfi_startproc
	endbr64
	pxor	%xmm0, %xmm0
	pxor	%xmm1, %xmm1
	movsbl	24(%rsp), %eax
	cvtsi2sdq	%rsi, %xmm0
	addsd	%xmm0, %xmm0
	cvtsi2sdq	%rdi, %xmm1
	addsd	%xmm1, %xmm0
	pxor	%xmm1, %xmm1
	cvtsi2sdq	%rdx, %xmm1
	mulsd	.LC13(%rip), %xmm1
	addsd	%xmm1, %xmm0
	pxor	%xmm1, %xmm1
	cvtsi2sdq	%rcx, %xmm1
	mulsd	.LC14(%rip), %xmm1
	addsd	%xmm1, %xmm0
	pxor	%xmm1, %xmm1
	cvtsi2sdq	%r8, %xmm1
	mulsd	.LC15(%rip), %xmm1
	addsd	%xmm1, %xmm0
	pxor	%xmm1, %xmm1
	cvtsi2sdq	%r9, %xmm1
	mulsd	.LC16(%rip), %xmm1
	addsd	%xmm1, %xmm0
	pxor	%xmm1, %xmm1
	cvtsi2sdq	8(%rsp), %xmm1
	mulsd	.LC17(%rip), %xmm1
	addsd	%xmm1, %xmm0
	pxor	%xmm1, %xmm1
	cvtsi2sdq	16(%rsp), %xmm1
	mulsd	.LC18(%rip), %xmm1
	addsd	%xmm1, %xmm0
	pxor	%xmm1, %xmm1
	cvtsi2sdl	%eax, %xmm1
	mulsd	.LC19(%rip), %xmm1
	movzbl	32(%rsp), %eax
	addsd	%xmm1, %xmm0
	pxor	%xmm1, %xmm1
	cvtsi2sdl	%eax, %xmm1
	mulsd	.LC20(%rip), %xmm1
	movswl	40(%rsp), %eax
	addsd	%xmm1, %xmm0
	pxor	%xmm1, %xmm1
	cvtsi2sdl	%eax, %xmm1
	mulsd	.LC21(%rip), %xmm1
	movzwl	48(%rsp), %eax
	addsd	%xmm1, %xmm0
	pxor	%xmm1, %xmm1
	cvtsi2sdl	%eax, %xmm1
	mulsd	.LC22(%rip), %xmm1
	movl	64(%rsp), %eax
	addsd	%xmm1, %xmm0
	pxor	%xmm1, %xmm1
	cvtsi2sdl	56(%rsp), %xmm1
	mulsd	.LC23(%rip), %xmm1
	addsd	%xmm1, %xmm0
	pxor	%xmm1, %xmm1
	cvtsi2sdq	%rax, %xmm1
	mulsd	.LC24(%rip), %xmm1
	addsd	%xmm1, %xmm0
	pxor	%xmm1, %xmm1
	cvtsi2sdq	72(%rsp), %xmm1
	mulsd	.LC25(%rip), %xmm1
	addsd	%xmm1, %xmm0
	ret
	.cfi_endproc
.LFE94:
	.size	abi_narrow, .-abi_narrow
	.p2align 4
	.globl	call_narrow
	.type	call_narrow, @function
call_narrow:
.LFB95:
	.cfi_startproc
	endbr64
	subq	$16, %rsp
	.cfi_def_cfa_offset 24
	movq	%rdi, %rax
	movl	$4, %ecx
	movl	$6, %r9d
	pushq	$-123456789
	.cfi_def_cfa_offset 32
	movl	$5, %r8d
	movl	$3, %edx
	movl	$2, %esi
	pushq	$-1294967296
	.cfi_def_cfa_offset 40
	movl	$1, %edi
	pushq	$-70000
	.cfi_def_cfa_offset 48
	pushq	$60000
	.cfi_def_cfa_offset 56
	pushq	$-300
	.cfi_def_cfa_offset 64
	pushq	$250
	.cfi_def_cfa_offset 72
	pushq	$-9
	.cfi_def_cfa_offset 80
	pushq	$8
	.cfi_def_cfa_offset 88
	pushq	$7
	.cfi_def_cfa_offset 96
	call	*%rax
	addq	$88, %rsp
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE95:
	.size	call_narrow, .-call_narrow
	.p2align 4
	.globl	abi_floats
	.type	abi_floats, @function
abi_floats:
.LFB96:
	.cfi_startproc
	endbr64
	cvtss2sd	%xmm1, %xmm1
	addsd	%xmm1, %xmm1
	cvtss2sd	%xmm2, %xmm2
	cvtss2sd	%xmm0, %xmm0
	cvtss2sd	%xmm3, %xmm3
	cvtss2sd	%xmm4, %xmm4
	cvtss2sd	%xmm5, %xmm5
	cvtss2sd	%xmm6, %xmm6
	mulsd	.LC13(%rip), %xmm2
	cvtss2sd	%xmm7, %xmm7
	addsd	%xmm0, %xmm1
	mulsd	.LC14(%rip), %xmm3
	pxor	%xmm0, %xmm0
	mulsd	.LC15(%rip), %xmm4
	cvtss2sd	8(%rsp), %xmm0
	mulsd	.LC16(%rip), %xmm5
	mulsd	.LC17(%rip), %xmm6
	addsd	%xmm2, %xmm1
	mulsd	.LC18(%rip), %xmm7
	mulsd	.LC19(%rip), %xmm0
	addsd	%xmm3, %xmm1
	addsd	%xmm4, %xmm1
	addsd	%xmm5, %xmm1
	addsd	%xmm6, %xmm1
	addsd	%xmm7, %xmm1
	addsd	%xmm0, %xmm1
	pxor	%xmm0, %xmm0
	cvtss2sd	16(%rsp), %xmm0
	mulsd	.LC20(%rip), %xmm0
	addsd	%xmm0, %xmm1
	pxor	%xmm0, %xmm0
	cvtss2sd	24(%rsp), %xmm0
	mulsd	.LC21(%rip), %xmm0
	addsd	%xmm1, %xmm0
	ret
	.cfi_endproc
.LFE96:
	.size	abi_floats, .-abi_floats
	.p2align 4
	.globl	call_floats
	.type	call_floats, @function
call_floats:
.LFB97:
	.cfi_startproc
	endbr64
	subq	$16, %rsp
	.cfi_def_cfa_offset 24
	movss	.LC29(%rip), %xmm7
	movss	.LC30(%rip), %xmm6
	pushq	$0x41300000
	.cfi_def_cfa_offset 32
	movss	.LC31(%rip), %xmm5
	pushq	$0x41200000
	.cfi_def_cfa_offset 40
	movss	.LC32(%rip), %xmm4
	pushq	$0x41100000
	.cfi_def_cfa_offset 48
	movss	.LC33(%rip), %xmm3
	movss	.LC34(%rip), %xmm2
	movss	.LC35(%rip), %xmm1
	movss	.LC12(%rip), %xmm0
	call	*%rdi
	addq	$40, %rsp
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE97:
	.size	call_floats, .-call_floats
	.p2align 4
	.globl	abi_mixed
	.type	abi_mixed, @function
abi_mixed:
.LFB98:
	.cfi_startproc
	endbr64
	movaps	%xmm0, %xmm8
	pxor	%xmm0, %xmm0
	cvtss2sd	%xmm1, %xmm1
	cvtss2sd	%xmm2, %xmm2
	cvtsi2sdq	%rsi, %xmm0
	addsd	%xmm0, %xmm0
	pxor	%xmm9, %xmm9
	cvtss2sd	%xmm8, %xmm8
	cvtsi2sdq	%rdi, %xmm9
	cvtss2sd	%xmm3, %xmm3
	cvtss2sd	%xmm4, %xmm4
	mulsd	.LC19(%rip), %xmm8
	mulsd	.LC20(%rip), %xmm1
	cvtss2sd	%xmm5, %xmm5
	cvtss2sd	%xmm6, %xmm6
	cvtss2sd	%xmm7, %xmm7
	addsd	%xmm9, %xmm0
	pxor	%xmm9, %xmm9
	movsbl	24(%rsp), %eax
	cvtsi2sdq	%rdx, %xmm9
	mulsd	.LC21(%rip), %xmm2
	mulsd	.LC13(%rip), %xmm9
	mulsd	.LC22(%rip), %xmm3
	mulsd	.LC23(%rip), %xmm4
	mulsd	.LC24(%rip), %xmm5
	mulsd	.LC25(%rip), %xmm6
	addsd	%xmm9, %xmm0
	pxor	%xmm9, %xmm9
	cvtsi2sdq	%rcx, %xmm9
	mulsd	.LC36(%rip), %xmm7
	mulsd	.LC14(%rip), %xmm9
	addsd	%xmm9, %xmm0
	pxor	%xmm9, %xmm9
	cvtsi2sdq	%r8, %xmm9
	mulsd	.LC15(%rip), %xmm9
	addsd	%xmm9, %xmm0
	pxor	%xmm9, %xmm9
	cvtsi2sdq	%r9, %xmm9
	mulsd	.LC16(%rip), %xmm9
	addsd	%xmm9, %xmm0
	pxor	%xmm9, %xmm9
	cvtsi2sdq	8(%rsp), %xmm9
	mulsd	.LC17(%rip), %xmm9
	addsd	%xmm9, %xmm0
	pxor	%xmm9, %xmm9
	cvtsi2sdq	16(%rsp), %xmm9
	mulsd	.LC18(%rip), %xmm9
	addsd	%xmm9, %xmm0
	addsd	%xmm8, %xmm0
	addsd	%xmm1, %xmm0
	pxor	%xmm1, %xmm1
	cvtsi2sdl	%eax, %xmm1
	mulsd	.LC37(%rip), %xmm1
	movswl	40(%rsp), %eax
	addsd	%xmm2, %xmm0
	addsd	%xmm3, %xmm0
	addsd	%xmm4, %xmm0
	addsd	%xmm5, %xmm0
	addsd	%xmm6, %xmm0
	addsd	%xmm7, %xmm0
	addsd	%xmm1, %xmm0
	pxor	%xmm1, %xmm1
	cvtss2sd	32(%rsp), %xmm1
	mulsd	.LC38(%rip), %xmm1
	addsd	%xmm1, %xmm0
	pxor	%xmm1, %xmm1
	cvtsi2sdl	%eax, %xmm1
	mulsd	.LC39(%rip), %xmm1
	addsd	%xmm1, %xmm0
	movsd	.LC40(%rip), %xmm1
	mulsd	48(%rsp), %xmm1
	addsd	%xmm1, %xmm0
	pxor	%xmm1, %xmm1
	cvtsi2sdl	56(%rsp), %xmm1
	mulsd	.LC41(%rip), %xmm1
	addsd	%xmm1, %xmm0
	ret
	.cfi_endproc
.LFE98:
	.size	abi_mixed, .-abi_mixed
	.p2align 4
	.globl	call_mixed
	.type	call_mixed, @function
call_mixed:
.LFB99:
	.cfi_startproc
	endbr64
	subq	$16, %rsp
	.cfi_def_cfa_offset 24
	movq	%rdi, %rax
	movl	$4, %ecx
	movabsq	$4621959855077326848, %rdx
	pushq	$-123456
	.cfi_def_cfa_offset 32
	movss	.LC29(%rip), %xmm7
	movl	$6, %r9d
	movl	$5, %r8d
	pushq	%rdx
	.cfi_def_cfa_offset 40
	movss	.LC30(%rip), %xmm6
	movl	$3, %edx
	movl	$2, %esi
	pushq	$-1000
	.cfi_def_cfa_offset 48
	movss	.LC31(%rip), %xmm5
	movl	$1, %edi
	pushq	$0x41180000
	.cfi_def_cfa_offset 56
	movss	.LC32(%rip), %xmm4
	pushq	$-9
	.cfi_def_cfa_offset 64
	movss	.LC33(%rip), %xmm3
	pushq	$8
	.cfi_def_cfa_offset 72
	movss	.LC34(%rip), %xmm2
	pushq	$7
	.cfi_def_cfa_offset 80
	movss	.LC35(%rip), %xmm1
	movss	.LC12(%rip), %xmm0
	call	*%rax
	addq	$72, %rsp
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE99:
	.size	call_mixed, .-call_mixed
	.p2align 4
	.globl	abi_var
	.type	abi_var, @function
abi_var:
.LFB100:
	.cfi_startproc
	endbr64
	subq	$216, %rsp
	.cfi_def_cfa_offset 224
	movq	%rsi, 40(%rsp)
	movq	%rdx, 48(%rsp)
	movq	%rcx, 56(%rsp)
	testb	%al, %al
	je	.L133
	movaps	%xmm1, 96(%rsp)
.L133:
	movq	%fs:40, %rax
	movq	%rax, 24(%rsp)
	xorl	%eax, %eax
	addsd	%xmm0, %xmm0
	pxor	%xmm1, %xmm1
	movl	40(%rsp), %edx
	cvtsi2sdl	%edi, %xmm1
	leaq	224(%rsp), %rax
	movl	$8, (%rsp)
	leal	(%rdx,%rdx,2), %edx
	movq	%rax, 8(%rsp)
	leaq	32(%rsp), %rax
	addsd	%xmm1, %xmm0
	pxor	%xmm1, %xmm1
	movq	%rax, 16(%rsp)
	movq	48(%rsp), %rax
	cvtsi2sdl	%edx, %xmm1
	movl	$64, 4(%rsp)
	leaq	(%rax,%rax,4), %rax
	addsd	%xmm1, %xmm0
	movsd	.LC14(%rip), %xmm1
	mulsd	96(%rsp), %xmm1
	addsd	%xmm1, %xmm0
	pxor	%xmm1, %xmm1
	cvtsi2sdq	%rax, %xmm1
	movl	56(%rsp), %eax
	addsd	%xmm1, %xmm0
	leal	(%rax,%rax,2), %eax
	pxor	%xmm1, %xmm1
	addl	%eax, %eax
	cvtsi2sdl	%eax, %xmm1
	addsd	%xmm1, %xmm0
	movq	24(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L145
	addq	$216, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 8
	ret
.L145:
	.cfi_restore_state
	call	__stack_chk_fail@PLT
	.cfi_endproc
.LFE100:
	.size	abi_var, .-abi_var
	.p2align 4
	.globl	abi_var_spill
	.type	abi_var_spill, @function
abi_var_spill:
.LFB101:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movl	%edx, %r11d
	movl	%esi, %ebp
	pushq	%rbx
	.cfi_def_cfa_offset 24
	.cfi_offset 3, -24
	movl	%edi, %ebx
	subq	$216, %rsp
	.cfi_def_cfa_offset 240
	movl	240(%rsp), %r10d
	movl	256(%rsp), %edi
	movl	264(%rsp), %esi
	testb	%al, %al
	je	.L147
	movaps	%xmm0, 80(%rsp)
.L147:
	movq	%fs:40, %rax
	movq	%rax, 24(%rsp)
	xorl	%eax, %eax
	leal	(%r11,%r11,2), %r11d
	leaq	32(%rsp), %rax
	movl	272(%rsp), %edx
	movq	%rax, 16(%rsp)
	leaq	280(%rsp), %rax
	pxor	%xmm0, %xmm0
	movsd	.LC22(%rip), %xmm1
	movq	%rax, 8(%rsp)
	leal	(%rbx,%rbp,2), %eax
	mulsd	80(%rsp), %xmm1
	addl	%r11d, %eax
	movl	$48, (%rsp)
	leal	(%rax,%rcx,4), %eax
	leal	(%r8,%r8,4), %ecx
	movl	$48, 4(%rsp)
	addl	%ecx, %eax
	leal	(%r9,%r9,2), %ecx
	leal	(%rax,%rcx,2), %eax
	leal	0(,%r10,8), %ecx
	subl	%r10d, %ecx
	addl	%ecx, %eax
	movl	248(%rsp), %ecx
	leal	(%rax,%rcx,8), %eax
	leal	(%rdi,%rdi,8), %ecx
	addl	%ecx, %eax
	leal	(%rsi,%rsi,4), %ecx
	leal	(%rax,%rcx,2), %eax
	leal	(%rdx,%rdx,4), %ecx
	leal	(%rdx,%rcx,2), %edx
	addl	%edx, %eax
	cvtsi2sdl	%eax, %xmm0
	addsd	%xmm1, %xmm0
	movq	24(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L154
	addq	$216, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 24
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
.L154:
	.cfi_restore_state
	call	__stack_chk_fail@PLT
	.cfi_endproc
.LFE101:
	.size	abi_var_spill, .-abi_var_spill
	.p2align 4
	.globl	abi_var_hfa
	.type	abi_var_hfa, @function
abi_var_hfa:
.LFB102:
	.cfi_startproc
	endbr64
	subq	$216, %rsp
	.cfi_def_cfa_offset 224
	movq	%rdi, 32(%rsp)
	testb	%al, %al
	je	.L156
	movaps	%xmm1, 96(%rsp)
.L156:
	movq	%fs:40, %rax
	movq	%rax, 24(%rsp)
	xorl	%eax, %eax
	movdqa	%xmm0, %xmm2
	leaq	224(%rsp), %rax
	movl	$0, (%rsp)
	shufps	$85, %xmm2, %xmm2
	movdqa	%xmm2, %xmm1
	movq	%rax, 8(%rsp)
	leaq	32(%rsp), %rax
	addss	%xmm2, %xmm1
	movq	%rax, 16(%rsp)
	movl	32(%rsp), %eax
	movl	$64, 4(%rsp)
	leal	(%rax,%rax,4), %eax
	addss	%xmm0, %xmm1
	movss	.LC34(%rip), %xmm0
	mulss	96(%rsp), %xmm0
	addss	%xmm0, %xmm1
	movss	.LC33(%rip), %xmm0
	mulss	100(%rsp), %xmm0
	addss	%xmm0, %xmm1
	pxor	%xmm0, %xmm0
	cvtsi2ssl	%eax, %xmm0
	addss	%xmm1, %xmm0
	cvtss2sd	%xmm0, %xmm0
	movq	24(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L163
	addq	$216, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 8
	ret
.L163:
	.cfi_restore_state
	call	__stack_chk_fail@PLT
	.cfi_endproc
.LFE102:
	.size	abi_var_hfa, .-abi_var_hfa
	.p2align 4
	.globl	abi_struct
	.type	abi_struct, @function
abi_struct:
.LFB103:
	.cfi_startproc
	endbr64
	movq	%rdx, %rax
	addq	%rsi, %rdi
	movq	32(%rsp), %rdx
	pxor	%xmm0, %xmm0
	addq	%rax, %rdi
	addq	%rcx, %rdi
	movsbq	24(%rsp), %rcx
	addq	%r8, %rdi
	leaq	(%rdi,%r9), %rax
	addq	8(%rsp), %rax
	addq	16(%rsp), %rax
	addq	%rcx, %rax
	movslq	%edx, %rcx
	sarq	$32, %rdx
	addl	%edx, %edx
	addq	%rcx, %rax
	movslq	%edx, %rdx
	addq	%rdx, %rax
	movsbq	40(%rsp), %rdx
	addq	%rdx, %rax
	cvtsi2sdq	%rax, %xmm0
	ret
	.cfi_endproc
.LFE103:
	.size	abi_struct, .-abi_struct
	.p2align 4
	.globl	call_struct
	.type	call_struct, @function
call_struct:
.LFB104:
	.cfi_startproc
	endbr64
	subq	$16, %rsp
	.cfi_def_cfa_offset 24
	movq	%rdi, %rax
	movl	$4, %ecx
	movabsq	$47244640266, %rdx
	pushq	$-12
	.cfi_def_cfa_offset 32
	movl	$6, %r9d
	movl	$5, %r8d
	movl	$2, %esi
	pushq	%rdx
	.cfi_def_cfa_offset 40
	movl	$1, %edi
	movl	$3, %edx
	pushq	$-9
	.cfi_def_cfa_offset 48
	pushq	$8
	.cfi_def_cfa_offset 56
	pushq	$7
	.cfi_def_cfa_offset 64
	call	*%rax
	addq	$56, %rsp
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE104:
	.size	call_struct, .-call_struct
	.p2align 4
	.globl	abi_hfa_boundary
	.type	abi_hfa_boundary, @function
abi_hfa_boundary:
.LFB105:
	.cfi_startproc
	endbr64
	addss	%xmm1, %xmm0
	addss	%xmm2, %xmm0
	addss	%xmm3, %xmm0
	addss	%xmm4, %xmm0
	addss	%xmm5, %xmm0
	addss	%xmm6, %xmm0
	addss	%xmm7, %xmm0
	shufps	$85, %xmm7, %xmm7
	addss	%xmm7, %xmm7
	addss	%xmm7, %xmm0
	addss	8(%rsp), %xmm0
	cvtss2sd	%xmm0, %xmm0
	ret
	.cfi_endproc
.LFE105:
	.size	abi_hfa_boundary, .-abi_hfa_boundary
	.p2align 4
	.globl	call_hfa_boundary
	.type	call_hfa_boundary, @function
call_hfa_boundary:
.LFB106:
	.cfi_startproc
	endbr64
	movabsq	$4688247213183205376, %rax
	subq	$16, %rsp
	.cfi_def_cfa_offset 24
	movss	.LC30(%rip), %xmm6
	movss	.LC31(%rip), %xmm5
	pushq	$0x41200000
	.cfi_def_cfa_offset 32
	movss	.LC32(%rip), %xmm4
	movq	%rax, %xmm7
	movss	.LC33(%rip), %xmm3
	movss	.LC34(%rip), %xmm2
	movss	.LC35(%rip), %xmm1
	movss	.LC12(%rip), %xmm0
	call	*%rdi
	addq	$24, %rsp
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE106:
	.size	call_hfa_boundary, .-call_hfa_boundary
	.p2align 4
	.globl	abi_array_hfa
	.type	abi_array_hfa, @function
abi_array_hfa:
.LFB107:
	.cfi_startproc
	endbr64
	subq	$72, %rsp
	.cfi_def_cfa_offset 80
	movq	%xmm0, %xmm0
	addps	.LC46(%rip), %xmm0
	movd	%xmm1, 24(%rsp)
	movss	.LC44(%rip), %xmm1
	addss	24(%rsp), %xmm1
	movq	%fs:40, %rax
	movq	%rax, 56(%rsp)
	xorl	%eax, %eax
	movss	%xmm1, 48(%rsp)
	movd	48(%rsp), %xmm1
	movq	56(%rsp), %rdx
	subq	%fs:40, %rdx
	jne	.L173
	addq	$72, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 8
	ret
.L173:
	.cfi_restore_state
	call	__stack_chk_fail@PLT
	.cfi_endproc
.LFE107:
	.size	abi_array_hfa, .-abi_array_hfa
	.p2align 4
	.globl	call_array_hfa
	.type	call_array_hfa, @function
call_array_hfa:
.LFB108:
	.cfi_startproc
	endbr64
	subq	$40, %rsp
	.cfi_def_cfa_offset 48
	movq	%fs:40, %rax
	movq	%rax, 24(%rsp)
	movabsq	$4611686019492741120, %rax
	movq	%rax, %xmm0
	movl	$1077936128, %eax
	movq	%rax, %xmm1
	call	*%rdi
	movq	%xmm0, 12(%rsp)
	movss	16(%rsp), %xmm0
	movd	%xmm1, 20(%rsp)
	movss	.LC34(%rip), %xmm1
	mulss	20(%rsp), %xmm1
	addss	%xmm0, %xmm0
	addss	12(%rsp), %xmm0
	addss	%xmm1, %xmm0
	movq	24(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L177
	cvtss2sd	%xmm0, %xmm0
	addq	$40, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 8
	ret
.L177:
	.cfi_restore_state
	call	__stack_chk_fail@PLT
	.cfi_endproc
.LFE108:
	.size	call_array_hfa, .-call_array_hfa
	.p2align 4
	.globl	abi_var_array
	.type	abi_var_array, @function
abi_var_array:
.LFB109:
	.cfi_startproc
	endbr64
	subq	$184, %rsp
	.cfi_def_cfa_offset 192
	testb	%al, %al
	je	.L179
	movaps	%xmm0, 48(%rsp)
	movaps	%xmm1, 64(%rsp)
	movaps	%xmm2, 80(%rsp)
.L179:
	movq	%fs:40, %rax
	movq	%rax, 40(%rsp)
	xorl	%eax, %eax
	leaq	192(%rsp), %rax
	pxor	%xmm0, %xmm0
	movq	%rsp, 32(%rsp)
	movq	%rax, 24(%rsp)
	movq	48(%rsp), %rax
	cvtsi2ssl	%edi, %xmm0
	movl	$48, 20(%rsp)
	movq	%rax, 4(%rsp)
	movss	8(%rsp), %xmm1
	addss	4(%rsp), %xmm0
	movl	64(%rsp), %eax
	addss	%xmm1, %xmm1
	movl	%eax, 12(%rsp)
	addss	%xmm1, %xmm0
	movss	.LC34(%rip), %xmm1
	mulss	12(%rsp), %xmm1
	addss	%xmm1, %xmm0
	cvtss2sd	%xmm0, %xmm0
	addsd	80(%rsp), %xmm0
	movq	40(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L186
	addq	$184, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 8
	ret
.L186:
	.cfi_restore_state
	call	__stack_chk_fail@PLT
	.cfi_endproc
.LFE109:
	.size	abi_var_array, .-abi_var_array
	.p2align 4
	.globl	abi_int_boundary
	.type	abi_int_boundary, @function
abi_int_boundary:
.LFB110:
	.cfi_startproc
	endbr64
	addq	%rsi, %rdi
	movq	24(%rsp), %rax
	pxor	%xmm0, %xmm0
	addq	%rdx, %rdi
	addq	%rcx, %rdi
	addq	%r8, %rdi
	addq	%r9, %rdi
	addq	8(%rsp), %rdi
	addq	16(%rsp), %rdi
	leaq	(%rdi,%rax,2), %rax
	addq	32(%rsp), %rax
	cvtsi2sdq	%rax, %xmm0
	ret
	.cfi_endproc
.LFE110:
	.size	abi_int_boundary, .-abi_int_boundary
	.p2align 4
	.globl	call_int_boundary
	.type	call_int_boundary, @function
call_int_boundary:
.LFB111:
	.cfi_startproc
	endbr64
	subq	$8, %rsp
	.cfi_def_cfa_offset 16
	movq	%rdi, %rax
	movl	$4, %ecx
	movl	$6, %r9d
	pushq	$10
	.cfi_def_cfa_offset 24
	movl	$5, %r8d
	movl	$3, %edx
	movl	$2, %esi
	pushq	$9
	.cfi_def_cfa_offset 32
	movl	$1, %edi
	pushq	$8
	.cfi_def_cfa_offset 40
	pushq	$7
	.cfi_def_cfa_offset 48
	call	*%rax
	addq	$40, %rsp
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE111:
	.size	call_int_boundary, .-call_int_boundary
	.p2align 4
	.globl	abi_hfa_stack
	.type	abi_hfa_stack, @function
abi_hfa_stack:
.LFB112:
	.cfi_startproc
	endbr64
	addq	%rsi, %rdi
	movaps	%xmm0, %xmm8
	pxor	%xmm0, %xmm0
	movsbl	24(%rsp), %eax
	addq	%rdx, %rdi
	addq	%rcx, %rdi
	addq	%r8, %rdi
	addq	%r9, %rdi
	addq	8(%rsp), %rdi
	addq	16(%rsp), %rdi
	cvtsi2ssq	%rdi, %xmm0
	addss	%xmm8, %xmm0
	addss	%xmm1, %xmm0
	pxor	%xmm1, %xmm1
	cvtsi2ssl	%eax, %xmm1
	addss	%xmm2, %xmm0
	addss	%xmm3, %xmm0
	addss	%xmm4, %xmm0
	addss	%xmm5, %xmm0
	addss	%xmm6, %xmm0
	addss	%xmm7, %xmm0
	addss	%xmm1, %xmm0
	movss	36(%rsp), %xmm1
	addss	32(%rsp), %xmm0
	addss	%xmm1, %xmm1
	addss	%xmm1, %xmm0
	addss	40(%rsp), %xmm0
	cvtss2sd	%xmm0, %xmm0
	ret
	.cfi_endproc
.LFE112:
	.size	abi_hfa_stack, .-abi_hfa_stack
	.p2align 4
	.globl	abi_call_int
	.type	abi_call_int, @function
abi_call_int:
.LFB113:
	.cfi_startproc
	endbr64
	movq	%rdi, %rax
	movl	%esi, %edi
	jmp	*%rax
	.cfi_endproc
.LFE113:
	.size	abi_call_int, .-abi_call_int
	.p2align 4
	.globl	abi_pointer_gc
	.type	abi_pointer_gc, @function
abi_pointer_gc:
.LFB114:
	.cfi_startproc
	endbr64
	pushq	%rbx
	.cfi_def_cfa_offset 16
	.cfi_offset 3, -16
	movl	$1515870810, %ecx
	movd	%ecx, %xmm0
	pshufd	$0, %xmm0, %xmm0
	subq	$48, %rsp
	.cfi_def_cfa_offset 64
	movq	%fs:40, %rax
	movq	%rax, 40(%rsp)
	movq	%rdi, %rax
	movaps	%xmm0, (%rsp)
	movq	%rsp, %rdi
	movaps	%xmm0, 16(%rsp)
	call	*%rax
	xorl	%eax, %eax
	cmpb	$-91, (%rsp)
	jne	.L192
	movq	%rsp, %rax
	leaq	31(%rsp), %rdx
	jmp	.L194
	.p2align 4
	.p2align 4,,10
	.p2align 3
.L201:
	addq	$1, %rax
	cmpq	%rdx, %rax
	je	.L200
.L194:
	cmpb	$90, 1(%rax)
	je	.L201
	xorl	%eax, %eax
.L192:
	movq	40(%rsp), %rdx
	subq	%fs:40, %rdx
	jne	.L202
	addq	$48, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 16
	popq	%rbx
	.cfi_def_cfa_offset 8
	ret
.L200:
	.cfi_restore_state
	movl	$1, %eax
	jmp	.L192
.L202:
	call	__stack_chk_fail@PLT
	.cfi_endproc
.LFE114:
	.size	abi_pointer_gc, .-abi_pointer_gc
	.p2align 4
	.globl	ffi_uint_callback
	.type	ffi_uint_callback, @function
ffi_uint_callback:
.LFB138:
	.cfi_startproc
	endbr64
	subq	$8, %rsp
	.cfi_def_cfa_offset 16
	movq	%rdi, %rax
	xorl	%r9d, %r9d
	xorl	%r8d, %r8d
	pushq	$-1294967296
	.cfi_def_cfa_offset 24
	xorl	%ecx, %ecx
	xorl	%edx, %edx
	xorl	%esi, %esi
	pushq	$0
	.cfi_def_cfa_offset 32
	xorl	%edi, %edi
	call	*%rax
	addq	$24, %rsp
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE138:
	.size	ffi_uint_callback, .-ffi_uint_callback
	.p2align 4
	.globl	ffi_array_struct
	.type	ffi_array_struct, @function
ffi_array_struct:
.LFB139:
	.cfi_startproc
	endbr64
	subq	$72, %rsp
	.cfi_def_cfa_offset 80
	movq	%xmm0, %xmm0
	addps	.LC46(%rip), %xmm0
	movd	%xmm1, 24(%rsp)
	movss	.LC44(%rip), %xmm1
	addss	24(%rsp), %xmm1
	movq	%fs:40, %rax
	movq	%rax, 56(%rsp)
	xorl	%eax, %eax
	movss	%xmm1, 48(%rsp)
	movd	48(%rsp), %xmm1
	movq	56(%rsp), %rdx
	subq	%fs:40, %rdx
	jne	.L208
	addq	$72, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 8
	ret
.L208:
	.cfi_restore_state
	call	__stack_chk_fail@PLT
	.cfi_endproc
.LFE139:
	.size	ffi_array_struct, .-ffi_array_struct
	.p2align 4
	.globl	ffi_fp_divide
	.type	ffi_fp_divide, @function
ffi_fp_divide:
.LFB140:
	.cfi_startproc
	endbr64
	movsd	%xmm0, -16(%rsp)
	movsd	%xmm1, -8(%rsp)
	movsd	-16(%rsp), %xmm0
	movsd	-8(%rsp), %xmm1
	divsd	%xmm1, %xmm0
	ret
	.cfi_endproc
.LFE140:
	.size	ffi_fp_divide, .-ffi_fp_divide
	.section	.rodata
	.align 8
	.type	__PRETTY_FUNCTION__.0, @object
	.size	__PRETTY_FUNCTION__.0, 12
__PRETTY_FUNCTION__.0:
	.string	"ffi_test_39"
	.local	global_var
	.comm	global_var,4,4
	.section	.rodata.cst4,"aM",@progbits,4
	.align 4
.LC0:
	.long	1069547520
	.section	.rodata.cst8,"aM",@progbits,8
	.align 8
.LC1:
	.long	0
	.long	1073217536
	.section	.rodata.cst4
	.align 4
.LC12:
	.long	1065353216
	.section	.rodata.cst8
	.align 8
.LC13:
	.long	0
	.long	1074266112
	.align 8
.LC14:
	.long	0
	.long	1074790400
	.align 8
.LC15:
	.long	0
	.long	1075052544
	.align 8
.LC16:
	.long	0
	.long	1075314688
	.align 8
.LC17:
	.long	0
	.long	1075576832
	.align 8
.LC18:
	.long	0
	.long	1075838976
	.align 8
.LC19:
	.long	0
	.long	1075970048
	.align 8
.LC20:
	.long	0
	.long	1076101120
	.align 8
.LC21:
	.long	0
	.long	1076232192
	.align 8
.LC22:
	.long	0
	.long	1076363264
	.align 8
.LC23:
	.long	0
	.long	1076494336
	.align 8
.LC24:
	.long	0
	.long	1076625408
	.align 8
.LC25:
	.long	0
	.long	1076756480
	.section	.rodata.cst4
	.align 4
.LC29:
	.long	1090519040
	.align 4
.LC30:
	.long	1088421888
	.align 4
.LC31:
	.long	1086324736
	.align 4
.LC32:
	.long	1084227584
	.align 4
.LC33:
	.long	1082130432
	.align 4
.LC34:
	.long	1077936128
	.align 4
.LC35:
	.long	1073741824
	.section	.rodata.cst8
	.align 8
.LC36:
	.long	0
	.long	1076887552
	.align 8
.LC37:
	.long	0
	.long	1076953088
	.align 8
.LC38:
	.long	0
	.long	1077018624
	.align 8
.LC39:
	.long	0
	.long	1077084160
	.align 8
.LC40:
	.long	0
	.long	1077149696
	.align 8
.LC41:
	.long	0
	.long	1077215232
	.section	.rodata.cst4
	.align 4
.LC44:
	.long	1106247680
	.section	.rodata.cst16,"aM",@progbits,16
	.align 16
.LC46:
	.long	1092616192
	.long	1101004800
	.long	0
	.long	0
	.ident	"GCC: (Ubuntu 15.2.0-16ubuntu1) 15.2.0"
	.section	.note.GNU-stack,"",@progbits
	.section	.note.gnu.property,"a"
	.align 8
	.long	1f - 0f
	.long	4f - 1f
	.long	5
0:
	.string	"GNU"
1:
	.align 8
	.long	0xc0000002
	.long	3f - 2f
2:
	.long	0x3
3:
	.align 8
4:
