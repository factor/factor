	.file	"ffi_uint_callback.c"
	.text
	.p2align 4
	.globl	ffi_uint_callback
	.type	ffi_uint_callback, @function
ffi_uint_callback:
.LFB23:
	.cfi_startproc
	endbr64
	subq	$8, %rsp
	.cfi_def_cfa_offset 16
	movq	%rdi, %rax
	xorl	%r9d, %r9d
	xorl	%r8d, %r8d
	pushq	$-1294967296
	.cfi_def_cfa_offset 24
	xorl	%ecx, %ecx
	xorl	%edx, %edx
	xorl	%esi, %esi
	pushq	$0
	.cfi_def_cfa_offset 32
	xorl	%edi, %edi
	call	*%rax
	addq	$24, %rsp
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE23:
	.size	ffi_uint_callback, .-ffi_uint_callback
	.ident	"GCC: (Ubuntu 15.2.0-16ubuntu1) 15.2.0"
	.section	.note.GNU-stack,"",@progbits
	.section	.note.gnu.property,"a"
	.align 8
	.long	1f - 0f
	.long	4f - 1f
	.long	5
0:
	.string	"GNU"
1:
	.align 8
	.long	0xc0000002
	.long	3f - 2f
2:
	.long	0x3
3:
	.align 8
4:
