	.file	"ffi_array_struct.c"
	.text
	.p2align 4
	.globl	ffi_array_struct
	.type	ffi_array_struct, @function
ffi_array_struct:
.LFB23:
	.cfi_startproc
	endbr64
	subq	$72, %rsp
	.cfi_def_cfa_offset 80
	movq	%xmm0, %xmm0
	addps	.LC2(%rip), %xmm0
	movd	%xmm1, 24(%rsp)
	movss	.LC0(%rip), %xmm1
	addss	24(%rsp), %xmm1
	movq	%fs:40, %rax
	movq	%rax, 56(%rsp)
	xorl	%eax, %eax
	movss	%xmm1, 48(%rsp)
	movd	48(%rsp), %xmm1
	movq	56(%rsp), %rdx
	subq	%fs:40, %rdx
	jne	.L5
	addq	$72, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 8
	ret
.L5:
	.cfi_restore_state
	call	__stack_chk_fail@PLT
	.cfi_endproc
.LFE23:
	.size	ffi_array_struct, .-ffi_array_struct
	.section	.rodata.cst4,"aM",@progbits,4
	.align 4
.LC0:
	.long	1106247680
	.section	.rodata.cst16,"aM",@progbits,16
	.align 16
.LC2:
	.long	1092616192
	.long	1101004800
	.long	0
	.long	0
	.ident	"GCC: (Ubuntu 15.2.0-16ubuntu1) 15.2.0"
	.section	.note.GNU-stack,"",@progbits
	.section	.note.gnu.property,"a"
	.align 8
	.long	1f - 0f
	.long	4f - 1f
	.long	5
0:
	.string	"GNU"
1:
	.align 8
	.long	0xc0000002
	.long	3f - 2f
2:
	.long	0x3
3:
	.align 8
4:
