	.file	"ffi_test.c"
	.text
	.globl	ffi_test_0                      # -- Begin function ffi_test_0
	.p2align	4
	.type	ffi_test_0,@function
ffi_test_0:                             # @ffi_test_0
	.cfi_startproc
# %bb.0:
	retq
.Lfunc_end0:
	.size	ffi_test_0, .Lfunc_end0-ffi_test_0
	.cfi_endproc
                                        # -- End function
	.globl	ffi_test_1                      # -- Begin function ffi_test_1
	.p2align	4
	.type	ffi_test_1,@function
ffi_test_1:                             # @ffi_test_1
	.cfi_startproc
# %bb.0:
	movl	$3, %eax
	retq
.Lfunc_end1:
	.size	ffi_test_1, .Lfunc_end1-ffi_test_1
	.cfi_endproc
                                        # -- End function
	.globl	ffi_test_2                      # -- Begin function ffi_test_2
	.p2align	4
	.type	ffi_test_2,@function
ffi_test_2:                             # @ffi_test_2
	.cfi_startproc
# %bb.0:
                                        # kill: def $esi killed $esi def $rsi
                                        # kill: def $edi killed $edi def $rdi
	leal	(%rdi,%rsi), %eax
	retq
.Lfunc_end2:
	.size	ffi_test_2, .Lfunc_end2-ffi_test_2
	.cfi_endproc
                                        # -- End function
	.globl	ffi_test_3                      # -- Begin function ffi_test_3
	.p2align	4
	.type	ffi_test_3,@function
ffi_test_3:                             # @ffi_test_3
	.cfi_startproc
# %bb.0:
                                        # kill: def $esi killed $esi def $rsi
                                        # kill: def $edi killed $edi def $rdi
	leal	(%rdi,%rsi), %eax
	imull	%ecx, %edx
	addl	%edx, %eax
	retq
.Lfunc_end3:
	.size	ffi_test_3, .Lfunc_end3-ffi_test_3
	.cfi_endproc
                                        # -- End function
	.section	.rodata.cst4,"aM",@progbits,4
	.p2align	2, 0x0                          # -- Begin function ffi_test_4
.LCPI4_0:
	.long	0x3fc00000                      # float 1.5
	.text
	.globl	ffi_test_4
	.p2align	4
	.type	ffi_test_4,@function
ffi_test_4:                             # @ffi_test_4
	.cfi_startproc
# %bb.0:
	movss	.LCPI4_0(%rip), %xmm0           # xmm0 = [1.5E+0,0.0E+0,0.0E+0,0.0E+0]
	retq
.Lfunc_end4:
	.size	ffi_test_4, .Lfunc_end4-ffi_test_4
	.cfi_endproc
                                        # -- End function
	.section	.rodata.cst8,"aM",@progbits,8
	.p2align	3, 0x0                          # -- Begin function ffi_test_5
.LCPI5_0:
	.quad	0x3ff8000000000000              # double 1.5
	.text
	.globl	ffi_test_5
	.p2align	4
	.type	ffi_test_5,@function
ffi_test_5:                             # @ffi_test_5
	.cfi_startproc
# %bb.0:
	movsd	.LCPI5_0(%rip), %xmm0           # xmm0 = [1.5E+0,0.0E+0]
	retq
.Lfunc_end5:
	.size	ffi_test_5, .Lfunc_end5-ffi_test_5
	.cfi_endproc
                                        # -- End function
	.globl	ffi_test_6                      # -- Begin function ffi_test_6
	.p2align	4
	.type	ffi_test_6,@function
ffi_test_6:                             # @ffi_test_6
	.cfi_startproc
# %bb.0:
	mulss	%xmm1, %xmm0
	cvtss2sd	%xmm0, %xmm0
	retq
.Lfunc_end6:
	.size	ffi_test_6, .Lfunc_end6-ffi_test_6
	.cfi_endproc
                                        # -- End function
	.globl	ffi_test_7                      # -- Begin function ffi_test_7
	.p2align	4
	.type	ffi_test_7,@function
ffi_test_7:                             # @ffi_test_7
	.cfi_startproc
# %bb.0:
	mulsd	%xmm1, %xmm0
	retq
.Lfunc_end7:
	.size	ffi_test_7, .Lfunc_end7-ffi_test_7
	.cfi_endproc
                                        # -- End function
	.globl	ffi_test_8                      # -- Begin function ffi_test_8
	.p2align	4
	.type	ffi_test_8,@function
ffi_test_8:                             # @ffi_test_8
	.cfi_startproc
# %bb.0:
	cvtss2sd	%xmm1, %xmm1
	cvtss2sd	%xmm3, %xmm3
	mulsd	%xmm2, %xmm3
	mulsd	%xmm1, %xmm0
	addsd	%xmm3, %xmm0
	xorps	%xmm1, %xmm1
	cvtsi2sd	%edi, %xmm1
	addsd	%xmm1, %xmm0
	retq
.Lfunc_end8:
	.size	ffi_test_8, .Lfunc_end8-ffi_test_8
	.cfi_endproc
                                        # -- End function
	.globl	ffi_test_9                      # -- Begin function ffi_test_9
	.p2align	4
	.type	ffi_test_9,@function
ffi_test_9:                             # @ffi_test_9
	.cfi_startproc
# %bb.0:
                                        # kill: def $r9d killed $r9d def $r9
                                        # kill: def $r8d killed $r8d def $r8
                                        # kill: def $ecx killed $ecx def $rcx
                                        # kill: def $edx killed $edx def $rdx
                                        # kill: def $esi killed $esi def $rsi
                                        # kill: def $edi killed $edi def $rdi
	addl	%edi, %esi
	leal	(%rdx,%rcx), %eax
	addl	%esi, %eax
	addl	%r8d, %eax
	addl	%r9d, %eax
	addl	8(%rsp), %eax
	retq
.Lfunc_end9:
	.size	ffi_test_9, .Lfunc_end9-ffi_test_9
	.cfi_endproc
                                        # -- End function
	.globl	ffi_test_10                     # -- Begin function ffi_test_10
	.p2align	4
	.type	ffi_test_10,@function
ffi_test_10:                            # @ffi_test_10
	.cfi_startproc
# %bb.0:
	subl	%esi, %edi
	cvtsi2sd	%edi, %xmm2
	subsd	%xmm0, %xmm2
	xorps	%xmm0, %xmm0
	cvtsi2sd	%edx, %xmm0
	subsd	%xmm0, %xmm2
	xorps	%xmm0, %xmm0
	cvtss2sd	%xmm1, %xmm0
	subsd	%xmm0, %xmm2
	xorps	%xmm0, %xmm0
	cvtsi2sd	%ecx, %xmm0
	xorps	%xmm1, %xmm1
	cvtsi2sd	%r8d, %xmm1
	subsd	%xmm0, %xmm2
	subsd	%xmm1, %xmm2
	xorps	%xmm0, %xmm0
	cvtsi2sd	%r9d, %xmm0
	subsd	%xmm0, %xmm2
	cvttsd2si	%xmm2, %eax
	retq
.Lfunc_end10:
	.size	ffi_test_10, .Lfunc_end10-ffi_test_10
	.cfi_endproc
                                        # -- End function
	.globl	ffi_test_11                     # -- Begin function ffi_test_11
	.p2align	4
	.type	ffi_test_11,@function
ffi_test_11:                            # @ffi_test_11
	.cfi_startproc
# %bb.0:
	movq	%rsi, %rax
	movq	%rsi, %rcx
	shrq	$32, %rcx
	imull	%edi, %eax
	imull	%edx, %ecx
	addl	%ecx, %eax
                                        # kill: def $eax killed $eax killed $rax
	retq
.Lfunc_end11:
	.size	ffi_test_11, .Lfunc_end11-ffi_test_11
	.cfi_endproc
                                        # -- End function
	.globl	ffi_test_12                     # -- Begin function ffi_test_12
	.p2align	4
	.type	ffi_test_12,@function
ffi_test_12:                            # @ffi_test_12
	.cfi_startproc
# %bb.0:
	addl	%esi, %edi
	cvtsi2ss	%edi, %xmm2
	addss	%xmm0, %xmm2
	shufps	$85, %xmm0, %xmm0               # xmm0 = xmm0[1,1,1,1]
	addss	%xmm2, %xmm0
	addss	%xmm1, %xmm0
	shufps	$85, %xmm1, %xmm1               # xmm1 = xmm1[1,1,1,1]
	addss	%xmm0, %xmm1
	xorps	%xmm0, %xmm0
	cvtsi2ss	%edx, %xmm0
	addss	%xmm1, %xmm0
	xorps	%xmm1, %xmm1
	cvtsi2ss	%ecx, %xmm1
	addss	%xmm0, %xmm1
	xorps	%xmm0, %xmm0
	cvtsi2ss	%r8d, %xmm0
	addss	%xmm1, %xmm0
	cvttss2si	%xmm0, %eax
	retq
.Lfunc_end12:
	.size	ffi_test_12, .Lfunc_end12-ffi_test_12
	.cfi_endproc
                                        # -- End function
	.globl	ffi_test_13                     # -- Begin function ffi_test_13
	.p2align	4
	.type	ffi_test_13,@function
ffi_test_13:                            # @ffi_test_13
	.cfi_startproc
# %bb.0:
                                        # kill: def $r9d killed $r9d def $r9
                                        # kill: def $r8d killed $r8d def $r8
                                        # kill: def $ecx killed $ecx def $rcx
                                        # kill: def $edx killed $edx def $rdx
                                        # kill: def $esi killed $esi def $rsi
                                        # kill: def $edi killed $edi def $rdi
	addl	%edi, %esi
	leal	(%rdx,%rcx), %eax
	addl	%esi, %eax
	addl	%r8d, %eax
	addl	%r9d, %eax
	addl	8(%rsp), %eax
	addl	16(%rsp), %eax
	addl	24(%rsp), %eax
	addl	32(%rsp), %eax
	addl	40(%rsp), %eax
	retq
.Lfunc_end13:
	.size	ffi_test_13, .Lfunc_end13-ffi_test_13
	.cfi_endproc
                                        # -- End function
	.globl	ffi_test_14                     # -- Begin function ffi_test_14
	.p2align	4
	.type	ffi_test_14,@function
ffi_test_14:                            # @ffi_test_14
	.cfi_startproc
# %bb.0:
                                        # kill: def $esi killed $esi def $rsi
	shlq	$32, %rsi
	movl	%edi, %eax
	orq	%rsi, %rax
	retq
.Lfunc_end14:
	.size	ffi_test_14, .Lfunc_end14-ffi_test_14
	.cfi_endproc
                                        # -- End function
	.globl	ffi_test_15                     # -- Begin function ffi_test_15
	.p2align	4
	.type	ffi_test_15,@function
ffi_test_15:                            # @ffi_test_15
	.cfi_startproc
# %bb.0:
	pushq	%rax
	.cfi_def_cfa_offset 16
	callq	strcmp@PLT
	testl	%eax, %eax
	leaq	.L.str.1(%rip), %rcx
	leaq	.L.str(%rip), %rax
	cmoveq	%rcx, %rax
	popq	%rcx
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end15:
	.size	ffi_test_15, .Lfunc_end15-ffi_test_15
	.cfi_endproc
                                        # -- End function
	.globl	ffi_test_16                     # -- Begin function ffi_test_16
	.p2align	4
	.type	ffi_test_16,@function
ffi_test_16:                            # @ffi_test_16
	.cfi_startproc
# %bb.0:
	movq	%rdi, %rax
	movq	%rsi, (%rdi)
	movq	%rdx, 8(%rdi)
	movq	%rcx, 16(%rdi)
	retq
.Lfunc_end16:
	.size	ffi_test_16, .Lfunc_end16-ffi_test_16
	.cfi_endproc
                                        # -- End function
	.globl	ffi_test_large_return           # -- Begin function ffi_test_large_return
	.p2align	4
	.type	ffi_test_large_return,@function
ffi_test_large_return:                  # @ffi_test_large_return
	.cfi_startproc
# %bb.0:
	movq	%rdi, %rax
	movq	24(%rsp), %rdi
	addq	%rdx, %rsi
	addq	%rcx, %rsi
	addq	%r9, %r8
	addq	8(%rsp), %r8
	movq	%rsi, (%rax)
	movq	%r8, 8(%rax)
	addq	16(%rsp), %rdi
	addq	32(%rsp), %rdi
	movq	%rdi, 16(%rax)
	retq
.Lfunc_end17:
	.size	ffi_test_large_return, .Lfunc_end17-ffi_test_large_return
	.cfi_endproc
                                        # -- End function
	.globl	ffi_test_large_return_callback  # -- Begin function ffi_test_large_return_callback
	.p2align	4
	.type	ffi_test_large_return_callback,@function
ffi_test_large_return_callback:         # @ffi_test_large_return_callback
	.cfi_startproc
# %bb.0:
	subq	$24, %rsp
	.cfi_def_cfa_offset 32
	movq	%rdi, %rax
	movq	%rsp, %rdi
	movl	$1, %esi
	movl	$2, %edx
	movl	$3, %ecx
	movl	$4, %r8d
	movl	$5, %r9d
	pushq	$9
	.cfi_adjust_cfa_offset 8
	pushq	$8
	.cfi_adjust_cfa_offset 8
	pushq	$7
	.cfi_adjust_cfa_offset 8
	pushq	$6
	.cfi_adjust_cfa_offset 8
	callq	*%rax
	addq	$32, %rsp
	.cfi_adjust_cfa_offset -32
	movq	8(%rsp), %rax
	addq	(%rsp), %rax
	addq	16(%rsp), %rax
	addq	$24, %rsp
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end18:
	.size	ffi_test_large_return_callback, .Lfunc_end18-ffi_test_large_return_callback
	.cfi_endproc
                                        # -- End function
	.globl	ffi_test_17                     # -- Begin function ffi_test_17
	.p2align	4
	.type	ffi_test_17,@function
ffi_test_17:                            # @ffi_test_17
	.cfi_startproc
# %bb.0:
	movl	%edi, %eax
	retq
.Lfunc_end19:
	.size	ffi_test_17, .Lfunc_end19-ffi_test_17
	.cfi_endproc
                                        # -- End function
	.globl	ffi_test_18                     # -- Begin function ffi_test_18
	.p2align	4
	.type	ffi_test_18,@function
ffi_test_18:                            # @ffi_test_18
	.cfi_startproc
# %bb.0:
                                        # kill: def $esi killed $esi def $rsi
                                        # kill: def $edi killed $edi def $rdi
	leal	(%rdi,%rsi), %eax
	imull	%ecx, %edx
	addl	%edx, %eax
	retq
.Lfunc_end20:
	.size	ffi_test_18, .Lfunc_end20-ffi_test_18
	.cfi_endproc
                                        # -- End function
	.globl	ffi_test_19                     # -- Begin function ffi_test_19
	.p2align	4
	.type	ffi_test_19,@function
ffi_test_19:                            # @ffi_test_19
	.cfi_startproc
# %bb.0:
	movq	%rdi, %rax
	movq	%rsi, (%rdi)
	movq	%rdx, 8(%rdi)
	movq	%rcx, 16(%rdi)
	retq
.Lfunc_end21:
	.size	ffi_test_19, .Lfunc_end21-ffi_test_19
	.cfi_endproc
                                        # -- End function
	.globl	ffi_test_20                     # -- Begin function ffi_test_20
	.p2align	4
	.type	ffi_test_20,@function
ffi_test_20:                            # @ffi_test_20
	.cfi_startproc
# %bb.0:
	retq
.Lfunc_end22:
	.size	ffi_test_20, .Lfunc_end22-ffi_test_20
	.cfi_endproc
                                        # -- End function
	.globl	ffi_test_21                     # -- Begin function ffi_test_21
	.p2align	4
	.type	ffi_test_21,@function
ffi_test_21:                            # @ffi_test_21
	.cfi_startproc
# %bb.0:
	movq	%rdi, %rax
	imulq	%rsi, %rax
	retq
.Lfunc_end23:
	.size	ffi_test_21, .Lfunc_end23-ffi_test_21
	.cfi_endproc
                                        # -- End function
	.globl	ffi_test_22                     # -- Begin function ffi_test_22
	.p2align	4
	.type	ffi_test_22,@function
ffi_test_22:                            # @ffi_test_22
	.cfi_startproc
# %bb.0:
	movq	%rdx, %rcx
	movq	%rsi, %rax
	movq	%rsi, %rdx
	orq	%rcx, %rdx
	shrq	$32, %rdx
	je	.LBB24_1
# %bb.2:
	cqto
	idivq	%rcx
	addq	%rdi, %rax
	retq
.LBB24_1:
                                        # kill: def $eax killed $eax killed $rax
	xorl	%edx, %edx
	divl	%ecx
                                        # kill: def $eax killed $eax def $rax
	addq	%rdi, %rax
	retq
.Lfunc_end24:
	.size	ffi_test_22, .Lfunc_end24-ffi_test_22
	.cfi_endproc
                                        # -- End function
	.globl	ffi_test_23                     # -- Begin function ffi_test_23
	.p2align	4
	.type	ffi_test_23,@function
ffi_test_23:                            # @ffi_test_23
	.cfi_startproc
# %bb.0:
	movss	(%rdi), %xmm1                   # xmm1 = mem[0],zero,zero,zero
	movss	4(%rdi), %xmm0                  # xmm0 = mem[0],zero,zero,zero
	mulss	4(%rsi), %xmm0
	mulss	(%rsi), %xmm1
	addss	%xmm0, %xmm1
	movss	8(%rdi), %xmm0                  # xmm0 = mem[0],zero,zero,zero
	mulss	8(%rsi), %xmm0
	addss	%xmm1, %xmm0
	retq
.Lfunc_end25:
	.size	ffi_test_23, .Lfunc_end25-ffi_test_23
	.cfi_endproc
                                        # -- End function
	.globl	ffi_test_24                     # -- Begin function ffi_test_24
	.p2align	4
	.type	ffi_test_24,@function
ffi_test_24:                            # @ffi_test_24
	.cfi_startproc
# %bb.0:
	movb	$1, %al
	retq
.Lfunc_end26:
	.size	ffi_test_24, .Lfunc_end26-ffi_test_24
	.cfi_endproc
                                        # -- End function
	.globl	ffi_test_25                     # -- Begin function ffi_test_25
	.p2align	4
	.type	ffi_test_25,@function
ffi_test_25:                            # @ffi_test_25
	.cfi_startproc
# %bb.0:
	movw	$513, %ax                       # imm = 0x201
	retq
.Lfunc_end27:
	.size	ffi_test_25, .Lfunc_end27-ffi_test_25
	.cfi_endproc
                                        # -- End function
	.globl	ffi_test_26                     # -- Begin function ffi_test_26
	.p2align	4
	.type	ffi_test_26,@function
ffi_test_26:                            # @ffi_test_26
	.cfi_startproc
# %bb.0:
	movl	$197121, %eax                   # imm = 0x30201
	retq
.Lfunc_end28:
	.size	ffi_test_26, .Lfunc_end28-ffi_test_26
	.cfi_endproc
                                        # -- End function
	.globl	ffi_test_27                     # -- Begin function ffi_test_27
	.p2align	4
	.type	ffi_test_27,@function
ffi_test_27:                            # @ffi_test_27
	.cfi_startproc
# %bb.0:
	movl	$67305985, %eax                 # imm = 0x4030201
	retq
.Lfunc_end29:
	.size	ffi_test_27, .Lfunc_end29-ffi_test_27
	.cfi_endproc
                                        # -- End function
	.globl	ffi_test_28                     # -- Begin function ffi_test_28
	.p2align	4
	.type	ffi_test_28,@function
ffi_test_28:                            # @ffi_test_28
	.cfi_startproc
# %bb.0:
	movabsq	$21542142465, %rax              # imm = 0x504030201
	retq
.Lfunc_end30:
	.size	ffi_test_28, .Lfunc_end30-ffi_test_28
	.cfi_endproc
                                        # -- End function
	.globl	ffi_test_29                     # -- Begin function ffi_test_29
	.p2align	4
	.type	ffi_test_29,@function
ffi_test_29:                            # @ffi_test_29
	.cfi_startproc
# %bb.0:
	movabsq	$6618611909121, %rax            # imm = 0x60504030201
	retq
.Lfunc_end31:
	.size	ffi_test_29, .Lfunc_end31-ffi_test_29
	.cfi_endproc
                                        # -- End function
	.globl	ffi_test_30                     # -- Begin function ffi_test_30
	.p2align	4
	.type	ffi_test_30,@function
ffi_test_30:                            # @ffi_test_30
	.cfi_startproc
# %bb.0:
	movabsq	$1976943448883713, %rax         # imm = 0x7060504030201
	retq
.Lfunc_end32:
	.size	ffi_test_30, .Lfunc_end32-ffi_test_30
	.cfi_endproc
                                        # -- End function
	.globl	ffi_test_31                     # -- Begin function ffi_test_31
	.p2align	4
	.type	ffi_test_31,@function
ffi_test_31:                            # @ffi_test_31
	.cfi_startproc
# %bb.0:
                                        # kill: def $r9d killed $r9d def $r9
                                        # kill: def $r8d killed $r8d def $r8
                                        # kill: def $ecx killed $ecx def $rcx
                                        # kill: def $edx killed $edx def $rdx
                                        # kill: def $esi killed $esi def $rsi
                                        # kill: def $edi killed $edi def $rdi
	addl	%edi, %esi
	leal	(%rdx,%rcx), %eax
	addl	%esi, %eax
	addl	%r8d, %eax
	addl	%r9d, %eax
	addl	8(%rsp), %eax
	addl	16(%rsp), %eax
	addl	24(%rsp), %eax
	addl	32(%rsp), %eax
	addl	40(%rsp), %eax
	addl	48(%rsp), %eax
	addl	56(%rsp), %eax
	addl	64(%rsp), %eax
	addl	72(%rsp), %eax
	addl	80(%rsp), %eax
	addl	88(%rsp), %eax
	addl	96(%rsp), %eax
	addl	104(%rsp), %eax
	addl	112(%rsp), %eax
	addl	120(%rsp), %eax
	addl	128(%rsp), %eax
	addl	136(%rsp), %eax
	addl	144(%rsp), %eax
	addl	152(%rsp), %eax
	addl	160(%rsp), %eax
	addl	168(%rsp), %eax
	addl	176(%rsp), %eax
	addl	184(%rsp), %eax
	addl	192(%rsp), %eax
	addl	200(%rsp), %eax
	addl	208(%rsp), %eax
	addl	216(%rsp), %eax
	addl	224(%rsp), %eax
	addl	232(%rsp), %eax
	addl	240(%rsp), %eax
	addl	248(%rsp), %eax
	addl	256(%rsp), %eax
	addl	264(%rsp), %eax
	addl	272(%rsp), %eax
	addl	280(%rsp), %eax
	addl	288(%rsp), %eax
	retq
.Lfunc_end33:
	.size	ffi_test_31, .Lfunc_end33-ffi_test_31
	.cfi_endproc
                                        # -- End function
	.globl	ffi_test_31_point_5             # -- Begin function ffi_test_31_point_5
	.p2align	4
	.type	ffi_test_31_point_5,@function
ffi_test_31_point_5:                    # @ffi_test_31_point_5
	.cfi_startproc
# %bb.0:
	addss	%xmm1, %xmm0
	addss	%xmm2, %xmm0
	addss	%xmm3, %xmm0
	addss	%xmm4, %xmm0
	addss	%xmm5, %xmm0
	addss	%xmm6, %xmm0
	addss	%xmm7, %xmm0
	addss	8(%rsp), %xmm0
	addss	16(%rsp), %xmm0
	addss	24(%rsp), %xmm0
	addss	32(%rsp), %xmm0
	addss	40(%rsp), %xmm0
	addss	48(%rsp), %xmm0
	addss	56(%rsp), %xmm0
	addss	64(%rsp), %xmm0
	addss	72(%rsp), %xmm0
	addss	80(%rsp), %xmm0
	addss	88(%rsp), %xmm0
	addss	96(%rsp), %xmm0
	addss	104(%rsp), %xmm0
	addss	112(%rsp), %xmm0
	addss	120(%rsp), %xmm0
	addss	128(%rsp), %xmm0
	addss	136(%rsp), %xmm0
	addss	144(%rsp), %xmm0
	addss	152(%rsp), %xmm0
	addss	160(%rsp), %xmm0
	addss	168(%rsp), %xmm0
	addss	176(%rsp), %xmm0
	addss	184(%rsp), %xmm0
	addss	192(%rsp), %xmm0
	addss	200(%rsp), %xmm0
	addss	208(%rsp), %xmm0
	addss	216(%rsp), %xmm0
	addss	224(%rsp), %xmm0
	addss	232(%rsp), %xmm0
	addss	240(%rsp), %xmm0
	addss	248(%rsp), %xmm0
	addss	256(%rsp), %xmm0
	addss	264(%rsp), %xmm0
	addss	272(%rsp), %xmm0
	retq
.Lfunc_end34:
	.size	ffi_test_31_point_5, .Lfunc_end34-ffi_test_31_point_5
	.cfi_endproc
                                        # -- End function
	.globl	ffi_test_32                     # -- Begin function ffi_test_32
	.p2align	4
	.type	ffi_test_32,@function
ffi_test_32:                            # @ffi_test_32
	.cfi_startproc
# %bb.0:
	addsd	%xmm1, %xmm0
	xorps	%xmm1, %xmm1
	cvtsi2sd	%edi, %xmm1
	mulsd	%xmm1, %xmm0
	retq
.Lfunc_end35:
	.size	ffi_test_32, .Lfunc_end35-ffi_test_32
	.cfi_endproc
                                        # -- End function
	.globl	ffi_test_33                     # -- Begin function ffi_test_33
	.p2align	4
	.type	ffi_test_33,@function
ffi_test_33:                            # @ffi_test_33
	.cfi_startproc
# %bb.0:
	movaps	%xmm0, %xmm1
	shufps	$85, %xmm0, %xmm1               # xmm1 = xmm1[1,1],xmm0[1,1]
	addss	%xmm0, %xmm1
	xorps	%xmm0, %xmm0
	cvtsi2ss	%edi, %xmm0
	mulss	%xmm1, %xmm0
	cvtss2sd	%xmm0, %xmm0
	retq
.Lfunc_end36:
	.size	ffi_test_33, .Lfunc_end36-ffi_test_33
	.cfi_endproc
                                        # -- End function
	.globl	ffi_test_34                     # -- Begin function ffi_test_34
	.p2align	4
	.type	ffi_test_34,@function
ffi_test_34:                            # @ffi_test_34
	.cfi_startproc
# %bb.0:
	movd	%edi, %xmm0
	shrq	$32, %rdi
	cvtsi2ss	%edi, %xmm1
	addss	%xmm0, %xmm1
	xorps	%xmm0, %xmm0
	cvtsi2ss	%esi, %xmm0
	mulss	%xmm1, %xmm0
	cvtss2sd	%xmm0, %xmm0
	retq
.Lfunc_end37:
	.size	ffi_test_34, .Lfunc_end37-ffi_test_34
	.cfi_endproc
                                        # -- End function
	.globl	ffi_test_35                     # -- Begin function ffi_test_35
	.p2align	4
	.type	ffi_test_35,@function
ffi_test_35:                            # @ffi_test_35
	.cfi_startproc
# %bb.0:
	movq	%rdi, %rax
	shrq	$32, %rax
	addl	%edi, %eax
	imull	%esi, %eax
	cvtsi2sd	%eax, %xmm0
	retq
.Lfunc_end38:
	.size	ffi_test_35, .Lfunc_end38-ffi_test_35
	.cfi_endproc
                                        # -- End function
	.globl	ffi_test_36                     # -- Begin function ffi_test_36
	.p2align	4
	.type	ffi_test_36,@function
ffi_test_36:                            # @ffi_test_36
	.cfi_startproc
# %bb.0:
	retq
.Lfunc_end39:
	.size	ffi_test_36, .Lfunc_end39-ffi_test_36
	.cfi_endproc
                                        # -- End function
	.globl	ffi_test_36_point_5             # -- Begin function ffi_test_36_point_5
	.p2align	4
	.type	ffi_test_36_point_5,@function
ffi_test_36_point_5:                    # @ffi_test_36_point_5
	.cfi_startproc
# %bb.0:
	movl	$0, global_var(%rip)
	retq
.Lfunc_end40:
	.size	ffi_test_36_point_5, .Lfunc_end40-ffi_test_36_point_5
	.cfi_endproc
                                        # -- End function
	.globl	ffi_test_37                     # -- Begin function ffi_test_37
	.p2align	4
	.type	ffi_test_37,@function
ffi_test_37:                            # @ffi_test_37
	.cfi_startproc
# %bb.0:
	pushq	%rax
	.cfi_def_cfa_offset 16
	movq	%rdi, %rax
	movl	global_var(%rip), %edi
	leal	(%rdi,%rdi), %esi
	leal	(%rdi,%rdi,2), %edx
                                        # kill: def $edi killed $edi killed $rdi
	callq	*%rax
	movl	%eax, global_var(%rip)
	popq	%rcx
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end41:
	.size	ffi_test_37, .Lfunc_end41-ffi_test_37
	.cfi_endproc
                                        # -- End function
	.globl	ffi_test_38                     # -- Begin function ffi_test_38
	.p2align	4
	.type	ffi_test_38,@function
ffi_test_38:                            # @ffi_test_38
	.cfi_startproc
# %bb.0:
	movq	%rdi, %rax
	imulq	%rsi, %rax
	retq
.Lfunc_end42:
	.size	ffi_test_38, .Lfunc_end42-ffi_test_38
	.cfi_endproc
                                        # -- End function
	.globl	ffi_test_39                     # -- Begin function ffi_test_39
	.p2align	4
	.type	ffi_test_39,@function
ffi_test_39:                            # @ffi_test_39
	.cfi_startproc
# %bb.0:
	pushq	%rax
	.cfi_def_cfa_offset 16
	cmpq	%rsi, %rdi
	jne	.LBB43_2
# %bb.1:
	leaq	16(%rsp), %rax
	movss	(%rax), %xmm0                   # xmm0 = mem[0],zero,zero,zero
	addss	4(%rax), %xmm0
	addss	8(%rax), %xmm0
	addss	12(%rax), %xmm0
	addss	16(%rax), %xmm0
	addss	20(%rax), %xmm0
	cvttss2si	%xmm0, %eax
	popq	%rcx
	.cfi_def_cfa_offset 8
	retq
.LBB43_2:
	.cfi_def_cfa_offset 16
	leaq	.L.str.2(%rip), %rdi
	leaq	.L.str.3(%rip), %rsi
	leaq	.L__PRETTY_FUNCTION__.ffi_test_39(%rip), %rcx
	movl	$229, %edx
	callq	__assert_fail@PLT
.Lfunc_end43:
	.size	ffi_test_39, .Lfunc_end43-ffi_test_39
	.cfi_endproc
                                        # -- End function
	.globl	ffi_test_40                     # -- Begin function ffi_test_40
	.p2align	4
	.type	ffi_test_40,@function
ffi_test_40:                            # @ffi_test_40
	.cfi_startproc
# %bb.0:
	retq
.Lfunc_end44:
	.size	ffi_test_40, .Lfunc_end44-ffi_test_40
	.cfi_endproc
                                        # -- End function
	.globl	ffi_test_41                     # -- Begin function ffi_test_41
	.p2align	4
	.type	ffi_test_41,@function
ffi_test_41:                            # @ffi_test_41
	.cfi_startproc
# %bb.0:
	movl	%edi, %eax
	retq
.Lfunc_end45:
	.size	ffi_test_41, .Lfunc_end45-ffi_test_41
	.cfi_endproc
                                        # -- End function
	.globl	ffi_test_42                     # -- Begin function ffi_test_42
	.p2align	4
	.type	ffi_test_42,@function
ffi_test_42:                            # @ffi_test_42
	.cfi_startproc
# %bb.0:
	unpcklps	%xmm1, %xmm0                    # xmm0 = xmm0[0],xmm1[0],xmm0[1],xmm1[1]
	retq
.Lfunc_end46:
	.size	ffi_test_42, .Lfunc_end46-ffi_test_42
	.cfi_endproc
                                        # -- End function
	.globl	ffi_test_43                     # -- Begin function ffi_test_43
	.p2align	4
	.type	ffi_test_43,@function
ffi_test_43:                            # @ffi_test_43
	.cfi_startproc
# %bb.0:
                                        # kill: def $edi killed $edi def $rdi
	movd	%xmm0, %eax
	shlq	$32, %rdi
	orq	%rdi, %rax
	retq
.Lfunc_end47:
	.size	ffi_test_43, .Lfunc_end47-ffi_test_43
	.cfi_endproc
                                        # -- End function
	.section	.rodata.cst8,"aM",@progbits,8
	.p2align	3, 0x0                          # -- Begin function ffi_test_44
.LCPI48_0:
	.quad	0x3ff0000000000000              # double 1
.LCPI48_1:
	.quad	0x4000000000000000              # double 2
	.text
	.globl	ffi_test_44
	.p2align	4
	.type	ffi_test_44,@function
ffi_test_44:                            # @ffi_test_44
	.cfi_startproc
# %bb.0:
	movsd	.LCPI48_0(%rip), %xmm0          # xmm0 = [1.0E+0,0.0E+0]
	movsd	.LCPI48_1(%rip), %xmm1          # xmm1 = [2.0E+0,0.0E+0]
	retq
.Lfunc_end48:
	.size	ffi_test_44, .Lfunc_end48-ffi_test_44
	.cfi_endproc
                                        # -- End function
	.globl	ffi_test_45                     # -- Begin function ffi_test_45
	.p2align	4
	.type	ffi_test_45,@function
ffi_test_45:                            # @ffi_test_45
	.cfi_startproc
# %bb.0:
	cvtsi2ss	%edi, %xmm1
	xorps	%xmm0, %xmm0
	movss	%xmm1, %xmm0                    # xmm0 = xmm1[0],xmm0[1,2,3]
	retq
.Lfunc_end49:
	.size	ffi_test_45, .Lfunc_end49-ffi_test_45
	.cfi_endproc
                                        # -- End function
	.globl	ffi_test_46                     # -- Begin function ffi_test_46
	.p2align	4
	.type	ffi_test_46,@function
ffi_test_46:                            # @ffi_test_46
	.cfi_startproc
# %bb.0:
	cvtsi2sd	%edi, %xmm0
	xorps	%xmm1, %xmm1
	retq
.Lfunc_end50:
	.size	ffi_test_46, .Lfunc_end50-ffi_test_46
	.cfi_endproc
                                        # -- End function
	.globl	ffi_test_47                     # -- Begin function ffi_test_47
	.p2align	4
	.type	ffi_test_47,@function
ffi_test_47:                            # @ffi_test_47
	.cfi_startproc
# %bb.0:
	unpcklpd	%xmm2, %xmm1                    # xmm1 = xmm1[0],xmm2[0]
	addpd	%xmm1, %xmm1
	cvtps2pd	%xmm0, %xmm0
	addpd	%xmm1, %xmm0
	cvtpd2ps	%xmm0, %xmm0
	retq
.Lfunc_end51:
	.size	ffi_test_47, .Lfunc_end51-ffi_test_47
	.cfi_endproc
                                        # -- End function
	.globl	ffi_test_48                     # -- Begin function ffi_test_48
	.p2align	4
	.type	ffi_test_48,@function
ffi_test_48:                            # @ffi_test_48
	.cfi_startproc
# %bb.0:
	movq	%rsi, %rax
	shrl	$16, %eax
                                        # kill: def $ax killed $ax killed $rax
	retq
.Lfunc_end52:
	.size	ffi_test_48, .Lfunc_end52-ffi_test_48
	.cfi_endproc
                                        # -- End function
	.globl	ffi_test_49                     # -- Begin function ffi_test_49
	.p2align	4
	.type	ffi_test_49,@function
ffi_test_49:                            # @ffi_test_49
	.cfi_startproc
# %bb.0:
                                        # kill: def $edi killed $edi def $rdi
	leal	1(%rdi), %eax
	retq
.Lfunc_end53:
	.size	ffi_test_49, .Lfunc_end53-ffi_test_49
	.cfi_endproc
                                        # -- End function
	.globl	ffi_test_50                     # -- Begin function ffi_test_50
	.p2align	4
	.type	ffi_test_50,@function
ffi_test_50:                            # @ffi_test_50
	.cfi_startproc
# %bb.0:
                                        # kill: def $esi killed $esi def $rsi
                                        # kill: def $edi killed $edi def $rdi
	leal	(%rdi,%rsi), %eax
	incl	%eax
	retq
.Lfunc_end54:
	.size	ffi_test_50, .Lfunc_end54-ffi_test_50
	.cfi_endproc
                                        # -- End function
	.globl	ffi_test_51                     # -- Begin function ffi_test_51
	.p2align	4
	.type	ffi_test_51,@function
ffi_test_51:                            # @ffi_test_51
	.cfi_startproc
# %bb.0:
                                        # kill: def $edx killed $edx def $rdx
                                        # kill: def $edi killed $edi def $rdi
	addl	%esi, %edi
	leal	(%rdx,%rdi), %eax
	incl	%eax
	retq
.Lfunc_end55:
	.size	ffi_test_51, .Lfunc_end55-ffi_test_51
	.cfi_endproc
                                        # -- End function
	.section	.rodata.cst4,"aM",@progbits,4
	.p2align	2, 0x0                          # -- Begin function ffi_test_52
.LCPI56_0:
	.long	0x3f800000                      # float 1
	.text
	.globl	ffi_test_52
	.p2align	4
	.type	ffi_test_52,@function
ffi_test_52:                            # @ffi_test_52
	.cfi_startproc
# %bb.0:
	cvtsi2ss	%edi, %xmm1
	cvtsi2ss	%esi, %xmm2
	addss	%xmm0, %xmm1
	addss	%xmm1, %xmm2
	addss	.LCPI56_0(%rip), %xmm2
	cvttss2si	%xmm2, %eax
	retq
.Lfunc_end56:
	.size	ffi_test_52, .Lfunc_end56-ffi_test_52
	.cfi_endproc
                                        # -- End function
	.section	.rodata.cst4,"aM",@progbits,4
	.p2align	2, 0x0                          # -- Begin function ffi_test_53
.LCPI57_0:
	.long	0x3f800000                      # float 1
	.text
	.globl	ffi_test_53
	.p2align	4
	.type	ffi_test_53,@function
ffi_test_53:                            # @ffi_test_53
	.cfi_startproc
# %bb.0:
	cvtsi2ss	%edi, %xmm1
	cvtsi2ss	%esi, %xmm2
	addss	%xmm0, %xmm1
	xorps	%xmm0, %xmm0
	cvtsi2ss	%edx, %xmm0
	addss	%xmm1, %xmm2
	addss	%xmm2, %xmm0
	addss	.LCPI57_0(%rip), %xmm0
	cvttss2si	%xmm0, %eax
	retq
.Lfunc_end57:
	.size	ffi_test_53, .Lfunc_end57-ffi_test_53
	.cfi_endproc
                                        # -- End function
	.globl	ffi_test_54                     # -- Begin function ffi_test_54
	.p2align	4
	.type	ffi_test_54,@function
ffi_test_54:                            # @ffi_test_54
	.cfi_startproc
# %bb.0:
                                        # kill: def $esi killed $esi def $rsi
	addl	%edi, %esi
	shrq	$32, %rdi
	leal	(%rdi,%rsi), %eax
	incl	%eax
	retq
.Lfunc_end58:
	.size	ffi_test_54, .Lfunc_end58-ffi_test_54
	.cfi_endproc
                                        # -- End function
	.globl	ffi_test_55                     # -- Begin function ffi_test_55
	.p2align	4
	.type	ffi_test_55,@function
ffi_test_55:                            # @ffi_test_55
	.cfi_startproc
# %bb.0:
                                        # kill: def $edx killed $edx def $rdx
                                        # kill: def $esi killed $esi def $rsi
	addl	%edi, %esi
	shrq	$32, %rdi
	addl	%edi, %esi
	leal	(%rdx,%rsi), %eax
	incl	%eax
	retq
.Lfunc_end59:
	.size	ffi_test_55, .Lfunc_end59-ffi_test_55
	.cfi_endproc
                                        # -- End function
	.globl	ffi_test_56                     # -- Begin function ffi_test_56
	.p2align	4
	.type	ffi_test_56,@function
ffi_test_56:                            # @ffi_test_56
	.cfi_startproc
# %bb.0:
                                        # kill: def $ecx killed $ecx def $rcx
                                        # kill: def $esi killed $esi def $rsi
	addl	%edi, %esi
	shrq	$32, %rdi
	addl	%edi, %esi
	addl	%edx, %esi
	leal	(%rcx,%rsi), %eax
	incl	%eax
	retq
.Lfunc_end60:
	.size	ffi_test_56, .Lfunc_end60-ffi_test_56
	.cfi_endproc
                                        # -- End function
	.globl	ffi_test_57                     # -- Begin function ffi_test_57
	.p2align	4
	.type	ffi_test_57,@function
ffi_test_57:                            # @ffi_test_57
	.cfi_startproc
# %bb.0:
                                        # kill: def $esi killed $esi def $rsi
                                        # kill: def $edi killed $edi def $rdi
	leal	(%rsi,%rdi), %eax
	subl	%esi, %edi
	shlq	$32, %rdi
	orq	%rdi, %rax
	retq
.Lfunc_end61:
	.size	ffi_test_57, .Lfunc_end61-ffi_test_57
	.cfi_endproc
                                        # -- End function
	.globl	ffi_test_58                     # -- Begin function ffi_test_58
	.p2align	4
	.type	ffi_test_58,@function
ffi_test_58:                            # @ffi_test_58
	.cfi_startproc
# %bb.0:
                                        # kill: def $esi killed $esi def $rsi
                                        # kill: def $edi killed $edi def $rdi
	addl	%esi, %edi
	subl	%edx, %esi
	shlq	$32, %rsi
	leaq	(%rdi,%rsi), %rax
	retq
.Lfunc_end62:
	.size	ffi_test_58, .Lfunc_end62-ffi_test_58
	.cfi_endproc
                                        # -- End function
	.globl	ffi_test_59                     # -- Begin function ffi_test_59
	.p2align	4
	.type	ffi_test_59,@function
ffi_test_59:                            # @ffi_test_59
	.cfi_startproc
# %bb.0:
	movq	%rdi, %rax
	retq
.Lfunc_end63:
	.size	ffi_test_59, .Lfunc_end63-ffi_test_59
	.cfi_endproc
                                        # -- End function
	.globl	ffi_test_60                     # -- Begin function ffi_test_60
	.p2align	4
	.type	ffi_test_60,@function
ffi_test_60:                            # @ffi_test_60
	.cfi_startproc
# %bb.0:
	movq	%rdi, %rax
	retq
.Lfunc_end64:
	.size	ffi_test_60, .Lfunc_end64-ffi_test_60
	.cfi_endproc
                                        # -- End function
	.globl	ffi_test_61                     # -- Begin function ffi_test_61
	.p2align	4
	.type	ffi_test_61,@function
ffi_test_61:                            # @ffi_test_61
	.cfi_startproc
# %bb.0:
	movb	$1, %al
	xorl	%edx, %edx
	retq
.Lfunc_end65:
	.size	ffi_test_61, .Lfunc_end65-ffi_test_61
	.cfi_endproc
                                        # -- End function
	.globl	ffi_test_62                     # -- Begin function ffi_test_62
	.p2align	4
	.type	ffi_test_62,@function
ffi_test_62:                            # @ffi_test_62
	.cfi_startproc
# %bb.0:
	movabsq	$1311768467750121387, %rax      # imm = 0x12345678ABCDEFAB
	retq
.Lfunc_end66:
	.size	ffi_test_62, .Lfunc_end66-ffi_test_62
	.cfi_endproc
                                        # -- End function
	.globl	ffi_test_63                     # -- Begin function ffi_test_63
	.p2align	4
	.type	ffi_test_63,@function
ffi_test_63:                            # @ffi_test_63
	.cfi_startproc
# %bb.0:
	movabsq	$-6066929601824707635, %rax     # imm = 0xABCDEFABCDEFABCD
	movabsq	$1311768467302729063, %rdx      # imm = 0x1234567891234567
	retq
.Lfunc_end67:
	.size	ffi_test_63, .Lfunc_end67-ffi_test_63
	.cfi_endproc
                                        # -- End function
	.globl	ffi_test_64                     # -- Begin function ffi_test_64
	.p2align	4
	.type	ffi_test_64,@function
ffi_test_64:                            # @ffi_test_64
	.cfi_startproc
# %bb.0:
	subq	$88, %rsp
	.cfi_def_cfa_offset 96
	movq	%rsi, -88(%rsp)
	movq	%rdx, -80(%rsp)
	movq	%rcx, -72(%rsp)
	movq	%r8, -64(%rsp)
	movq	%r9, -56(%rsp)
	testb	%al, %al
	je	.LBB68_19
# %bb.18:
	movaps	%xmm0, -48(%rsp)
	movaps	%xmm1, -32(%rsp)
	movaps	%xmm2, -16(%rsp)
	movaps	%xmm3, (%rsp)
	movaps	%xmm4, 16(%rsp)
	movaps	%xmm5, 32(%rsp)
	movaps	%xmm6, 48(%rsp)
	movaps	%xmm7, 64(%rsp)
.LBB68_19:
	leaq	-96(%rsp), %rax
	movq	%rax, -112(%rsp)
	leaq	96(%rsp), %rax
	movq	%rax, -120(%rsp)
	movabsq	$206158430216, %rax             # imm = 0x3000000008
	movq	%rax, -128(%rsp)
	testl	%edi, %edi
	jle	.LBB68_1
# %bb.2:
	movl	-128(%rsp), %edx
	movq	-112(%rsp), %rcx
	movq	-120(%rsp), %rsi
	cmpl	$1, %edi
	jne	.LBB68_10
# %bb.3:
	xorl	%eax, %eax
.LBB68_4:
	testb	$1, %dil
	je	.LBB68_9
# %bb.5:
	cmpl	$41, %edx
	jae	.LBB68_6
# %bb.7:
	movl	%edx, %esi
	addq	%rsi, %rcx
	addl	$8, %edx
	movl	%edx, -128(%rsp)
	movq	%rcx, %rsi
	jmp	.LBB68_8
.LBB68_1:
	xorl	%eax, %eax
	addq	$88, %rsp
	.cfi_def_cfa_offset 8
	retq
.LBB68_10:
	.cfi_def_cfa_offset 96
	movl	%edi, %r8d
	andl	$2147483646, %r8d               # imm = 0x7FFFFFFE
	xorl	%eax, %eax
	jmp	.LBB68_11
	.p2align	4
.LBB68_16:                              #   in Loop: Header=BB68_11 Depth=1
	movq	%r9, %rsi
	movl	%edx, %r9d
	addq	%rcx, %r9
	addl	$8, %edx
	movl	%edx, -128(%rsp)
.LBB68_17:                              #   in Loop: Header=BB68_11 Depth=1
	addl	(%r9), %eax
	addl	$-2, %r8d
	je	.LBB68_4
.LBB68_11:                              # =>This Inner Loop Header: Depth=1
	cmpl	$40, %edx
	ja	.LBB68_13
# %bb.12:                               #   in Loop: Header=BB68_11 Depth=1
	movq	%rsi, %r9
	movl	%edx, %esi
	addq	%rcx, %rsi
	addl	$8, %edx
	movl	%edx, -128(%rsp)
	jmp	.LBB68_14
	.p2align	4
.LBB68_13:                              #   in Loop: Header=BB68_11 Depth=1
	leaq	8(%rsi), %r9
	movq	%r9, -120(%rsp)
.LBB68_14:                              #   in Loop: Header=BB68_11 Depth=1
	addl	(%rsi), %eax
	cmpl	$41, %edx
	jb	.LBB68_16
# %bb.15:                               #   in Loop: Header=BB68_11 Depth=1
	leaq	8(%r9), %rsi
	movq	%rsi, -120(%rsp)
	jmp	.LBB68_17
.LBB68_6:
	leaq	8(%rsi), %rcx
	movq	%rcx, -120(%rsp)
.LBB68_8:
	addl	(%rsi), %eax
.LBB68_9:
	addq	$88, %rsp
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end68:
	.size	ffi_test_64, .Lfunc_end68-ffi_test_64
	.cfi_endproc
                                        # -- End function
	.globl	ffi_test_65                     # -- Begin function ffi_test_65
	.p2align	4
	.type	ffi_test_65,@function
ffi_test_65:                            # @ffi_test_65
	.cfi_startproc
# %bb.0:
	subq	$88, %rsp
	.cfi_def_cfa_offset 96
	movq	%rsi, -88(%rsp)
	movq	%rdx, -80(%rsp)
	movq	%rcx, -72(%rsp)
	movq	%r8, -64(%rsp)
	movq	%r9, -56(%rsp)
	testb	%al, %al
	je	.LBB69_19
# %bb.18:
	movapd	%xmm0, -48(%rsp)
	movaps	%xmm1, -32(%rsp)
	movaps	%xmm2, -16(%rsp)
	movaps	%xmm3, (%rsp)
	movaps	%xmm4, 16(%rsp)
	movaps	%xmm5, 32(%rsp)
	movaps	%xmm6, 48(%rsp)
	movaps	%xmm7, 64(%rsp)
.LBB69_19:
	leaq	-96(%rsp), %rax
	movq	%rax, -112(%rsp)
	leaq	96(%rsp), %rax
	movq	%rax, -120(%rsp)
	movabsq	$206158430216, %rax             # imm = 0x3000000008
	movq	%rax, -128(%rsp)
	testl	%edi, %edi
	jle	.LBB69_1
# %bb.2:
	movq	-112(%rsp), %rax
	movl	-124(%rsp), %ecx
	movq	-120(%rsp), %rdx
	cmpl	$1, %edi
	jne	.LBB69_10
# %bb.3:
	xorpd	%xmm0, %xmm0
.LBB69_4:
	testb	$1, %dil
	je	.LBB69_9
# %bb.5:
	cmpl	$161, %ecx
	jae	.LBB69_6
# %bb.7:
	movl	%ecx, %edx
	addq	%rdx, %rax
	addl	$16, %ecx
	movl	%ecx, -124(%rsp)
	movq	%rax, %rdx
	jmp	.LBB69_8
.LBB69_1:
	xorpd	%xmm0, %xmm0
	addq	$88, %rsp
	.cfi_def_cfa_offset 8
	retq
.LBB69_10:
	.cfi_def_cfa_offset 96
	movl	%edi, %esi
	andl	$2147483646, %esi               # imm = 0x7FFFFFFE
	xorpd	%xmm0, %xmm0
	jmp	.LBB69_11
	.p2align	4
.LBB69_16:                              #   in Loop: Header=BB69_11 Depth=1
	movq	%r8, %rdx
	movl	%ecx, %r8d
	addq	%rax, %r8
	addl	$16, %ecx
	movl	%ecx, -124(%rsp)
.LBB69_17:                              #   in Loop: Header=BB69_11 Depth=1
	addsd	(%r8), %xmm0
	addl	$-2, %esi
	je	.LBB69_4
.LBB69_11:                              # =>This Inner Loop Header: Depth=1
	cmpl	$160, %ecx
	ja	.LBB69_13
# %bb.12:                               #   in Loop: Header=BB69_11 Depth=1
	movq	%rdx, %r8
	movl	%ecx, %edx
	addq	%rax, %rdx
	addl	$16, %ecx
	movl	%ecx, -124(%rsp)
	jmp	.LBB69_14
	.p2align	4
.LBB69_13:                              #   in Loop: Header=BB69_11 Depth=1
	leaq	8(%rdx), %r8
	movq	%r8, -120(%rsp)
.LBB69_14:                              #   in Loop: Header=BB69_11 Depth=1
	addsd	(%rdx), %xmm0
	cmpl	$161, %ecx
	jb	.LBB69_16
# %bb.15:                               #   in Loop: Header=BB69_11 Depth=1
	leaq	8(%r8), %rdx
	movq	%rdx, -120(%rsp)
	jmp	.LBB69_17
.LBB69_6:
	leaq	8(%rdx), %rax
	movq	%rax, -120(%rsp)
.LBB69_8:
	addsd	(%rdx), %xmm0
.LBB69_9:
	addq	$88, %rsp
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end69:
	.size	ffi_test_65, .Lfunc_end69-ffi_test_65
	.cfi_endproc
                                        # -- End function
	.globl	ffi_test_66                     # -- Begin function ffi_test_66
	.p2align	4
	.type	ffi_test_66,@function
ffi_test_66:                            # @ffi_test_66
	.cfi_startproc
# %bb.0:
	addq	%rdi, %rsi
	leaq	(%rdx,%rcx), %rax
	addq	%rsi, %rax
	addq	%r8, %rax
	addq	8(%rsp), %rax
	addq	16(%rsp), %rax
	retq
.Lfunc_end70:
	.size	ffi_test_66, .Lfunc_end70-ffi_test_66
	.cfi_endproc
                                        # -- End function
	.globl	ffi_test_67                     # -- Begin function ffi_test_67
	.p2align	4
	.type	ffi_test_67,@function
ffi_test_67:                            # @ffi_test_67
	.cfi_startproc
# %bb.0:
	addq	%rsi, %rdi
	addq	%rcx, %rdx
	addq	%rdi, %rdx
	addq	%r8, %rdx
	leaq	(%rdx,%r9,2), %rax
	addq	8(%rsp), %rax
	addq	16(%rsp), %rax
	retq
.Lfunc_end71:
	.size	ffi_test_67, .Lfunc_end71-ffi_test_67
	.cfi_endproc
                                        # -- End function
	.globl	ffi_test_68                     # -- Begin function ffi_test_68
	.p2align	4
	.type	ffi_test_68,@function
ffi_test_68:                            # @ffi_test_68
	.cfi_startproc
# %bb.0:
	movdqu	16(%rsp), %xmm0
	movdqu	32(%rsp), %xmm1
	paddq	%xmm0, %xmm1
	pshufd	$238, %xmm1, %xmm0              # xmm0 = xmm1[2,3,2,3]
	paddq	%xmm1, %xmm0
	movq	%xmm0, %r9
	addq	8(%rsp), %r9
	addq	%rdi, %rsi
	leaq	(%rdx,%rcx), %rax
	addq	%r8, %rax
	addq	%rsi, %rax
	addq	%r9, %rax
	retq
.Lfunc_end72:
	.size	ffi_test_68, .Lfunc_end72-ffi_test_68
	.cfi_endproc
                                        # -- End function
	.globl	ffi_test_69                     # -- Begin function ffi_test_69
	.p2align	4
	.type	ffi_test_69,@function
ffi_test_69:                            # @ffi_test_69
	.cfi_startproc
# %bb.0:
	cvttss2si	8(%rsp), %r9
	movdqu	16(%rsp), %xmm0
	movdqu	32(%rsp), %xmm1
	paddq	%xmm0, %xmm1
	pshufd	$238, %xmm1, %xmm0              # xmm0 = xmm1[2,3,2,3]
	paddq	%xmm1, %xmm0
	movq	%xmm0, %r10
	leaq	(%rdi,%rdx), %rax
	addq	%r8, %rcx
	addq	%rcx, %r9
	addq	%rsi, %rax
	addq	%r10, %rax
	addq	%r9, %rax
	retq
.Lfunc_end73:
	.size	ffi_test_69, .Lfunc_end73-ffi_test_69
	.cfi_endproc
                                        # -- End function
	.globl	ffi_test_70                     # -- Begin function ffi_test_70
	.p2align	4
	.type	ffi_test_70,@function
ffi_test_70:                            # @ffi_test_70
	.cfi_startproc
# %bb.0:
	movdqu	40(%rsp), %xmm0
	paddq	8(%rsp), %xmm0
	pshufd	$238, %xmm0, %xmm1              # xmm1 = xmm0[2,3,2,3]
	paddq	%xmm0, %xmm1
	movq	%xmm1, %rax
	addq	32(%rsp), %rax
	addq	24(%rsp), %rsi
	addq	%rsi, %rax
	addq	%rdi, %rax
	retq
.Lfunc_end74:
	.size	ffi_test_70, .Lfunc_end74-ffi_test_70
	.cfi_endproc
                                        # -- End function
	.globl	bug1021_test_1                  # -- Begin function bug1021_test_1
	.p2align	4
	.type	bug1021_test_1,@function
bug1021_test_1:                         # @bug1021_test_1
	.cfi_startproc
# %bb.0:
                                        # kill: def $esi killed $esi def $rsi
	imull	%esi, %esi
	leaq	(%rsi,%rdi), %rax
	retq
.Lfunc_end75:
	.size	bug1021_test_1, .Lfunc_end75-bug1021_test_1
	.cfi_endproc
                                        # -- End function
	.globl	bug1021_test_2                  # -- Begin function bug1021_test_2
	.p2align	4
	.type	bug1021_test_2,@function
bug1021_test_2:                         # @bug1021_test_2
	.cfi_startproc
# %bb.0:
	movsbl	(%rsi), %eax
	retq
.Lfunc_end76:
	.size	bug1021_test_2, .Lfunc_end76-bug1021_test_2
	.cfi_endproc
                                        # -- End function
	.globl	bug1021_test_3                  # -- Begin function bug1021_test_3
	.p2align	4
	.type	bug1021_test_3,@function
bug1021_test_3:                         # @bug1021_test_3
	.cfi_startproc
# %bb.0:
	movslq	%edi, %rax
	retq
.Lfunc_end77:
	.size	bug1021_test_3, .Lfunc_end77-bug1021_test_3
	.cfi_endproc
                                        # -- End function
	.globl	ffi_test_small_floats_available # -- Begin function ffi_test_small_floats_available
	.p2align	4
	.type	ffi_test_small_floats_available,@function
ffi_test_small_floats_available:        # @ffi_test_small_floats_available
	.cfi_startproc
# %bb.0:
	xorl	%eax, %eax
	retq
.Lfunc_end78:
	.size	ffi_test_small_floats_available, .Lfunc_end78-ffi_test_small_floats_available
	.cfi_endproc
                                        # -- End function
	.section	.rodata.cst8,"aM",@progbits,8
	.p2align	3, 0x0                          # -- Begin function abi_narrow
.LCPI79_0:
	.quad	0x4008000000000000              # double 3
.LCPI79_1:
	.quad	0x4010000000000000              # double 4
.LCPI79_2:
	.quad	0x4014000000000000              # double 5
.LCPI79_3:
	.quad	0x4018000000000000              # double 6
.LCPI79_4:
	.quad	0x401c000000000000              # double 7
.LCPI79_5:
	.quad	0x4020000000000000              # double 8
.LCPI79_6:
	.quad	0x4022000000000000              # double 9
.LCPI79_7:
	.quad	0x4024000000000000              # double 10
.LCPI79_8:
	.quad	0x4026000000000000              # double 11
.LCPI79_9:
	.quad	0x4028000000000000              # double 12
.LCPI79_10:
	.quad	0x402a000000000000              # double 13
.LCPI79_11:
	.quad	0x402c000000000000              # double 14
.LCPI79_12:
	.quad	0x402e000000000000              # double 15
	.text
	.globl	abi_narrow
	.p2align	4
	.type	abi_narrow,@function
abi_narrow:                             # @abi_narrow
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	.cfi_offset %rbx, -24
	.cfi_offset %rbp, -16
	movl	80(%rsp), %eax
	movzwl	64(%rsp), %r10d
	movswl	56(%rsp), %r11d
	movzbl	48(%rsp), %ebx
	movsbl	40(%rsp), %ebp
	cvtsi2sd	%rdi, %xmm0
	cvtsi2sd	%rsi, %xmm1
	addsd	%xmm1, %xmm1
	addsd	%xmm0, %xmm1
	xorps	%xmm0, %xmm0
	cvtsi2sd	%rdx, %xmm0
	mulsd	.LCPI79_0(%rip), %xmm0
	cvtsi2sd	%rcx, %xmm2
	addsd	%xmm1, %xmm0
	mulsd	.LCPI79_1(%rip), %xmm2
	addsd	%xmm0, %xmm2
	xorps	%xmm0, %xmm0
	cvtsi2sd	%r8, %xmm0
	mulsd	.LCPI79_2(%rip), %xmm0
	xorps	%xmm1, %xmm1
	cvtsi2sd	%r9, %xmm1
	mulsd	.LCPI79_3(%rip), %xmm1
	addsd	%xmm2, %xmm0
	addsd	%xmm0, %xmm1
	xorps	%xmm0, %xmm0
	cvtsi2sdq	24(%rsp), %xmm0
	mulsd	.LCPI79_4(%rip), %xmm0
	xorps	%xmm2, %xmm2
	cvtsi2sdq	32(%rsp), %xmm2
	addsd	%xmm1, %xmm0
	mulsd	.LCPI79_5(%rip), %xmm2
	addsd	%xmm0, %xmm2
	xorps	%xmm0, %xmm0
	cvtsi2sd	%ebp, %xmm0
	mulsd	.LCPI79_6(%rip), %xmm0
	xorps	%xmm1, %xmm1
	cvtsi2sd	%ebx, %xmm1
	mulsd	.LCPI79_7(%rip), %xmm1
	addsd	%xmm2, %xmm0
	addsd	%xmm0, %xmm1
	xorps	%xmm0, %xmm0
	cvtsi2sd	%r11d, %xmm0
	mulsd	.LCPI79_8(%rip), %xmm0
	xorps	%xmm2, %xmm2
	cvtsi2sd	%r10d, %xmm2
	addsd	%xmm1, %xmm0
	mulsd	.LCPI79_9(%rip), %xmm2
	addsd	%xmm0, %xmm2
	xorps	%xmm0, %xmm0
	cvtsi2sdl	72(%rsp), %xmm0
	mulsd	.LCPI79_10(%rip), %xmm0
	xorps	%xmm1, %xmm1
	cvtsi2sd	%rax, %xmm1
	mulsd	.LCPI79_11(%rip), %xmm1
	addsd	%xmm2, %xmm0
	addsd	%xmm0, %xmm1
	xorps	%xmm0, %xmm0
	cvtsi2sdq	88(%rsp), %xmm0
	mulsd	.LCPI79_12(%rip), %xmm0
	addsd	%xmm1, %xmm0
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end79:
	.size	abi_narrow, .Lfunc_end79-abi_narrow
	.cfi_endproc
                                        # -- End function
	.globl	call_narrow                     # -- Begin function call_narrow
	.p2align	4
	.type	call_narrow,@function
call_narrow:                            # @call_narrow
	.cfi_startproc
# %bb.0:
	pushq	%rax
	.cfi_def_cfa_offset 16
	movq	%rdi, %rax
	subq	$8, %rsp
	.cfi_adjust_cfa_offset 8
	movl	$1, %edi
	movl	$2, %esi
	movl	$3, %edx
	movl	$4, %ecx
	movl	$5, %r8d
	movl	$6, %r9d
	pushq	$-123456789                     # imm = 0xF8A432EB
	.cfi_adjust_cfa_offset 8
	pushq	$-1294967296                    # imm = 0xB2D05E00
	.cfi_adjust_cfa_offset 8
	pushq	$-70000                         # imm = 0xFFFEEE90
	.cfi_adjust_cfa_offset 8
	pushq	$60000                          # imm = 0xEA60
	.cfi_adjust_cfa_offset 8
	pushq	$-300                           # imm = 0xFED4
	.cfi_adjust_cfa_offset 8
	pushq	$250
	.cfi_adjust_cfa_offset 8
	pushq	$-9
	.cfi_adjust_cfa_offset 8
	pushq	$8
	.cfi_adjust_cfa_offset 8
	pushq	$7
	.cfi_adjust_cfa_offset 8
	callq	*%rax
	addq	$80, %rsp
	.cfi_adjust_cfa_offset -80
	popq	%rax
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end80:
	.size	call_narrow, .Lfunc_end80-call_narrow
	.cfi_endproc
                                        # -- End function
	.section	.rodata.cst8,"aM",@progbits,8
	.p2align	3, 0x0                          # -- Begin function abi_floats
.LCPI81_0:
	.quad	0x4008000000000000              # double 3
.LCPI81_1:
	.quad	0x4010000000000000              # double 4
.LCPI81_2:
	.quad	0x4014000000000000              # double 5
.LCPI81_3:
	.quad	0x4018000000000000              # double 6
.LCPI81_4:
	.quad	0x401c000000000000              # double 7
.LCPI81_5:
	.quad	0x4020000000000000              # double 8
.LCPI81_6:
	.quad	0x4022000000000000              # double 9
.LCPI81_7:
	.quad	0x4024000000000000              # double 10
.LCPI81_8:
	.quad	0x4026000000000000              # double 11
	.text
	.globl	abi_floats
	.p2align	4
	.type	abi_floats,@function
abi_floats:                             # @abi_floats
	.cfi_startproc
# %bb.0:
	movss	24(%rsp), %xmm8                 # xmm8 = mem[0],zero,zero,zero
	movss	16(%rsp), %xmm9                 # xmm9 = mem[0],zero,zero,zero
	movss	8(%rsp), %xmm10                 # xmm10 = mem[0],zero,zero,zero
	cvtss2sd	%xmm0, %xmm0
	cvtss2sd	%xmm1, %xmm1
	addsd	%xmm1, %xmm1
	addsd	%xmm0, %xmm1
	xorps	%xmm0, %xmm0
	cvtss2sd	%xmm2, %xmm0
	mulsd	.LCPI81_0(%rip), %xmm0
	xorps	%xmm2, %xmm2
	cvtss2sd	%xmm3, %xmm2
	addsd	%xmm1, %xmm0
	mulsd	.LCPI81_1(%rip), %xmm2
	addsd	%xmm0, %xmm2
	xorps	%xmm0, %xmm0
	cvtss2sd	%xmm4, %xmm0
	mulsd	.LCPI81_2(%rip), %xmm0
	xorps	%xmm1, %xmm1
	cvtss2sd	%xmm5, %xmm1
	mulsd	.LCPI81_3(%rip), %xmm1
	addsd	%xmm2, %xmm0
	addsd	%xmm0, %xmm1
	xorps	%xmm0, %xmm0
	cvtss2sd	%xmm6, %xmm0
	mulsd	.LCPI81_4(%rip), %xmm0
	xorps	%xmm2, %xmm2
	cvtss2sd	%xmm7, %xmm2
	addsd	%xmm1, %xmm0
	mulsd	.LCPI81_5(%rip), %xmm2
	addsd	%xmm0, %xmm2
	xorps	%xmm0, %xmm0
	cvtss2sd	%xmm10, %xmm0
	mulsd	.LCPI81_6(%rip), %xmm0
	xorps	%xmm1, %xmm1
	cvtss2sd	%xmm9, %xmm1
	mulsd	.LCPI81_7(%rip), %xmm1
	addsd	%xmm2, %xmm0
	addsd	%xmm0, %xmm1
	xorps	%xmm0, %xmm0
	cvtss2sd	%xmm8, %xmm0
	mulsd	.LCPI81_8(%rip), %xmm0
	addsd	%xmm1, %xmm0
	retq
.Lfunc_end81:
	.size	abi_floats, .Lfunc_end81-abi_floats
	.cfi_endproc
                                        # -- End function
	.section	.rodata.cst4,"aM",@progbits,4
	.p2align	2, 0x0                          # -- Begin function call_floats
.LCPI82_0:
	.long	0x3f800000                      # float 1
.LCPI82_1:
	.long	0x40000000                      # float 2
.LCPI82_2:
	.long	0x40400000                      # float 3
.LCPI82_3:
	.long	0x40800000                      # float 4
.LCPI82_4:
	.long	0x40a00000                      # float 5
.LCPI82_5:
	.long	0x40c00000                      # float 6
.LCPI82_6:
	.long	0x40e00000                      # float 7
.LCPI82_7:
	.long	0x41000000                      # float 8
	.text
	.globl	call_floats
	.p2align	4
	.type	call_floats,@function
call_floats:                            # @call_floats
	.cfi_startproc
# %bb.0:
	pushq	%rax
	.cfi_def_cfa_offset 16
	subq	$8, %rsp
	.cfi_adjust_cfa_offset 8
	movss	.LCPI82_0(%rip), %xmm0          # xmm0 = [1.0E+0,0.0E+0,0.0E+0,0.0E+0]
	movss	.LCPI82_1(%rip), %xmm1          # xmm1 = [2.0E+0,0.0E+0,0.0E+0,0.0E+0]
	movss	.LCPI82_2(%rip), %xmm2          # xmm2 = [3.0E+0,0.0E+0,0.0E+0,0.0E+0]
	movss	.LCPI82_3(%rip), %xmm3          # xmm3 = [4.0E+0,0.0E+0,0.0E+0,0.0E+0]
	movss	.LCPI82_4(%rip), %xmm4          # xmm4 = [5.0E+0,0.0E+0,0.0E+0,0.0E+0]
	movss	.LCPI82_5(%rip), %xmm5          # xmm5 = [6.0E+0,0.0E+0,0.0E+0,0.0E+0]
	movss	.LCPI82_6(%rip), %xmm6          # xmm6 = [7.0E+0,0.0E+0,0.0E+0,0.0E+0]
	movss	.LCPI82_7(%rip), %xmm7          # xmm7 = [8.0E+0,0.0E+0,0.0E+0,0.0E+0]
	pushq	$1093664768                     # imm = 0x41300000
	.cfi_adjust_cfa_offset 8
	pushq	$1092616192                     # imm = 0x41200000
	.cfi_adjust_cfa_offset 8
	pushq	$1091567616                     # imm = 0x41100000
	.cfi_adjust_cfa_offset 8
	callq	*%rdi
	addq	$32, %rsp
	.cfi_adjust_cfa_offset -32
	popq	%rax
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end82:
	.size	call_floats, .Lfunc_end82-call_floats
	.cfi_endproc
                                        # -- End function
	.section	.rodata.cst8,"aM",@progbits,8
	.p2align	3, 0x0                          # -- Begin function abi_mixed
.LCPI83_0:
	.quad	0x4008000000000000              # double 3
.LCPI83_1:
	.quad	0x4010000000000000              # double 4
.LCPI83_2:
	.quad	0x4014000000000000              # double 5
.LCPI83_3:
	.quad	0x4018000000000000              # double 6
.LCPI83_4:
	.quad	0x401c000000000000              # double 7
.LCPI83_5:
	.quad	0x4020000000000000              # double 8
.LCPI83_6:
	.quad	0x4022000000000000              # double 9
.LCPI83_7:
	.quad	0x4024000000000000              # double 10
.LCPI83_8:
	.quad	0x4026000000000000              # double 11
.LCPI83_9:
	.quad	0x4028000000000000              # double 12
.LCPI83_10:
	.quad	0x402a000000000000              # double 13
.LCPI83_11:
	.quad	0x402c000000000000              # double 14
.LCPI83_12:
	.quad	0x402e000000000000              # double 15
.LCPI83_13:
	.quad	0x4030000000000000              # double 16
.LCPI83_14:
	.quad	0x4031000000000000              # double 17
.LCPI83_15:
	.quad	0x4032000000000000              # double 18
.LCPI83_16:
	.quad	0x4033000000000000              # double 19
.LCPI83_17:
	.quad	0x4034000000000000              # double 20
.LCPI83_18:
	.quad	0x4035000000000000              # double 21
	.text
	.globl	abi_mixed
	.p2align	4
	.type	abi_mixed,@function
abi_mixed:                              # @abi_mixed
	.cfi_startproc
# %bb.0:
	movsd	48(%rsp), %xmm8                 # xmm8 = mem[0],zero
	movswl	40(%rsp), %eax
	cvtsi2sd	%rdi, %xmm9
	cvtsi2sd	%rsi, %xmm10
	addsd	%xmm10, %xmm10
	addsd	%xmm9, %xmm10
	xorps	%xmm9, %xmm9
	cvtsi2sd	%rdx, %xmm9
	mulsd	.LCPI83_0(%rip), %xmm9
	cvtsi2sd	%rcx, %xmm11
	mulsd	.LCPI83_1(%rip), %xmm11
	addsd	%xmm10, %xmm9
	addsd	%xmm9, %xmm11
	xorps	%xmm9, %xmm9
	cvtsi2sd	%r8, %xmm9
	mulsd	.LCPI83_2(%rip), %xmm9
	xorps	%xmm10, %xmm10
	cvtsi2sd	%r9, %xmm10
	addsd	%xmm11, %xmm9
	mulsd	.LCPI83_3(%rip), %xmm10
	addsd	%xmm9, %xmm10
	xorps	%xmm11, %xmm11
	cvtsi2sdq	8(%rsp), %xmm11
	mulsd	.LCPI83_4(%rip), %xmm11
	movss	32(%rsp), %xmm9                 # xmm9 = mem[0],zero,zero,zero
	addsd	%xmm10, %xmm11
	xorps	%xmm10, %xmm10
	cvtsi2sdq	16(%rsp), %xmm10
	movsbl	24(%rsp), %ecx
	mulsd	.LCPI83_5(%rip), %xmm10
	addsd	%xmm11, %xmm10
	cvtss2sd	%xmm0, %xmm0
	mulsd	.LCPI83_6(%rip), %xmm0
	cvtss2sd	%xmm1, %xmm1
	mulsd	.LCPI83_7(%rip), %xmm1
	addsd	%xmm10, %xmm0
	addsd	%xmm0, %xmm1
	xorps	%xmm0, %xmm0
	cvtss2sd	%xmm2, %xmm0
	mulsd	.LCPI83_8(%rip), %xmm0
	xorps	%xmm2, %xmm2
	cvtss2sd	%xmm3, %xmm2
	addsd	%xmm1, %xmm0
	mulsd	.LCPI83_9(%rip), %xmm2
	addsd	%xmm0, %xmm2
	xorps	%xmm0, %xmm0
	cvtss2sd	%xmm4, %xmm0
	mulsd	.LCPI83_10(%rip), %xmm0
	xorps	%xmm1, %xmm1
	cvtss2sd	%xmm5, %xmm1
	mulsd	.LCPI83_11(%rip), %xmm1
	addsd	%xmm2, %xmm0
	addsd	%xmm0, %xmm1
	xorps	%xmm0, %xmm0
	cvtss2sd	%xmm6, %xmm0
	mulsd	.LCPI83_12(%rip), %xmm0
	xorps	%xmm2, %xmm2
	cvtss2sd	%xmm7, %xmm2
	addsd	%xmm1, %xmm0
	mulsd	.LCPI83_13(%rip), %xmm2
	addsd	%xmm0, %xmm2
	xorps	%xmm0, %xmm0
	cvtsi2sd	%ecx, %xmm0
	mulsd	.LCPI83_14(%rip), %xmm0
	xorps	%xmm1, %xmm1
	cvtss2sd	%xmm9, %xmm1
	mulsd	.LCPI83_15(%rip), %xmm1
	addsd	%xmm2, %xmm0
	addsd	%xmm0, %xmm1
	xorps	%xmm0, %xmm0
	cvtsi2sd	%eax, %xmm0
	mulsd	.LCPI83_16(%rip), %xmm0
	mulsd	.LCPI83_17(%rip), %xmm8
	addsd	%xmm1, %xmm0
	addsd	%xmm0, %xmm8
	xorps	%xmm0, %xmm0
	cvtsi2sdl	56(%rsp), %xmm0
	mulsd	.LCPI83_18(%rip), %xmm0
	addsd	%xmm8, %xmm0
	retq
.Lfunc_end83:
	.size	abi_mixed, .Lfunc_end83-abi_mixed
	.cfi_endproc
                                        # -- End function
	.section	.rodata.cst4,"aM",@progbits,4
	.p2align	2, 0x0                          # -- Begin function call_mixed
.LCPI84_0:
	.long	0x3f800000                      # float 1
.LCPI84_1:
	.long	0x40000000                      # float 2
.LCPI84_2:
	.long	0x40400000                      # float 3
.LCPI84_3:
	.long	0x40800000                      # float 4
.LCPI84_4:
	.long	0x40a00000                      # float 5
.LCPI84_5:
	.long	0x40c00000                      # float 6
.LCPI84_6:
	.long	0x40e00000                      # float 7
.LCPI84_7:
	.long	0x41000000                      # float 8
	.text
	.globl	call_mixed
	.p2align	4
	.type	call_mixed,@function
call_mixed:                             # @call_mixed
	.cfi_startproc
# %bb.0:
	pushq	%rax
	.cfi_def_cfa_offset 16
	movq	%rdi, %rax
	subq	$8, %rsp
	.cfi_adjust_cfa_offset 8
	movabsq	$4621959855077326848, %r10      # imm = 0x4024800000000000
	movss	.LCPI84_0(%rip), %xmm0          # xmm0 = [1.0E+0,0.0E+0,0.0E+0,0.0E+0]
	movss	.LCPI84_1(%rip), %xmm1          # xmm1 = [2.0E+0,0.0E+0,0.0E+0,0.0E+0]
	movss	.LCPI84_2(%rip), %xmm2          # xmm2 = [3.0E+0,0.0E+0,0.0E+0,0.0E+0]
	movss	.LCPI84_3(%rip), %xmm3          # xmm3 = [4.0E+0,0.0E+0,0.0E+0,0.0E+0]
	movss	.LCPI84_4(%rip), %xmm4          # xmm4 = [5.0E+0,0.0E+0,0.0E+0,0.0E+0]
	movss	.LCPI84_5(%rip), %xmm5          # xmm5 = [6.0E+0,0.0E+0,0.0E+0,0.0E+0]
	movss	.LCPI84_6(%rip), %xmm6          # xmm6 = [7.0E+0,0.0E+0,0.0E+0,0.0E+0]
	movss	.LCPI84_7(%rip), %xmm7          # xmm7 = [8.0E+0,0.0E+0,0.0E+0,0.0E+0]
	movl	$1, %edi
	movl	$2, %esi
	movl	$3, %edx
	movl	$4, %ecx
	movl	$5, %r8d
	movl	$6, %r9d
	pushq	$-123456                        # imm = 0xFFFE1DC0
	.cfi_adjust_cfa_offset 8
	pushq	%r10
	.cfi_adjust_cfa_offset 8
	pushq	$-1000                          # imm = 0xFC18
	.cfi_adjust_cfa_offset 8
	pushq	$1092091904                     # imm = 0x41180000
	.cfi_adjust_cfa_offset 8
	pushq	$-9
	.cfi_adjust_cfa_offset 8
	pushq	$8
	.cfi_adjust_cfa_offset 8
	pushq	$7
	.cfi_adjust_cfa_offset 8
	callq	*%rax
	addq	$64, %rsp
	.cfi_adjust_cfa_offset -64
	popq	%rax
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end84:
	.size	call_mixed, .Lfunc_end84-call_mixed
	.cfi_endproc
                                        # -- End function
	.section	.rodata.cst8,"aM",@progbits,8
	.p2align	3, 0x0                          # -- Begin function abi_var
.LCPI85_0:
	.quad	0x4010000000000000              # double 4
	.text
	.globl	abi_var
	.p2align	4
	.type	abi_var,@function
abi_var:                                # @abi_var
	.cfi_startproc
# %bb.0:
	subq	$88, %rsp
	.cfi_def_cfa_offset 96
	movq	%rsi, -88(%rsp)
	movq	%rdx, -80(%rsp)
	movq	%rcx, -72(%rsp)
	movq	%r8, -64(%rsp)
	movq	%r9, -56(%rsp)
	testb	%al, %al
	je	.LBB85_13
# %bb.12:
	movaps	%xmm1, -32(%rsp)
	movaps	%xmm2, -16(%rsp)
	movaps	%xmm3, (%rsp)
	movaps	%xmm4, 16(%rsp)
	movaps	%xmm5, 32(%rsp)
	movaps	%xmm6, 48(%rsp)
	movaps	%xmm7, 64(%rsp)
.LBB85_13:
	leaq	-96(%rsp), %rax
	movq	%rax, -112(%rsp)
	leaq	96(%rsp), %rax
	movq	%rax, -120(%rsp)
	movabsq	$274877906952, %rax             # imm = 0x4000000008
	movq	%rax, -128(%rsp)
	movl	$8, %ecx
	movl	$8, %eax
	cmpq	$40, %rax
	ja	.LBB85_2
# %bb.1:
	addq	-112(%rsp), %rax
	addl	$8, %ecx
	movl	%ecx, -128(%rsp)
	jmp	.LBB85_3
.LBB85_2:
	movq	-120(%rsp), %rax
	leaq	8(%rax), %rdx
	movq	%rdx, -120(%rsp)
.LBB85_3:
	movl	(%rax), %eax
	movl	-124(%rsp), %esi
	cmpq	$160, %rsi
	ja	.LBB85_5
# %bb.4:
	movq	%rsi, %rdx
	addq	-112(%rsp), %rdx
	addl	$16, %esi
	movl	%esi, -124(%rsp)
	jmp	.LBB85_6
.LBB85_5:
	movq	-120(%rsp), %rdx
	leaq	8(%rdx), %rsi
	movq	%rsi, -120(%rsp)
.LBB85_6:
	movsd	(%rdx), %xmm1                   # xmm1 = mem[0],zero
	cmpl	$41, %ecx
	jae	.LBB85_7
# %bb.9:
	movq	-112(%rsp), %rdx
	movl	%ecx, %r8d
	leal	8(%rcx), %esi
	movl	%esi, -128(%rsp)
	movq	(%rdx,%r8), %rdx
	cmpl	$32, %ecx
	ja	.LBB85_8
# %bb.10:
	movl	%esi, %esi
	addq	-112(%rsp), %rsi
	addl	$16, %ecx
	movl	%ecx, -128(%rsp)
	jmp	.LBB85_11
.LBB85_7:
	movq	-120(%rsp), %rcx
	leaq	8(%rcx), %rdx
	movq	%rdx, -120(%rsp)
	movq	(%rcx), %rdx
.LBB85_8:
	movq	-120(%rsp), %rsi
	leaq	8(%rsi), %rcx
	movq	%rcx, -120(%rsp)
.LBB85_11:
	xorps	%xmm2, %xmm2
	cvtsi2sd	%edi, %xmm2
	movl	(%rsi), %ecx
	addsd	%xmm0, %xmm0
	addsd	%xmm2, %xmm0
	leal	(%rax,%rax,2), %eax
	xorps	%xmm2, %xmm2
	cvtsi2sd	%eax, %xmm2
	mulsd	.LCPI85_0(%rip), %xmm1
	addsd	%xmm0, %xmm2
	leaq	(%rdx,%rdx,4), %rax
	xorps	%xmm3, %xmm3
	cvtsi2sd	%rax, %xmm3
	addsd	%xmm2, %xmm1
	addsd	%xmm1, %xmm3
	addl	%ecx, %ecx
	leal	(%rcx,%rcx,2), %eax
	xorps	%xmm0, %xmm0
	cvtsi2sd	%eax, %xmm0
	addsd	%xmm3, %xmm0
	addq	$88, %rsp
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end85:
	.size	abi_var, .Lfunc_end85-abi_var
	.cfi_endproc
                                        # -- End function
	.section	.rodata.cst8,"aM",@progbits,8
	.p2align	3, 0x0                          # -- Begin function abi_var_spill
.LCPI86_0:
	.quad	0x4028000000000000              # double 12
	.text
	.globl	abi_var_spill
	.p2align	4
	.type	abi_var_spill,@function
abi_var_spill:                          # @abi_var_spill
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r12
	.cfi_def_cfa_offset 40
	pushq	%rbx
	.cfi_def_cfa_offset 48
	subq	$80, %rsp
	.cfi_def_cfa_offset 128
	.cfi_offset %rbx, -48
	.cfi_offset %r12, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
                                        # kill: def $r9d killed $r9d def $r9
                                        # kill: def $r8d killed $r8d def $r8
                                        # kill: def $ecx killed $ecx def $rcx
                                        # kill: def $edx killed $edx def $rdx
                                        # kill: def $esi killed $esi def $rsi
                                        # kill: def $edi killed $edi def $rdi
	testb	%al, %al
	je	.LBB86_8
# %bb.7:
	movaps	%xmm0, -48(%rsp)
	movaps	%xmm1, -32(%rsp)
	movaps	%xmm2, -16(%rsp)
	movaps	%xmm3, (%rsp)
	movaps	%xmm4, 16(%rsp)
	movaps	%xmm5, 32(%rsp)
	movaps	%xmm6, 48(%rsp)
	movaps	%xmm7, 64(%rsp)
.LBB86_8:
	leaq	-96(%rsp), %rax
	movq	%rax, -112(%rsp)
	leaq	160(%rsp), %rax
	movq	%rax, -120(%rsp)
	movabsq	$206158430256, %rax             # imm = 0x3000000030
	movq	%rax, -128(%rsp)
	movl	$48, %r10d
	cmpq	$40, %r10
	ja	.LBB86_2
# %bb.1:
	movl	$48, %eax
	addq	-112(%rsp), %rax
	addl	$8, %r10d
	movl	%r10d, -128(%rsp)
	jmp	.LBB86_3
.LBB86_2:
	movq	-120(%rsp), %rax
	leaq	8(%rax), %r10
	movq	%r10, -120(%rsp)
.LBB86_3:
	movl	152(%rsp), %r10d
	movl	144(%rsp), %r11d
	movl	136(%rsp), %ebx
	movl	128(%rsp), %r14d
	movl	(%rax), %eax
	movl	-124(%rsp), %r12d
	cmpq	$160, %r12
	ja	.LBB86_5
# %bb.4:
	movq	%r12, %r15
	addq	-112(%rsp), %r15
	leal	16(%r12), %ebp
	movl	%ebp, -124(%rsp)
	jmp	.LBB86_6
.LBB86_5:
	movq	-120(%rsp), %r15
	leaq	8(%r15), %r12
	movq	%r12, -120(%rsp)
.LBB86_6:
	movsd	(%r15), %xmm0                   # xmm0 = mem[0],zero
	leal	(%rdi,%rsi,2), %esi
	leal	(%rdx,%rdx,2), %edx
	addl	%esi, %edx
	leal	(%rdx,%rcx,4), %ecx
	leal	(%r8,%r8,4), %edx
	addl	%ecx, %edx
	leal	(%r9,%r9,2), %ecx
	leal	(%rdx,%rcx,2), %ecx
	leal	(%rcx,%r14,8), %ecx
	subl	%r14d, %ecx
	leal	(%rcx,%rbx,8), %ecx
	leal	(%r11,%r11,8), %edx
	addl	%ecx, %edx
	leal	(%r10,%r10,4), %ecx
	leal	(%rdx,%rcx,2), %ecx
	leal	(%rax,%rax,4), %edx
	leal	(%rax,%rdx,2), %eax
	addl	%ecx, %eax
	cvtsi2sd	%eax, %xmm1
	mulsd	.LCPI86_0(%rip), %xmm0
	addsd	%xmm1, %xmm0
	addq	$80, %rsp
	.cfi_def_cfa_offset 48
	popq	%rbx
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end86:
	.size	abi_var_spill, .Lfunc_end86-abi_var_spill
	.cfi_endproc
                                        # -- End function
	.section	.rodata.cst4,"aM",@progbits,4
	.p2align	2, 0x0                          # -- Begin function abi_var_hfa
.LCPI87_0:
	.long	0x40400000                      # float 3
.LCPI87_1:
	.long	0x40800000                      # float 4
	.text
	.globl	abi_var_hfa
	.p2align	4
	.type	abi_var_hfa,@function
abi_var_hfa:                            # @abi_var_hfa
	.cfi_startproc
# %bb.0:
	subq	$88, %rsp
	.cfi_def_cfa_offset 96
	movq	%rdi, -96(%rsp)
	movq	%rsi, -88(%rsp)
	movq	%rdx, -80(%rsp)
	movq	%rcx, -72(%rsp)
	movq	%r8, -64(%rsp)
	movq	%r9, -56(%rsp)
	testb	%al, %al
	je	.LBB87_8
# %bb.7:
	movaps	%xmm1, -32(%rsp)
	movaps	%xmm2, -16(%rsp)
	movaps	%xmm3, (%rsp)
	movaps	%xmm4, 16(%rsp)
	movaps	%xmm5, 32(%rsp)
	movaps	%xmm6, 48(%rsp)
	movaps	%xmm7, 64(%rsp)
.LBB87_8:
	movabsq	$274877906944, %rax             # imm = 0x4000000000
	movq	%rax, -128(%rsp)
	leaq	-96(%rsp), %rax
	movq	%rax, -112(%rsp)
	leaq	96(%rsp), %rax
	movq	%rax, -120(%rsp)
	movl	-124(%rsp), %ecx
	cmpq	$160, %rcx
	ja	.LBB87_2
# %bb.1:
	movq	%rcx, %rax
	addq	-112(%rsp), %rax
	addl	$16, %ecx
	movl	%ecx, -124(%rsp)
	jmp	.LBB87_3
.LBB87_2:
	movq	-120(%rsp), %rax
	leaq	8(%rax), %rcx
	movq	%rcx, -120(%rsp)
.LBB87_3:
	movss	(%rax), %xmm2                   # xmm2 = mem[0],zero,zero,zero
	movss	4(%rax), %xmm1                  # xmm1 = mem[0],zero,zero,zero
	movl	-128(%rsp), %ecx
	cmpq	$40, %rcx
	ja	.LBB87_5
# %bb.4:
	movq	%rcx, %rax
	addq	-112(%rsp), %rax
	addl	$8, %ecx
	movl	%ecx, -128(%rsp)
	jmp	.LBB87_6
.LBB87_5:
	movq	-120(%rsp), %rax
	leaq	8(%rax), %rcx
	movq	%rcx, -120(%rsp)
.LBB87_6:
	movl	(%rax), %eax
	movaps	%xmm0, %xmm3
	shufps	$85, %xmm0, %xmm3               # xmm3 = xmm3[1,1],xmm0[1,1]
	addss	%xmm3, %xmm3
	addss	%xmm0, %xmm3
	mulss	.LCPI87_0(%rip), %xmm2
	addss	%xmm3, %xmm2
	mulss	.LCPI87_1(%rip), %xmm1
	addss	%xmm2, %xmm1
	leal	(%rax,%rax,4), %eax
	xorps	%xmm0, %xmm0
	cvtsi2ss	%eax, %xmm0
	addss	%xmm1, %xmm0
	cvtss2sd	%xmm0, %xmm0
	addq	$88, %rsp
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end87:
	.size	abi_var_hfa, .Lfunc_end87-abi_var_hfa
	.cfi_endproc
                                        # -- End function
	.globl	abi_struct                      # -- Begin function abi_struct
	.p2align	4
	.type	abi_struct,@function
abi_struct:                             # @abi_struct
	.cfi_startproc
# %bb.0:
	movsbq	40(%rsp), %rax
	movq	32(%rsp), %r10
	addq	%rsi, %rdi
	addq	%rcx, %rdx
	addq	%rdi, %rdx
	addq	%r9, %r8
	addq	%rdx, %r8
	addq	8(%rsp), %r8
	addq	16(%rsp), %r8
	movsbq	24(%rsp), %rcx
	movslq	%r10d, %rdx
	addq	%rcx, %rdx
	addq	%rax, %rdx
	shrq	$31, %r10
	movslq	%r10d, %rax
	andq	$-2, %rax
	addq	%rdx, %rax
	addq	%r8, %rax
	cvtsi2sd	%rax, %xmm0
	retq
.Lfunc_end88:
	.size	abi_struct, .Lfunc_end88-abi_struct
	.cfi_endproc
                                        # -- End function
	.globl	call_struct                     # -- Begin function call_struct
	.p2align	4
	.type	call_struct,@function
call_struct:                            # @call_struct
	.cfi_startproc
# %bb.0:
	pushq	%rax
	.cfi_def_cfa_offset 16
	movq	%rdi, %rax
	subq	$8, %rsp
	.cfi_adjust_cfa_offset 8
	movabsq	$47244640266, %r10              # imm = 0xB0000000A
	movl	$1, %edi
	movl	$2, %esi
	movl	$3, %edx
	movl	$4, %ecx
	movl	$5, %r8d
	movl	$6, %r9d
	pushq	$-12
	.cfi_adjust_cfa_offset 8
	pushq	%r10
	.cfi_adjust_cfa_offset 8
	pushq	$-9
	.cfi_adjust_cfa_offset 8
	pushq	$8
	.cfi_adjust_cfa_offset 8
	pushq	$7
	.cfi_adjust_cfa_offset 8
	callq	*%rax
	addq	$48, %rsp
	.cfi_adjust_cfa_offset -48
	popq	%rax
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end89:
	.size	call_struct, .Lfunc_end89-call_struct
	.cfi_endproc
                                        # -- End function
	.globl	abi_hfa_boundary                # -- Begin function abi_hfa_boundary
	.p2align	4
	.type	abi_hfa_boundary,@function
abi_hfa_boundary:                       # @abi_hfa_boundary
	.cfi_startproc
# %bb.0:
	addss	%xmm1, %xmm0
	addss	%xmm2, %xmm0
	addss	%xmm3, %xmm0
	addss	%xmm4, %xmm0
	addss	%xmm5, %xmm0
	addss	%xmm6, %xmm0
	addss	%xmm7, %xmm0
	shufps	$85, %xmm7, %xmm7               # xmm7 = xmm7[1,1,1,1]
	addss	%xmm7, %xmm7
	addss	%xmm0, %xmm7
	addss	8(%rsp), %xmm7
	xorps	%xmm0, %xmm0
	cvtss2sd	%xmm7, %xmm0
	retq
.Lfunc_end90:
	.size	abi_hfa_boundary, .Lfunc_end90-abi_hfa_boundary
	.cfi_endproc
                                        # -- End function
	.section	.rodata.cst16,"aM",@progbits,16
	.p2align	4, 0x0                          # -- Begin function call_hfa_boundary
.LCPI91_0:
	.long	0x41000000                      # float 8
	.long	0x41100000                      # float 9
	.zero	4
	.zero	4
.LCPI91_8:
	.long	0x41000000                      # float 8
	.long	0x41100000                      # float 9
	.long	0x00000000                      # float 0
	.long	0x00000000                      # float 0
	.section	.rodata.cst4,"aM",@progbits,4
	.p2align	2, 0x0
.LCPI91_1:
	.long	0x3f800000                      # float 1
.LCPI91_2:
	.long	0x40000000                      # float 2
.LCPI91_3:
	.long	0x40400000                      # float 3
.LCPI91_4:
	.long	0x40800000                      # float 4
.LCPI91_5:
	.long	0x40a00000                      # float 5
.LCPI91_6:
	.long	0x40c00000                      # float 6
.LCPI91_7:
	.long	0x40e00000                      # float 7
	.text
	.globl	call_hfa_boundary
	.p2align	4
	.type	call_hfa_boundary,@function
call_hfa_boundary:                      # @call_hfa_boundary
	.cfi_startproc
# %bb.0:
	pushq	%rax
	.cfi_def_cfa_offset 16
	movl	$1092616192, (%rsp)             # imm = 0x41200000
	movsd	.LCPI91_8(%rip), %xmm7          # xmm7 = [8.0E+0,9.0E+0,0.0E+0,0.0E+0]
	movss	.LCPI91_1(%rip), %xmm0          # xmm0 = [1.0E+0,0.0E+0,0.0E+0,0.0E+0]
	movss	.LCPI91_2(%rip), %xmm1          # xmm1 = [2.0E+0,0.0E+0,0.0E+0,0.0E+0]
	movss	.LCPI91_3(%rip), %xmm2          # xmm2 = [3.0E+0,0.0E+0,0.0E+0,0.0E+0]
	movss	.LCPI91_4(%rip), %xmm3          # xmm3 = [4.0E+0,0.0E+0,0.0E+0,0.0E+0]
	movss	.LCPI91_5(%rip), %xmm4          # xmm4 = [5.0E+0,0.0E+0,0.0E+0,0.0E+0]
	movss	.LCPI91_6(%rip), %xmm5          # xmm5 = [6.0E+0,0.0E+0,0.0E+0,0.0E+0]
	movss	.LCPI91_7(%rip), %xmm6          # xmm6 = [7.0E+0,0.0E+0,0.0E+0,0.0E+0]
	callq	*%rdi
	popq	%rax
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end91:
	.size	call_hfa_boundary, .Lfunc_end91-call_hfa_boundary
	.cfi_endproc
                                        # -- End function
	.section	.rodata.cst16,"aM",@progbits,16
	.p2align	4, 0x0                          # -- Begin function abi_array_hfa
.LCPI92_0:
	.long	0x41200000                      # float 10
	.long	0x41a00000                      # float 20
	.zero	4
	.zero	4
	.section	.rodata.cst4,"aM",@progbits,4
	.p2align	2, 0x0
.LCPI92_1:
	.long	0x41f00000                      # float 30
	.text
	.globl	abi_array_hfa
	.p2align	4
	.type	abi_array_hfa,@function
abi_array_hfa:                          # @abi_array_hfa
	.cfi_startproc
# %bb.0:
	addps	.LCPI92_0(%rip), %xmm0
	addss	.LCPI92_1(%rip), %xmm1
	retq
.Lfunc_end92:
	.size	abi_array_hfa, .Lfunc_end92-abi_array_hfa
	.cfi_endproc
                                        # -- End function
	.section	.rodata.cst16,"aM",@progbits,16
	.p2align	4, 0x0                          # -- Begin function call_array_hfa
.LCPI93_0:
	.long	0x3f800000                      # float 1
	.long	0x40000000                      # float 2
	.zero	4
	.zero	4
.LCPI93_2:
	.long	0x3f800000                      # float 1
	.long	0x40000000                      # float 2
	.long	0x00000000                      # float 0
	.long	0x00000000                      # float 0
	.section	.rodata.cst4,"aM",@progbits,4
	.p2align	2, 0x0
.LCPI93_1:
	.long	0x40400000                      # float 3
	.text
	.globl	call_array_hfa
	.p2align	4
	.type	call_array_hfa,@function
call_array_hfa:                         # @call_array_hfa
	.cfi_startproc
# %bb.0:
	pushq	%rax
	.cfi_def_cfa_offset 16
	movsd	.LCPI93_2(%rip), %xmm0          # xmm0 = [1.0E+0,2.0E+0,0.0E+0,0.0E+0]
	movss	.LCPI93_1(%rip), %xmm1          # xmm1 = [3.0E+0,0.0E+0,0.0E+0,0.0E+0]
	callq	*%rdi
	movaps	%xmm0, %xmm2
	shufps	$85, %xmm0, %xmm2               # xmm2 = xmm2[1,1],xmm0[1,1]
	addss	%xmm2, %xmm2
	addss	%xmm0, %xmm2
	mulss	.LCPI93_1(%rip), %xmm1
	addss	%xmm2, %xmm1
	xorps	%xmm0, %xmm0
	cvtss2sd	%xmm1, %xmm0
	popq	%rax
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end93:
	.size	call_array_hfa, .Lfunc_end93-call_array_hfa
	.cfi_endproc
                                        # -- End function
	.section	.rodata.cst4,"aM",@progbits,4
	.p2align	2, 0x0                          # -- Begin function abi_var_array
.LCPI94_0:
	.long	0x40400000                      # float 3
	.text
	.globl	abi_var_array
	.p2align	4
	.type	abi_var_array,@function
abi_var_array:                          # @abi_var_array
	.cfi_startproc
# %bb.0:
	subq	$104, %rsp
	.cfi_def_cfa_offset 112
	movq	%rsi, -72(%rsp)
	movq	%rdx, -64(%rsp)
	movq	%rcx, -56(%rsp)
	movq	%r8, -48(%rsp)
	movq	%r9, -40(%rsp)
	testb	%al, %al
	je	.LBB94_8
# %bb.7:
	movaps	%xmm0, -32(%rsp)
	movaps	%xmm1, -16(%rsp)
	movaps	%xmm2, (%rsp)
	movaps	%xmm3, 16(%rsp)
	movaps	%xmm4, 32(%rsp)
	movaps	%xmm5, 48(%rsp)
	movaps	%xmm6, 64(%rsp)
	movaps	%xmm7, 80(%rsp)
.LBB94_8:
	movabsq	$206158430216, %rax             # imm = 0x3000000008
	movq	%rax, -128(%rsp)
	leaq	-80(%rsp), %rax
	movq	%rax, -112(%rsp)
	leaq	112(%rsp), %rax
	movq	%rax, -120(%rsp)
	movl	-124(%rsp), %eax
	cmpq	$144, %rax
	ja	.LBB94_2
# %bb.1:
	movq	-112(%rsp), %rcx
	movsd	(%rcx,%rax), %xmm1              # xmm1 = mem[0],zero
	movsd	%xmm1, -96(%rsp)
	movss	16(%rcx,%rax), %xmm0            # xmm0 = mem[0],zero,zero,zero
	movss	%xmm0, -88(%rsp)
	addl	$32, %eax
	movl	%eax, -124(%rsp)
	leaq	-96(%rsp), %rcx
	jmp	.LBB94_3
.LBB94_2:
	movq	-120(%rsp), %rcx
	leaq	16(%rcx), %rdx
	movq	%rdx, -120(%rsp)
	movss	(%rcx), %xmm1                   # xmm1 = mem[0],zero,zero,zero
	movss	8(%rcx), %xmm0                  # xmm0 = mem[0],zero,zero,zero
.LBB94_3:
	movss	4(%rcx), %xmm2                  # xmm2 = mem[0],zero,zero,zero
	cmpl	$160, %eax
	ja	.LBB94_5
# %bb.4:
	movl	%eax, %ecx
	addq	-112(%rsp), %rcx
	addl	$16, %eax
	movl	%eax, -124(%rsp)
	jmp	.LBB94_6
.LBB94_5:
	movq	-120(%rsp), %rcx
	leaq	8(%rcx), %rax
	movq	%rax, -120(%rsp)
.LBB94_6:
	xorps	%xmm3, %xmm3
	cvtsi2ss	%edi, %xmm3
	addss	%xmm3, %xmm1
	addss	%xmm2, %xmm2
	mulss	.LCPI94_0(%rip), %xmm0
	addss	%xmm1, %xmm2
	addss	%xmm2, %xmm0
	cvtss2sd	%xmm0, %xmm0
	addsd	(%rcx), %xmm0
	addq	$104, %rsp
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end94:
	.size	abi_var_array, .Lfunc_end94-abi_var_array
	.cfi_endproc
                                        # -- End function
	.globl	abi_int_boundary                # -- Begin function abi_int_boundary
	.p2align	4
	.type	abi_int_boundary,@function
abi_int_boundary:                       # @abi_int_boundary
	.cfi_startproc
# %bb.0:
	addq	%rsi, %rdi
	addq	%rcx, %rdx
	addq	%rdi, %rdx
	addq	%r9, %r8
	addq	%rdx, %r8
	addq	8(%rsp), %r8
	movq	24(%rsp), %rax
	addq	32(%rsp), %r8
	addq	16(%rsp), %r8
	leaq	(%r8,%rax,2), %rax
	cvtsi2sd	%rax, %xmm0
	retq
.Lfunc_end95:
	.size	abi_int_boundary, .Lfunc_end95-abi_int_boundary
	.cfi_endproc
                                        # -- End function
	.globl	call_int_boundary               # -- Begin function call_int_boundary
	.p2align	4
	.type	call_int_boundary,@function
call_int_boundary:                      # @call_int_boundary
	.cfi_startproc
# %bb.0:
	subq	$56, %rsp
	.cfi_def_cfa_offset 64
	movq	%rdi, %rax
	movq	$8, 40(%rsp)
	movq	$9, 48(%rsp)
	movups	40(%rsp), %xmm0
	movups	%xmm0, 8(%rsp)
	movq	$10, 24(%rsp)
	movq	$7, (%rsp)
	movl	$1, %edi
	movl	$2, %esi
	movl	$3, %edx
	movl	$4, %ecx
	movl	$5, %r8d
	movl	$6, %r9d
	callq	*%rax
	addq	$56, %rsp
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end96:
	.size	call_int_boundary, .Lfunc_end96-call_int_boundary
	.cfi_endproc
                                        # -- End function
	.globl	abi_hfa_stack                   # -- Begin function abi_hfa_stack
	.p2align	4
	.type	abi_hfa_stack,@function
abi_hfa_stack:                          # @abi_hfa_stack
	.cfi_startproc
# %bb.0:
	addq	%rsi, %rdi
	addq	%rcx, %rdx
	addq	%rdi, %rdx
	addq	%r9, %r8
	addq	%rdx, %r8
	addq	8(%rsp), %r8
	addq	16(%rsp), %r8
	cvtsi2ss	%r8, %xmm8
	movsbl	24(%rsp), %eax
	movss	36(%rsp), %xmm9                 # xmm9 = mem[0],zero,zero,zero
	addss	%xmm0, %xmm8
	addss	%xmm1, %xmm8
	addss	%xmm2, %xmm8
	addss	%xmm3, %xmm8
	addss	%xmm4, %xmm8
	addss	%xmm5, %xmm8
	addss	%xmm6, %xmm8
	xorps	%xmm0, %xmm0
	cvtsi2ss	%eax, %xmm0
	addss	%xmm7, %xmm8
	addss	%xmm8, %xmm0
	addss	32(%rsp), %xmm0
	addss	%xmm9, %xmm9
	addss	%xmm0, %xmm9
	addss	40(%rsp), %xmm9
	xorps	%xmm0, %xmm0
	cvtss2sd	%xmm9, %xmm0
	retq
.Lfunc_end97:
	.size	abi_hfa_stack, .Lfunc_end97-abi_hfa_stack
	.cfi_endproc
                                        # -- End function
	.globl	abi_call_int                    # -- Begin function abi_call_int
	.p2align	4
	.type	abi_call_int,@function
abi_call_int:                           # @abi_call_int
	.cfi_startproc
# %bb.0:
	movq	%rdi, %rax
	movl	%esi, %edi
	jmpq	*%rax                           # TAILCALL
.Lfunc_end98:
	.size	abi_call_int, .Lfunc_end98-abi_call_int
	.cfi_endproc
                                        # -- End function
	.section	.rodata.cst16,"aM",@progbits,16
	.p2align	4, 0x0                          # -- Begin function abi_pointer_gc
.LCPI99_0:
	.zero	16,90
.LCPI99_1:
	.byte	165                             # 0xa5
	.byte	90                              # 0x5a
	.byte	90                              # 0x5a
	.byte	90                              # 0x5a
	.byte	90                              # 0x5a
	.byte	90                              # 0x5a
	.byte	90                              # 0x5a
	.byte	90                              # 0x5a
	.byte	90                              # 0x5a
	.byte	90                              # 0x5a
	.byte	90                              # 0x5a
	.byte	90                              # 0x5a
	.byte	90                              # 0x5a
	.byte	90                              # 0x5a
	.byte	90                              # 0x5a
	.byte	90                              # 0x5a
	.text
	.globl	abi_pointer_gc
	.p2align	4
	.type	abi_pointer_gc,@function
abi_pointer_gc:                         # @abi_pointer_gc
	.cfi_startproc
# %bb.0:
	subq	$40, %rsp
	.cfi_def_cfa_offset 48
	movq	%rdi, %rax
	movaps	.LCPI99_0(%rip), %xmm0          # xmm0 = [90,90,90,90,90,90,90,90,90,90,90,90,90,90,90,90]
	movaps	%xmm0, 16(%rsp)
	movaps	%xmm0, (%rsp)
	movq	%rsp, %rdi
	callq	*%rax
	movdqa	(%rsp), %xmm0
	movdqa	.LCPI99_0(%rip), %xmm1          # xmm1 = [90,90,90,90,90,90,90,90,90,90,90,90,90,90,90,90]
	pcmpeqb	16(%rsp), %xmm1
	pcmpeqb	.LCPI99_1(%rip), %xmm0
	pand	%xmm1, %xmm0
	pmovmskb	%xmm0, %ecx
	xorl	%eax, %eax
	xorl	$65535, %ecx                    # imm = 0xFFFF
	sete	%al
	addq	$40, %rsp
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end99:
	.size	abi_pointer_gc, .Lfunc_end99-abi_pointer_gc
	.cfi_endproc
                                        # -- End function
	.globl	ffi_uint_callback               # -- Begin function ffi_uint_callback
	.p2align	4
	.type	ffi_uint_callback,@function
ffi_uint_callback:                      # @ffi_uint_callback
	.cfi_startproc
# %bb.0:
	pushq	%rax
	.cfi_def_cfa_offset 16
	movq	%rdi, %rax
	xorl	%edi, %edi
	xorl	%esi, %esi
	xorl	%edx, %edx
	xorl	%ecx, %ecx
	xorl	%r8d, %r8d
	xorl	%r9d, %r9d
	pushq	$-1294967296                    # imm = 0xB2D05E00
	.cfi_adjust_cfa_offset 8
	pushq	$0
	.cfi_adjust_cfa_offset 8
	callq	*%rax
	addq	$16, %rsp
	.cfi_adjust_cfa_offset -16
	popq	%rcx
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end100:
	.size	ffi_uint_callback, .Lfunc_end100-ffi_uint_callback
	.cfi_endproc
                                        # -- End function
	.section	.rodata.cst16,"aM",@progbits,16
	.p2align	4, 0x0                          # -- Begin function ffi_array_struct
.LCPI101_0:
	.long	0x41200000                      # float 10
	.long	0x41a00000                      # float 20
	.zero	4
	.zero	4
	.section	.rodata.cst4,"aM",@progbits,4
	.p2align	2, 0x0
.LCPI101_1:
	.long	0x41f00000                      # float 30
	.text
	.globl	ffi_array_struct
	.p2align	4
	.type	ffi_array_struct,@function
ffi_array_struct:                       # @ffi_array_struct
	.cfi_startproc
# %bb.0:
	addps	.LCPI101_0(%rip), %xmm0
	addss	.LCPI101_1(%rip), %xmm1
	retq
.Lfunc_end101:
	.size	ffi_array_struct, .Lfunc_end101-ffi_array_struct
	.cfi_endproc
                                        # -- End function
	.globl	ffi_fp_divide                   # -- Begin function ffi_fp_divide
	.p2align	4
	.type	ffi_fp_divide,@function
ffi_fp_divide:                          # @ffi_fp_divide
	.cfi_startproc
# %bb.0:
	movsd	%xmm0, -8(%rsp)
	movsd	%xmm1, -16(%rsp)
	movsd	-8(%rsp), %xmm0                 # xmm0 = mem[0],zero
	divsd	-16(%rsp), %xmm0
	retq
.Lfunc_end102:
	.size	ffi_fp_divide, .Lfunc_end102-ffi_fp_divide
	.cfi_endproc
                                        # -- End function
	.type	.L.str,@object                  # @.str
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str:
	.asciz	"foo"
	.size	.L.str, 4

	.type	.L.str.1,@object                # @.str.1
.L.str.1:
	.asciz	"bar"
	.size	.L.str.1, 4

	.type	global_var,@object              # @global_var
	.local	global_var
	.comm	global_var,4,4
	.type	.L.str.2,@object                # @.str.2
.L.str.2:
	.asciz	"a == b"
	.size	.L.str.2, 7

	.type	.L.str.3,@object                # @.str.3
.L.str.3:
	.asciz	"vm/ffi_test.c"
	.size	.L.str.3, 14

	.type	.L__PRETTY_FUNCTION__.ffi_test_39,@object # @__PRETTY_FUNCTION__.ffi_test_39
.L__PRETTY_FUNCTION__.ffi_test_39:
	.asciz	"int ffi_test_39(long, long, struct test_struct_13)"
	.size	.L__PRETTY_FUNCTION__.ffi_test_39, 51

	.ident	"Ubuntu clang version 21.1.8 (6ubuntu1)"
	.section	".note.GNU-stack","",@progbits
	.addrsig
