	.file	"ffi_fp_status.c"
	.text
	.globl	ffi_fp_divide                   # -- Begin function ffi_fp_divide
	.p2align	4
	.type	ffi_fp_divide,@function
ffi_fp_divide:                          # @ffi_fp_divide
	.cfi_startproc
# %bb.0:
	movsd	%xmm0, -8(%rsp)
	movsd	%xmm1, -16(%rsp)
	movsd	-8(%rsp), %xmm0                 # xmm0 = mem[0],zero
	divsd	-16(%rsp), %xmm0
	retq
.Lfunc_end0:
	.size	ffi_fp_divide, .Lfunc_end0-ffi_fp_divide
	.cfi_endproc
                                        # -- End function
	.ident	"Ubuntu clang version 21.1.8 (6ubuntu1)"
	.section	".note.GNU-stack","",@progbits
	.addrsig
