int ffi_test_small_floats_available(void) { return 0; }
