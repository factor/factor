	.file	"ffi_array_struct.c"
	.section	.rodata.cst16,"aM",@progbits,16
	.p2align	4, 0x0                          # -- Begin function ffi_array_struct
.LCPI0_0:
	.long	0x41200000                      # float 10
	.long	0x41a00000                      # float 20
	.zero	4
	.zero	4
	.section	.rodata.cst4,"aM",@progbits,4
	.p2align	2, 0x0
.LCPI0_1:
	.long	0x41f00000                      # float 30
	.text
	.globl	ffi_array_struct
	.p2align	4
	.type	ffi_array_struct,@function
ffi_array_struct:                       # @ffi_array_struct
	.cfi_startproc
# %bb.0:
	addps	.LCPI0_0(%rip), %xmm0
	addss	.LCPI0_1(%rip), %xmm1
	retq
.Lfunc_end0:
	.size	ffi_array_struct, .Lfunc_end0-ffi_array_struct
	.cfi_endproc
                                        # -- End function
	.ident	"Ubuntu clang version 21.1.8 (6ubuntu1)"
	.section	".note.GNU-stack","",@progbits
	.addrsig
