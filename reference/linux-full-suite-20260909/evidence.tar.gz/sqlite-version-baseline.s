
/home/sheeple/factor-workspaces/all-20260909/validation/sqlite-optional/baseline.so:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .plt.got:

Disassembly of section .text:

0000000000026b90 <sqlite3_libversion>:
   26b90:	48 8b 05 29 34 15 00 	mov    0x153429(%rip),%rax        # 179fc0 <sqlite3_version@@Base+0x33ef8>
   26b97:	c3                   	ret

Disassembly of section .fini:
