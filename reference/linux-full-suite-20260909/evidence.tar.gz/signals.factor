USING: assocs compiler.errors debugger io kernel namespaces parser
sequences system tools.test vocabs.hierarchy ;
f restartable-tests? set-global
auto-use? off
"unix.signals" [ load ] [ test ] bi
:test-failures
compiler-errors get values [ print-error ] each
test-failures get empty? compiler-errors get assoc-empty? and 0 1 ? exit
