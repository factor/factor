from pathlib import Path
import hashlib,json,os,re,subprocess,tarfile,io
root=Path('/home/sheeple/factor');r=Path('/home/sheeple/factor-workspaces/all-20260909');v=r/'validation';out=root/'reference/linux-full-suite-20260909';out.mkdir(exist_ok=True)
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1<<20),b''):h.update(b)
 return h.hexdigest()
def git(path,*args):return subprocess.check_output(['git',*args],cwd=path)
results={}
for name in ['source-boot','bootstrap','load-all-initial','load-all','load-all-final','test-all','test-all-final','targeted','signals','sqlite-optional','sqlite-loaded-image']:
 p=v/(name+'.json')
 if p.exists():results[name]=json.loads(p.read_text())
for name in ['test-all','test-all-final']:
 lines=(v/(name+'.log')).read_text(errors='replace').splitlines()
 files=[s.removeprefix('TEST-FILE ') for s in lines if s.startswith('TEST-FILE ')]
 results[name]['test_file_events']=len(files);results[name]['unique_test_files']=len(set(files))
 results[name]['reported_totals']=[s for s in lines if s.startswith(('TEST FAILURES ','COMPILER ERRORS '))]
 results[name]['skips']=sorted(set(s for s in lines if s.startswith(('FFI-SKIP','FILE-PICKER-SKIP','Skipping '))))
assert results['test-all-final']['status']==0,'Full suite is not passing'
assert results['load-all-final']['status']==0
paths=git(r,'diff','--name-only','HEAD').decode().splitlines()+git(r,'ls-files','--others','--exclude-standard').decode().splitlines()
paths=sorted(set(p for p in paths if not p.startswith('validation/')))
for p in paths:assert (root/p).read_bytes()==(r/p).read_bytes(),p
manifest={'baseline_commit':git(r,'rev-parse','HEAD').decode().strip(),'candidate_commit':git(root,'rev-parse','HEAD').decode().strip(),'source_patch':'candidate.patch (inside evidence archive)','changed_source_sha256':{p:sha(r/p) for p in paths},'artifacts':{p:sha(r/p) for p in ['factor','libfactor.a','factor.image','loaded.image','loaded-final.image','gtk2.image','boot.unix-x86.64.image','libfactor-ffi-test.so']},'runtime_provenance':json.loads((v/'provenance.json').read_text()),'runtime_dependency_sha256':{str(p.relative_to(v)):sha(p) for p in (v/'libraries').rglob('*') if p.is_file()},'environment':{'DISPLAY':':109','TMPDIR':'/home/sheeple/fa-tmp-0909','XDG_CACHE_HOME':'/home/sheeple/fa-cache-0909','FACTOR_GUI_TEST_IMAGE':str(r/'factor.image')},'process_exits':{p.name:int(p.read_text()) for p in v.glob('*.exit')},'controls_sha256':{str(p.relative_to(v)):sha(p) for p in v.rglob('*') if p.is_file() and (p.suffix in ['.c','.h','.so','.s'] or p.name.endswith('.deb')) and not any(part in ['libraries','headers','postgres'] for part in p.relative_to(v).parts)}}
(out/'results.json').write_text(json.dumps(results,indent=2)+'\n');(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
secrets={k:value.encode() for k,value in os.environ.items() if re.search(r'token|secret|password|api.?key|credential',k,re.I) and len(value)>=8};redactions={}
def redact(data):
 for key,value in secrets.items():
  count=data.count(value)
  if count:data=data.replace(value,('[REDACTED:'+key+']').encode());redactions[key]=redactions.get(key,0)+count
 return data
with tarfile.open(out/'evidence.tar.gz','w:gz') as archive:
 def add_bytes(name,data):
  info=tarfile.TarInfo(name);info.size=len(data);archive.addfile(info,io.BytesIO(data))
 for p in sorted(v.rglob('*')):
  rel=p.relative_to(v)
  if not p.is_file() or any(part in ['libraries','headers','packages','postgres','pgsock','terminfo','__pycache__'] for part in rel.parts):continue
  if p.suffix in ['.log','.json','.exit','.factor','.py','.c','.h','.s']:
   add_bytes(str(rel),redact(p.read_bytes()))
 for p in paths:add_bytes('candidate-source/'+p,(r/p).read_bytes())
 add_bytes('candidate.patch',git(r,'diff','--binary','HEAD'))
 for source in ['extra/curl/ffi/ffi.factor','extra/lua/lua.factor','basis/db/sqlite/ffi/release-tests/release-tests.factor','basis/compiler/cfg/intrinsics/simd/simd-tests.factor','basis/unix/signals/signals-tests.factor','extra/git/git-tests.factor','extra/file-picker/linux/linux-tests.factor','extra/curses/ffi/native/headless.factor']:
  add_bytes('baseline-source/'+source,git(r,'show','HEAD:'+source))
 add_bytes('package-full-suite.py',Path(__file__).read_bytes())
(out/'redactions.json').write_text(json.dumps(redactions,indent=2)+'\n')
(out/'SHA256SUMS').write_text(''.join(sha(p)+'  '+p.name+'\n' for p in sorted(out.iterdir()) if p.is_file() and p.name!='SHA256SUMS'))
print('Packaged',out)
