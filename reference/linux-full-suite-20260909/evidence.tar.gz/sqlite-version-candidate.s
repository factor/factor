
/home/sheeple/factor-workspaces/all-20260909/validation/sqlite-optional/libsqlite3-optional.so:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .plt.got:

Disassembly of section .text:

0000000000025670 <sqlite3_libversion>:
   25670:	48 8d 05 51 ea 11 00 	lea    0x11ea51(%rip),%rax        # 1440c8 <sqlite3_version>
   25677:	c3                   	ret

Disassembly of section .fini:
