	.file	"loader.c"
	.text
	.section	.rodata.str1.1,"aMS",@progbits,1
.LC0:
	.string	"libsqlite3.so.0"
.LC1:
	.string	"%s\n"
.LC2:
	.string	"sqlite3_libversion"
	.section	.rodata.str1.8,"aMS",@progbits,1
	.align 8
.LC3:
	.string	"SQLite fixture version with system SQLite loaded: %s\n"
	.section	.rodata.str1.1
.LC4:
	.string	"3.53.4"
	.section	.text.startup,"ax",@progbits
	.p2align 4
	.globl	main
	.type	main, @function
main:
.LFB38:
	.cfi_startproc
	endbr64
	movl	$2, %edx
	cmpl	$2, %edi
	je	.L14
	movl	%edx, %eax
	ret
.L14:
	pushq	%r14
	.cfi_def_cfa_offset 16
	.cfi_offset 14, -16
	leaq	.LC0(%rip), %rdi
	pushq	%rbx
	.cfi_def_cfa_offset 24
	.cfi_offset 3, -24
	subq	$24, %rsp
	.cfi_def_cfa_offset 48
	movq	%rsi, 8(%rsp)
	movl	$258, %esi
	call	dlopen@PLT
	movq	8(%rsp), %rdx
	movl	$2, %esi
	movq	%rax, %rbx
	movq	8(%rdx), %rdi
	call	dlopen@PLT
	movq	%rax, %r14
	testq	%rbx, %rbx
	je	.L8
	testq	%rax, %rax
	je	.L8
	leaq	.LC2(%rip), %rsi
	movq	%rax, %rdi
	call	dlsym@PLT
	testq	%rax, %rax
	je	.L5
	movq	%rax, 8(%rsp)
	call	*%rax
	leaq	.LC3(%rip), %rsi
	movl	$2, %edi
	movq	%rax, %rdx
	xorl	%eax, %eax
	call	__printf_chk@PLT
	call	*8(%rsp)
	leaq	.LC4(%rip), %rsi
	movq	%rax, %rdi
	call	strcmp@PLT
	xorl	%edx, %edx
	movq	%r14, %rdi
	testl	%eax, %eax
	setne	%dl
	movl	%edx, 8(%rsp)
	call	dlclose@PLT
	movq	%rbx, %rdi
	call	dlclose@PLT
	movl	8(%rsp), %edx
.L1:
	addq	$24, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 24
	movl	%edx, %eax
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	ret
.L8:
	.cfi_restore_state
	call	dlerror@PLT
	movq	stderr(%rip), %rdi
	movl	$2, %esi
	leaq	.LC1(%rip), %rdx
	movq	%rax, %rcx
	xorl	%eax, %eax
	call	__fprintf_chk@PLT
.L5:
	movl	$1, %edx
	jmp	.L1
	.cfi_endproc
.LFE38:
	.size	main, .-main
	.ident	"GCC: (Ubuntu 15.2.0-16ubuntu1) 15.2.0"
	.section	.note.GNU-stack,"",@progbits
	.section	.note.gnu.property,"a"
	.align 8
	.long	1f - 0f
	.long	4f - 1f
	.long	5
0:
	.string	"GNU"
1:
	.align 8
	.long	0xc0000002
	.long	3f - 2f
2:
	.long	0x3
3:
	.align 8
4:
