	.file	"library-controls.c"
	.section	.rodata.cst8,"aM",@progbits,8
	.p2align	3, 0x0                          # -- Begin function main
.LCPI0_0:
	.quad	0x4004000000000000              # double 2.5
	.text
	.globl	main
	.p2align	4
	.type	main,@function
main:                                   # @main
	.cfi_startproc
# %bb.0:
	pushq	%r14
	.cfi_def_cfa_offset 16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	pushq	%rax
	.cfi_def_cfa_offset 32
	.cfi_offset %rbx, -24
	.cfi_offset %r14, -16
	callq	curl_easy_init@PLT
	movl	$1, %ebx
	testq	%rax, %rax
	je	.LBB0_10
# %bb.1:
	movq	%rax, %r14
	movq	%rax, %rdi
	movl	$78, %esi
	movq	$-1, %rdx
	xorl	%eax, %eax
	callq	curl_easy_setopt@PLT
	cmpl	$43, %eax
	jne	.LBB0_10
# %bb.2:
	movq	%r14, %rdi
	movl	$30146, %esi                    # imm = 0x75C2
	movq	$-1, %rdx
	xorl	%eax, %eax
	callq	curl_easy_setopt@PLT
	cmpl	$43, %eax
	jne	.LBB0_10
# %bb.3:
	leaq	.L.str(%rip), %rdx
	movq	%r14, %rdi
	movl	$10002, %esi                    # imm = 0x2712
	xorl	%eax, %eax
	callq	curl_easy_setopt@PLT
	testl	%eax, %eax
	jne	.LBB0_10
# %bb.4:
	movq	$0, (%rsp)
	movq	%rsp, %rdx
	movq	%r14, %rdi
	movl	$1048577, %esi                  # imm = 0x100001
	xorl	%eax, %eax
	callq	curl_easy_getinfo@PLT
	movl	$1, %ebx
	testl	%eax, %eax
	jne	.LBB0_10
# %bb.5:
	movq	(%rsp), %rdi
	leaq	.L.str(%rip), %rsi
	callq	strcmp@PLT
	testl	%eax, %eax
	je	.LBB0_6
.LBB0_10:
	movl	%ebx, %eax
	addq	$8, %rsp
	.cfi_def_cfa_offset 24
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	retq
.LBB0_6:
	.cfi_def_cfa_offset 32
	movq	%r14, %rdi
	callq	curl_easy_cleanup@PLT
	callq	luaL_newstate@PLT
	testq	%rax, %rax
	je	.LBB0_10
# %bb.7:
	movq	%rax, %r14
	leaq	.L.str.1(%rip), %rsi
	leaq	.L.str.2(%rip), %rdx
	movsd	.LCPI0_0(%rip), %xmm0           # xmm0 = [2.5E+0,0.0E+0]
	movq	%rax, %rdi
	movl	$-37, %ecx
	movl	$90, %r8d
	movb	$1, %al
	callq	lua_pushfstring@PLT
	leaq	.L.str.3(%rip), %rsi
	movq	%rax, %rdi
	callq	strcmp@PLT
	testl	%eax, %eax
	jne	.LBB0_10
# %bb.8:
	movq	%r14, %rdi
	callq	lua_gettop@PLT
	cmpl	$1, %eax
	jne	.LBB0_10
# %bb.9:
	movq	%r14, %rdi
	callq	lua_close@PLT
	leaq	.L.str.4(%rip), %rdi
	callq	puts@PLT
	xorl	%ebx, %ebx
	jmp	.LBB0_10
.Lfunc_end0:
	.size	main, .Lfunc_end0-main
	.cfi_endproc
                                        # -- End function
	.type	.L.str,@object                  # @.str
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str:
	.asciz	"https://example.invalid/no-transfer"
	.size	.L.str, 36

	.type	.L.str.1,@object                # @.str.1
.L.str.1:
	.asciz	"%s/%d/%f/%c/%%"
	.size	.L.str.1, 15

	.type	.L.str.2,@object                # @.str.2
.L.str.2:
	.asciz	"lua"
	.size	.L.str.2, 4

	.type	.L.str.3,@object                # @.str.3
.L.str.3:
	.asciz	"lua/-37/2.5/Z/%"
	.size	.L.str.3, 16

	.type	.L.str.4,@object                # @.str.4
.L.str.4:
	.asciz	"C controls: curl local options and Lua 5.1 variadic formatting passed"
	.size	.L.str.4, 70

	.ident	"Ubuntu clang version 21.1.8 (6ubuntu1)"
	.section	".note.GNU-stack","",@progbits
	.addrsig
