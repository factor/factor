USING: assocs compiler.errors debugger io kernel namespaces parser sequences system tools.test vocabs ;
f restartable-tests? set-global
auto-use? off
"curl.ffi" require
"/home/sheeple/factor-workspaces/all-20260909/validation/curl.ffi-baseline.factor" run-file
"/home/sheeple/factor-workspaces/all-20260909/extra/curl/ffi/ffi-tests.factor" run-test-file
:test-failures
compiler-errors get values [ print-error ] each
test-failures get empty? compiler-errors get assoc-empty? and 0 1 ? exit
