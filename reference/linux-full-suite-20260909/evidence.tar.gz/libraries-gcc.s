	.file	"library-controls.c"
	.text
	.section	.rodata.str1.8,"aMS",@progbits,1
	.align 8
.LC0:
	.string	"https://example.invalid/no-transfer"
	.section	.rodata.str1.1,"aMS",@progbits,1
.LC2:
	.string	"lua"
.LC3:
	.string	"%s/%d/%f/%c/%%"
.LC4:
	.string	"lua/-37/2.5/Z/%"
	.section	.rodata.str1.8
	.align 8
.LC5:
	.string	"C controls: curl local options and Lua 5.1 variadic formatting passed"
	.section	.text.startup,"ax",@progbits
	.p2align 4
	.globl	main
	.type	main, @function
main:
.LFB99:
	.cfi_startproc
	endbr64
	pushq	%rbx
	.cfi_def_cfa_offset 16
	.cfi_offset 3, -16
	subq	$32, %rsp
	.cfi_def_cfa_offset 48
	movq	%fs:40, %rax
	movq	%rax, 24(%rsp)
	xorl	%eax, %eax
	call	curl_easy_init@PLT
	testq	%rax, %rax
	je	.L4
	movq	%rax, %rbx
	movq	%rax, %rdi
	movl	$78, %esi
	xorl	%eax, %eax
	movq	$-1, %rdx
	call	curl_easy_setopt@PLT
	cmpl	$43, %eax
	je	.L11
.L4:
	movl	$1, %ebx
.L1:
	movq	24(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L12
	addq	$32, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 16
	movl	%ebx, %eax
	popq	%rbx
	.cfi_def_cfa_offset 8
	ret
.L11:
	.cfi_restore_state
	xorl	%eax, %eax
	movq	$-1, %rdx
	movl	$30146, %esi
	movq	%rbx, %rdi
	call	curl_easy_setopt@PLT
	cmpl	$43, %eax
	jne	.L4
	xorl	%eax, %eax
	leaq	.LC0(%rip), %rdx
	movl	$10002, %esi
	movq	%rbx, %rdi
	call	curl_easy_setopt@PLT
	testl	%eax, %eax
	jne	.L4
	xorl	%edx, %edx
	movl	$1048577, %esi
	movq	%rbx, %rdi
	movq	%rdx, 16(%rsp)
	leaq	16(%rsp), %rdx
	call	curl_easy_getinfo@PLT
	testl	%eax, %eax
	jne	.L4
	movq	16(%rsp), %rdi
	leaq	.LC0(%rip), %rsi
	call	strcmp@PLT
	testl	%eax, %eax
	jne	.L4
	movq	%rbx, %rdi
	call	curl_easy_cleanup@PLT
	call	luaL_newstate@PLT
	testq	%rax, %rax
	je	.L4
	movsd	.LC1(%rip), %xmm0
	movq	%rax, %rdi
	movq	%rax, 8(%rsp)
	movl	$90, %r8d
	movl	$-37, %ecx
	leaq	.LC2(%rip), %rdx
	movl	$1, %eax
	leaq	.LC3(%rip), %rsi
	call	lua_pushfstring@PLT
	leaq	.LC4(%rip), %rsi
	movq	%rax, %rdi
	call	strcmp@PLT
	movl	%eax, %ebx
	testl	%eax, %eax
	jne	.L4
	movq	8(%rsp), %rdi
	call	lua_gettop@PLT
	subl	$1, %eax
	jne	.L4
	movq	8(%rsp), %rdi
	call	lua_close@PLT
	leaq	.LC5(%rip), %rdi
	call	puts@PLT
	jmp	.L1
.L12:
	call	__stack_chk_fail@PLT
	.cfi_endproc
.LFE99:
	.size	main, .-main
	.section	.rodata.cst8,"aM",@progbits,8
	.align 8
.LC1:
	.long	0
	.long	1074003968
	.ident	"GCC: (Ubuntu 15.2.0-16ubuntu1) 15.2.0"
	.section	.note.GNU-stack,"",@progbits
	.section	.note.gnu.property,"a"
	.align 8
	.long	1f - 0f
	.long	4f - 1f
	.long	5
0:
	.string	"GNU"
1:
	.align 8
	.long	0xc0000002
	.long	3f - 2f
2:
	.long	0x3
3:
	.align 8
4:
