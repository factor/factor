	.file	"loader.c"
	.text
	.globl	main                            # -- Begin function main
	.p2align	4
	.type	main,@function
main:                                   # @main
	.cfi_startproc
# %bb.0:
	movl	$2, %eax
	cmpl	$2, %edi
	jne	.LBB0_7
# %bb.1:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%rbx
	.cfi_def_cfa_offset 40
	pushq	%rax
	.cfi_def_cfa_offset 48
	.cfi_offset %rbx, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	movq	%rsi, %r14
	leaq	.L.str(%rip), %rdi
	movl	$258, %esi                      # imm = 0x102
	callq	dlopen@PLT
	movq	%rax, %rbx
	movq	8(%r14), %rdi
	movl	$2, %esi
	callq	dlopen@PLT
	testq	%rbx, %rbx
	je	.LBB0_8
# %bb.2:
	movq	%rax, %r14
	testq	%rax, %rax
	je	.LBB0_8
# %bb.3:
	leaq	.L.str.2(%rip), %rsi
	movq	%r14, %rdi
	callq	dlsym@PLT
	testq	%rax, %rax
	je	.LBB0_5
# %bb.4:
	movq	%rax, %r15
	callq	*%rax
	leaq	.L.str.3(%rip), %rdi
	movq	%rax, %rsi
	xorl	%eax, %eax
	callq	printf@PLT
	callq	*%r15
	leaq	.L.str.4(%rip), %rsi
	movq	%rax, %rdi
	callq	strcmp@PLT
	xorl	%ebp, %ebp
	testl	%eax, %eax
	setne	%bpl
	movq	%r14, %rdi
	callq	dlclose@PLT
	movq	%rbx, %rdi
	callq	dlclose@PLT
	movl	%ebp, %eax
	jmp	.LBB0_6
.LBB0_8:
	movq	stderr@GOTPCREL(%rip), %rax
	movq	(%rax), %rbx
	callq	dlerror@PLT
	leaq	.L.str.1(%rip), %rsi
	movq	%rbx, %rdi
	movq	%rax, %rdx
	xorl	%eax, %eax
	callq	fprintf@PLT
.LBB0_5:
	movl	$1, %eax
.LBB0_6:
	addq	$8, %rsp
	.cfi_def_cfa_offset 40
	popq	%rbx
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	.cfi_restore %rbx
	.cfi_restore %r14
	.cfi_restore %r15
	.cfi_restore %rbp
.LBB0_7:
	retq
.Lfunc_end0:
	.size	main, .Lfunc_end0-main
	.cfi_endproc
                                        # -- End function
	.type	.L.str,@object                  # @.str
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str:
	.asciz	"libsqlite3.so.0"
	.size	.L.str, 16

	.type	.L.str.1,@object                # @.str.1
.L.str.1:
	.asciz	"%s\n"
	.size	.L.str.1, 4

	.type	.L.str.2,@object                # @.str.2
.L.str.2:
	.asciz	"sqlite3_libversion"
	.size	.L.str.2, 19

	.type	.L.str.3,@object                # @.str.3
.L.str.3:
	.asciz	"SQLite fixture version with system SQLite loaded: %s\n"
	.size	.L.str.3, 54

	.type	.L.str.4,@object                # @.str.4
.L.str.4:
	.asciz	"3.53.4"
	.size	.L.str.4, 7

	.ident	"Ubuntu clang version 21.1.8 (6ubuntu1)"
	.section	".note.GNU-stack","",@progbits
	.addrsig
