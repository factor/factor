from pathlib import Path
import subprocess,shutil,os,json,signal,time
root=Path('/home/sheeple/factor');r=Path.cwd();v=r/'validation';clone=r.parent/'gui-controls-20260909'
subprocess.run(['git','clone','--shared','--no-hardlinks',str(root),str(clone)],check=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
for name in ['factor','factor.image']:shutil.copy2(r/name,clone/name)
fixture=clone/'extra/file-picker/linux/fixtures/dialog.factor';original=fixture.read_text();results=[]
env=dict(os.environ,FACTOR_GUI_TEST_IMAGE=str(clone/'factor.image'),TMPDIR='/home/sheeple/fa-tmp-0909',XDG_CACHE_HOME='/home/sheeple/fa-cache-0909',G_DEBUG='fatal-criticals')
libs=v/'libraries';env['LD_LIBRARY_PATH']=':'.join(str(libs/p) for p in ['usr/lib/x86_64-linux-gnu','usr/lib/x86_64-linux-gnu/blas','usr/lib','lib'])
try:
 for name,expected in [('valid',0),('wrong-c-assertion',1),('missing-image',1)]:
  fixture.write_text(original.replace('{ f t } [','{ f f } [',1) if name=='wrong-c-assertion' else original)
  e=dict(env)
  if name=='missing-image':e['FACTOR_GUI_TEST_IMAGE']=str(clone/'deliberately-unavailable.image')
  cmd=['xvfb-run','-a',str(clone/'factor'),'-no-user-init','-no-monitors','.github/gtk-tests.factor']
  with (v/('gui-control-'+name+'.log')).open('w') as log:
   proc=subprocess.Popen(cmd,cwd=clone,env=e,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
   try:status=proc.wait(timeout=90)
   except subprocess.TimeoutExpired:os.killpg(proc.pid,signal.SIGKILL);proc.wait();status=124
  (v/('gui-control-'+name+'.exit')).write_text(str(status)+'\n');results.append(dict(name=name,command=cmd,gui_image=e['FACTOR_GUI_TEST_IMAGE'],status=status,expected=expected,classification='qualification' if name=='valid' else 'negative control'))
  print(name,status,flush=True);assert status==expected
finally:
 fixture.write_text(original)
 (v/'gui-negative-controls.json').write_text(json.dumps(results,indent=2)+'\n')
assert not subprocess.check_output(['git','status','--porcelain'],cwd=clone).strip()
