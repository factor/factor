from pathlib import Path
import json,os,signal,subprocess,time
out=Path(__file__).resolve().parent;s=json.loads((out/'services.json').read_text());results={}
results['postgres']=subprocess.run(['/usr/lib/postgresql/18/bin/pg_ctl','-D',s['postgres']['data'],'-m','fast','-w','stop'],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True).returncode
for name in ['redis','Xvfb']:
 pid=s[name]['pid'];cmd=Path(f'/proc/{pid}/cmdline')
 if cmd.exists():
  expected=b'redis-server' if name=='redis' else b'Xvfb\x00:109'
  assert expected in cmd.read_bytes(),f'Unexpected process at {pid}'
  os.kill(pid,signal.SIGTERM)
 results[name]='termination requested'
(out/'services-stopped.json').write_text(json.dumps(results,indent=2)+'\n')
