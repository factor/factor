	.file	"terminfo.c"
	.text
	.section	.rodata.str1.1,"aMS",@progbits,1
.LC0:
	.string	"(null)"
.LC1:
	.string	"factor-ffi-test"
.LC2:
	.string	"pfkey"
.LC3:
	.string	"text"
.LC4:
	.string	"7:text"
.LC5:
	.string	"C tparm from terminfo: %s\n"
	.section	.text.startup,"ax",@progbits
	.p2align 4
	.globl	main
	.type	main, @function
main:
.LFB38:
	.cfi_startproc
	endbr64
	pushq	%r12
	.cfi_def_cfa_offset 16
	.cfi_offset 12, -16
	pushq	%rbp
	.cfi_def_cfa_offset 24
	.cfi_offset 6, -24
	pushq	%rbx
	.cfi_def_cfa_offset 32
	.cfi_offset 3, -32
	subq	$16, %rsp
	.cfi_def_cfa_offset 48
	call	tmpfile@PLT
	movq	%rax, %rbx
	call	tmpfile@PLT
	testq	%rbx, %rbx
	je	.L5
	movq	%rax, %rbp
	testq	%rax, %rax
	je	.L5
	movq	%rax, %rdx
	movq	%rbx, %rsi
	leaq	.LC1(%rip), %rdi
	call	newterm@PLT
	movq	%rax, %r12
	testq	%rax, %rax
	je	.L5
	leaq	.LC2(%rip), %rdi
	call	tigetstr@PLT
	leaq	-1(%rax), %rdx
	cmpq	$-3, %rdx
	jbe	.L13
.L5:
	movl	$1, %ecx
.L1:
	addq	$16, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 32
	movl	%ecx, %eax
	popq	%rbx
	.cfi_def_cfa_offset 24
	popq	%rbp
	.cfi_def_cfa_offset 16
	popq	%r12
	.cfi_def_cfa_offset 8
	ret
.L13:
	.cfi_restore_state
	movq	%rax, %rdi
	leaq	.LC3(%rip), %rdx
	xorl	%eax, %eax
	movl	$7, %esi
	call	tparm@PLT
	testq	%rax, %rax
	je	.L7
	leaq	.LC4(%rip), %rsi
	movq	%rax, %rdi
	movq	%rax, 8(%rsp)
	call	strcmp@PLT
	xorl	%ecx, %ecx
	movq	8(%rsp), %rdx
	testl	%eax, %eax
	setne	%cl
.L6:
	leaq	.LC5(%rip), %rsi
	movl	$2, %edi
	xorl	%eax, %eax
	movl	%ecx, 8(%rsp)
	call	__printf_chk@PLT
	call	endwin@PLT
	movq	%r12, %rdi
	call	delscreen@PLT
	movq	%rbx, %rdi
	call	fclose@PLT
	movq	%rbp, %rdi
	call	fclose@PLT
	movl	8(%rsp), %ecx
	jmp	.L1
.L7:
	movl	$1, %ecx
	leaq	.LC0(%rip), %rdx
	jmp	.L6
	.cfi_endproc
.LFE38:
	.size	main, .-main
	.ident	"GCC: (Ubuntu 15.2.0-16ubuntu1) 15.2.0"
	.section	.note.GNU-stack,"",@progbits
	.section	.note.gnu.property,"a"
	.align 8
	.long	1f - 0f
	.long	4f - 1f
	.long	5
0:
	.string	"GNU"
1:
	.align 8
	.long	0xc0000002
	.long	3f - 2f
2:
	.long	0x3
3:
	.align 8
4:
