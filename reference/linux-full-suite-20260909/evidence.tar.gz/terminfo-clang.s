	.file	"terminfo.c"
	.text
	.globl	main                            # -- Begin function main
	.p2align	4
	.type	main,@function
main:                                   # @main
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r12
	.cfi_def_cfa_offset 40
	pushq	%rbx
	.cfi_def_cfa_offset 48
	.cfi_offset %rbx, -48
	.cfi_offset %r12, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	callq	tmpfile@PLT
	movq	%rax, %rbx
	callq	tmpfile@PLT
	testq	%rbx, %rbx
	sete	%cl
	testq	%rax, %rax
	sete	%dl
	movl	$1, %ebp
	orb	%cl, %dl
	jne	.LBB0_7
# %bb.1:
	leaq	.L.str(%rip), %rdi
	movq	%rbx, %rsi
	movq	%rax, %r14
	movq	%rax, %rdx
	callq	newterm@PLT
	testq	%rax, %rax
	je	.LBB0_7
# %bb.2:
	movq	%rax, %r15
	leaq	.L.str.1(%rip), %rdi
	callq	tigetstr@PLT
	leaq	1(%rax), %rcx
	cmpq	$2, %rcx
	jb	.LBB0_7
# %bb.3:
	leaq	.L.str.2(%rip), %rdx
	movl	$7, %esi
	movq	%rax, %rdi
	xorl	%eax, %eax
	callq	tparm@PLT
	testq	%rax, %rax
	je	.LBB0_4
# %bb.5:
	movq	%rax, %r12
	leaq	.L.str.3(%rip), %rsi
	movq	%rax, %rdi
	callq	strcmp@PLT
	xorl	%ebp, %ebp
	testl	%eax, %eax
	setne	%bpl
	jmp	.LBB0_6
.LBB0_4:
	movl	$1, %ebp
	leaq	.L.str.5(%rip), %r12
.LBB0_6:
	leaq	.L.str.4(%rip), %rdi
	movq	%r12, %rsi
	xorl	%eax, %eax
	callq	printf@PLT
	callq	endwin@PLT
	movq	%r15, %rdi
	callq	delscreen@PLT
	movq	%rbx, %rdi
	callq	fclose@PLT
	movq	%r14, %rdi
	callq	fclose@PLT
.LBB0_7:
	movl	%ebp, %eax
	popq	%rbx
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end0:
	.size	main, .Lfunc_end0-main
	.cfi_endproc
                                        # -- End function
	.type	.L.str,@object                  # @.str
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str:
	.asciz	"factor-ffi-test"
	.size	.L.str, 16

	.type	.L.str.1,@object                # @.str.1
.L.str.1:
	.asciz	"pfkey"
	.size	.L.str.1, 6

	.type	.L.str.2,@object                # @.str.2
.L.str.2:
	.asciz	"text"
	.size	.L.str.2, 5

	.type	.L.str.3,@object                # @.str.3
.L.str.3:
	.asciz	"7:text"
	.size	.L.str.3, 7

	.type	.L.str.4,@object                # @.str.4
.L.str.4:
	.asciz	"C tparm from terminfo: %s\n"
	.size	.L.str.4, 27

	.type	.L.str.5,@object                # @.str.5
.L.str.5:
	.asciz	"(null)"
	.size	.L.str.5, 7

	.ident	"Ubuntu clang version 21.1.8 (6ubuntu1)"
	.section	".note.GNU-stack","",@progbits
	.addrsig
