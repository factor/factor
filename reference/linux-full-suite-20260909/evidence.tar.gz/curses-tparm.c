#include <curses.h>
#include <term.h>
#include <stdio.h>
int main(void) {
    FILE *out = tmpfile(), *in = tmpfile();
    SCREEN *screen = newterm("dumb", out, in);
    if (!screen) return 2;
    char *text = tparm("%p1%s", "text");
    printf("tparm string = %s\n", text ? text : "(null)");
    endwin(); delscreen(screen); fclose(out); fclose(in);
    return text ? 0 : 1;
}
