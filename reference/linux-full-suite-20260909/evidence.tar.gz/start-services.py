from pathlib import Path
import os,socket,subprocess,time,json
out=Path(__file__).resolve().parent
for port in [64591,64592]:
 with socket.socket() as s:s.bind(('127.0.0.1',port))
assert not Path('/tmp/.X11-unix/X109').exists()
pg=out/'postgres';pg.mkdir();(out/'pgsock').mkdir()
with (pg/'init.log').open('w') as log:
 subprocess.run(['/usr/lib/postgresql/18/bin/initdb','-D',str(pg/'data'),'--encoding=UTF8','--locale=C','--auth=trust'],check=True,stdout=log,stderr=subprocess.STDOUT)
subprocess.run(['/usr/lib/postgresql/18/bin/pg_ctl','-D',str(pg/'data'),'-l',str(pg/'server.log'),'-o','-p 64591 -h 127.0.0.1 -k '+str(out/'pgsock'),'-w','start'],check=True)
subprocess.run(['redis-server','--bind','127.0.0.1','--port','64592','--save','','--appendonly','no','--daemonize','yes','--pidfile',str(out/'redis.pid'),'--logfile',str(out/'redis.log')],check=True)
p=subprocess.Popen(['Xvfb',':109','-screen','0','1280x1024x24','-nolisten','tcp'],stdout=(out/'xvfb.log').open('w'),stderr=subprocess.STDOUT,start_new_session=True)
(out/'xvfb.pid').write_text(str(p.pid));time.sleep(1)
assert p.poll() is None
(out/'services.json').write_text(json.dumps({'postgres':{'port':64591,'data':str(pg/'data')},'redis':{'port':64592,'pid':int((out/'redis.pid').read_text())},'Xvfb':{'display':':109','pid':p.pid}},indent=2)+'\n')
