from pathlib import Path
import subprocess,json,os,time
r=Path.cwd();v=r/'validation';libs=v/'libraries';env=dict(os.environ,LD_LIBRARY_PATH=':'.join(str(libs/p) for p in ['usr/lib/x86_64-linux-gnu','usr/lib/x86_64-linux-gnu/blas','usr/lib','lib']),TMPDIR='/home/sheeple/fa-tmp-0909',XDG_CACHE_HOME='/home/sheeple/fa-cache-0909',G_DEBUG='fatal-criticals')
results=[]
commands=[('gtk2-bootstrap',[str(r/'factor'),'-i=boot.unix-x86.64.image','-ui-backend=gtk2','-no-user-init','-no-monitors','-output-image=gtk2.image'],env),('gtk3-ci',['xvfb-run','-a',str(r/'factor'),'-i=loaded-final.image','-no-user-init','-no-monitors','.github/gtk-tests.factor'],dict(env,FACTOR_GUI_TEST_IMAGE=str(r/'factor.image'))),('gtk2-ci',['xvfb-run','-a',str(r/'factor'),'-i=gtk2.image','-no-user-init','-no-monitors','.github/gtk-tests.factor'],dict(env,FACTOR_GUI_TEST_IMAGE=str(r/'gtk2.image')))]
for name,cmd,e in commands:
 start=time.monotonic()
 with (v/(name+'.log')).open('w') as log:
  proc=subprocess.Popen(cmd,stdout=log,stderr=subprocess.STDOUT,env=e,start_new_session=True)
  try:status=proc.wait(timeout=300 if name=='gtk2-bootstrap' else 60)
  except subprocess.TimeoutExpired:
   import signal
   os.killpg(proc.pid,signal.SIGKILL);proc.wait();status=124
 (v/(name+'.exit')).write_text(str(status)+'\n');results.append(dict(name=name,command=cmd,status=status,seconds=time.monotonic()-start));print(name,status,flush=True)
 (v/'gtk-ci-checks.json').write_text(json.dumps(results,indent=2)+'\n')
 if status:raise SystemExit(status)
