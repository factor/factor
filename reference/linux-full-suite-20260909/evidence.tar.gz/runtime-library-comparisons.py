from pathlib import Path
import subprocess,json,os
r=Path.cwd();v=r/'validation';lib=v/'libraries/usr/lib/x86_64-linux-gnu'
env=dict(os.environ,LD_LIBRARY_PATH=str(lib),TMPDIR='/home/sheeple/fa-tmp-0909',XDG_CACHE_HOME='/home/sheeple/fa-cache-0909')
results=[]
for vocab,source,tests in [('curl.ffi','extra/curl/ffi/ffi.factor','extra/curl/ffi/ffi-tests.factor'),('lua','extra/lua/lua.factor','extra/lua/lua-tests.factor')]:
 old=v/(vocab+'-baseline.factor');old.write_bytes(subprocess.check_output(['git','show','HEAD:'+source]))
 for label,path,expected in [('baseline',old,1),('candidate',r/source,0)]:
  driver=v/(vocab+'-'+label+'-driver.factor')
  driver.write_text('USING: assocs compiler.errors debugger io kernel namespaces parser sequences system tools.test vocabs ;\nf restartable-tests? set-global\nauto-use? off\n"'+vocab+'" require\n"'+str(path)+'" run-file\n"'+str(r/tests)+'" run-test-file\n:test-failures\ncompiler-errors get values [ print-error ] each\ntest-failures get empty? compiler-errors get assoc-empty? and 0 1 ? exit\n')
  cmd=[str(r/'factor'),'-i='+str(r/'factor.image'),'-no-user-init','-no-monitors',str(driver)]
  with (v/(vocab+'-'+label+'.log')).open('w') as log:p=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,env=env,timeout=60)
  (v/(vocab+'-'+label+'.exit')).write_text(str(p.returncode)+'\n');results.append(dict(vocab=vocab,version=label,command=cmd,status=p.returncode,expected=expected));print(vocab,label,p.returncode);assert p.returncode==expected
(v/'runtime-library-comparisons.json').write_text(json.dumps(results,indent=2)+'\n')
