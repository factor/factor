USING: assocs compiler.errors debugger io kernel namespaces parser
sequences system tools.test vocabs.hierarchy ;
f restartable-tests? set-global
auto-use? off
{ "compiler.cfg.intrinsics.simd" "math.vectors.simd.intrinsics"
  "curl.ffi" "lua" "git" "curses.ffi" "file-picker.linux"
  "db.sqlite.ffi.release-tests" } [ [ load ] [ test ] bi ] each
:test-failures
compiler-errors get values [ print-error ] each
test-failures get empty? compiler-errors get assoc-empty? and 0 1 ? exit
