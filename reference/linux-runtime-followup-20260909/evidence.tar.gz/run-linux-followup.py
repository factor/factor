from pathlib import Path
import os,subprocess,json,hashlib,signal
root=Path('/home/sheeple/factor');base=Path('/home/sheeple/factor-workspaces/linux-followup-base');candidate=base.parent/'linux-followup';out=candidate/'logs/followup'
def copy(names):
 import shutil
 for n in names:
  p=candidate/n;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(root/n,p)
def run(label,cmd,cwd,env=None,timeout=90):
 with (out/(label+'.log')).open('wb') as log:
  proc=subprocess.Popen(cmd,cwd=cwd,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  try:rc=proc.wait(timeout=timeout)
  except subprocess.TimeoutExpired:
   os.killpg(proc.pid,signal.SIGKILL);proc.wait();rc=124
 (out/(label+'.exit')).write_text(str(rc)+'\n');print(label,rc,flush=True);return rc
def compare(case,fixture,reload):
 driver=out/(case+'-driver.factor')
 driver.write_text('USING: vocabs.loader ;\n'+''.join('"'+v+'" reload\n' for v in reload)+(root/'.github/ffi-compare.factor').read_text())
 env=dict(os.environ,FACTOR_REPRO_TESTS=str(root/fixture),TMPDIR=str(out/'tmp'))
 for label,r in [('baseline',base),('candidate',candidate)]:
  run(case+'-'+label,[str(r/'factor'),'-i='+str(r/'factor.image'),'-resource-path='+str(r),'-no-user-init','-no-monitors',str(driver)],r,env,30)
if __name__=='__main__':
 copy(['basis/unix/ffi/linux/linux.factor','basis/unix/ffi/macos/macos.factor','basis/unix/ffi/bsd/bsd.factor','basis/io/backend/unix/unix.factor','basis/io/files/unix/unix-tests.factor','basis/io/files/unix/fixtures/append.factor'])
 compare('append','basis/io/files/unix/fixtures/append.factor',['unix.ffi.linux','io.backend.unix'])
