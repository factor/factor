from pathlib import Path
import subprocess,json,hashlib,tarfile,shutil,os
root=Path('/home/sheeple/factor')
base=Path('/home/sheeple/factor-workspaces/linux-followup-base')
candidate=base.parent/'linux-followup'
out=candidate/'logs/followup'
report=root/'reference/linux-runtime-followup-20260909'
report.mkdir(exist_ok=True)
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for chunk in iter(lambda:f.read(1024*1024),b''): h.update(chunk)
 return h.hexdigest()
def git(r,*args):return subprocess.check_output(['git',*args],cwd=r)
manifest={'scope':'native x86-64 Linux glibc, C++ VM','reviewed_head':git(root,'rev-parse','HEAD').decode().strip(),'workspaces':{}}
for name,r in [('baseline',base),('candidate',candidate)]:
 files=git(r,'ls-files','-z').decode().split('\0')
 files+=git(r,'ls-files','--others','--exclude-standard','-z').decode().split('\0')
 source={p:sha(r/p) for p in sorted(set(files)) if p and (r/p).is_file() and not p.startswith('reference/')}
 binaries={p:sha(r/p) for p in ['factor','libfactor.a','libfactor-ffi-test.so','factor.image','gtk2.image','gtk2-r2.image','final.image','boot.unix-x86.64.image'] if (r/p).is_file()}
 manifest['workspaces'][name]={'path':str(r),'commit':git(r,'rev-parse','HEAD').decode().strip(),'status':git(r,'status','--short').decode(),'source_sha256':source,'binary_sha256':binaries}
 (report/(name+'.patch')).write_bytes(git(r,'diff','--binary','HEAD'))
 with tarfile.open(report/(name+'-untracked.tar.gz'),'w:gz') as archive:
  for p in git(r,'ls-files','--others','--exclude-standard','-z').decode().split('\0'):
   if p and (r/p).is_file():archive.add(r/p,arcname=p)
comparison_paths=['basis/io/files/unix/fixtures/append.factor','basis/io/files/unix/fixtures/fifo.factor','basis/io/files/unix/fixtures/fifo-append.factor','extra/file-picker/linux/fixtures/dialog.factor','extra/ping/ping-tests.factor','basis/ui/backend/gtk2/gtk2-tests.factor','vm/tests/library_probe.py']
manifest['comparison_sources']={p:sha(root/p) for p in comparison_paths}
for p in comparison_paths:
 assert sha(root/p)==sha(candidate/p), p+' changed since validation'
manifest['runtime_libraries']={p:sha(Path(p)) for p in ['/home/sheeple/factor/logs/linux-issues/libraries/libgtk-x11-2.0.so.0','/home/sheeple/factor/logs/linux-issues/libraries/libgdk-x11-2.0.so.0']}
manifest['exits']={str(p.relative_to(out)):int(p.read_text().strip()) for p in sorted(out.rglob('*.exit'))}
manifest['controls_sha256']={str(p.relative_to(out)):sha(p) for p in sorted(out.rglob('*')) if p.is_file() and (p.suffix=='.s' or ('control' in p.name and p.suffix==''))}
(report/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
for p in ['final-comparisons.json','final-validation.json']:
 if (out/p).exists():shutil.copy2(out/p,report/p)
with tarfile.open(report/'evidence.tar.gz','w:gz') as archive:
 for r,name in [(out,'candidate'),(base/'logs/followup','baseline')]:
  for p in sorted(r.rglob('*')):
   rel=p.relative_to(r)
   if p.is_file() and not any(part in ['tmp','integration-tmp'] for part in rel.parts):archive.add(p,arcname=str(Path(name)/rel))
 for p in comparison_paths:
  archive.add(candidate/p,arcname='comparison-sources/'+p)
 for filename in ['run-linux-followup.py','final-linux-followup.py','gtk-commit-review.json','validate-final-followup.py','archive-followup.py']:
  archive.add(base.parent/filename,arcname=filename)
with tarfile.open(report/'source-patches.tar.gz','w:gz') as archive:
 for p in sorted(report.glob('*.patch')):
  archive.add(p,arcname=p.name)
  p.unlink()
(report/'SHA256SUMS').write_text(''.join(sha(p)+'  '+p.name+'\n' for p in sorted(report.iterdir()) if p.is_file() and p.name!='SHA256SUMS'))
print(report)
