USING: accessors ping tools.test ;
{ 0 } [ local-ping type>> ] unit-test
