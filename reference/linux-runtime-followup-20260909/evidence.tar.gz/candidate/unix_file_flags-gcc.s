	.file	"unix_file_flags.c"
	.text
	.section	.rodata.str1.1,"aMS",@progbits,1
.LC0:
	.string	"mkdtemp(directory)"
.LC1:
	.string	"chdir(directory) == 0"
.LC2:
	.string	"append"
.LC3:
	.string	"first >= 0"
	.section	.rodata.str1.8,"aMS",@progbits,1
	.align 8
.LC4:
	.string	"fcntl(first, F_SETFL, fcntl(first, F_GETFL) | O_NONBLOCK) == 0"
	.section	.rodata.str1.1
.LC5:
	.string	"second >= 0"
.LC6:
	.string	"b"
.LC7:
	.string	"write(second, \"b\", 1) == 1"
.LC8:
	.string	"a"
.LC9:
	.string	"write(first, \"a\", 1) == 1"
	.section	.rodata.str1.8
	.align 8
.LC10:
	.string	"close(first) == 0 && close(second) == 0"
	.align 8
.LC11:
	.string	"read(first, bytes, 2) == 2 && memcmp(bytes, \"ba\", 2) == 0"
	.align 8
.LC12:
	.string	"close(first) == 0 && unlink(\"append\") == 0"
	.section	.rodata.str1.1
.LC13:
	.string	"pipe"
.LC14:
	.string	"mkfifo(\"pipe\", 0600) == 0"
	.section	.rodata.str1.8
	.align 8
.LC15:
	.string	"open(\"pipe\", O_WRONLY | O_NONBLOCK) == -1 && errno == ENXIO"
	.align 8
.LC16:
	.string	"first >= 0 && read(first, bytes, 1) == 0"
	.align 8
.LC17:
	.string	"lseek(second, 0, SEEK_END) == -1 && errno == ESPIPE"
	.section	.rodata.str1.1
.LC18:
	.string	"x"
	.section	.rodata.str1.8
	.align 8
.LC19:
	.string	"write(second, \"x\", 1) == 1 && read(first, bytes, 1) == 1 && bytes[0] == 'x'"
	.align 8
.LC20:
	.string	"close(first) == 0 && close(second) == 0 && unlink(\"pipe\") == 0"
	.section	.rodata.str1.1
.LC21:
	.string	"/"
	.section	.rodata.str1.8
	.align 8
.LC22:
	.string	"chdir(\"/\") == 0 && rmdir(directory) == 0"
	.align 8
.LC23:
	.string	"C-CONTROL append, nonblocking FIFO, FIFO appender passed"
	.section	.text.unlikely,"ax",@progbits
.LCOLDB26:
	.section	.text.startup,"ax",@progbits
.LHOTB26:
	.p2align 4
	.globl	main
	.type	main, @function
main:
.LFB80:
	.cfi_startproc
	endbr64
	pushq	%r14
	.cfi_def_cfa_offset 16
	.cfi_offset 14, -16
	pushq	%r13
	.cfi_def_cfa_offset 24
	.cfi_offset 13, -24
	pushq	%r12
	.cfi_def_cfa_offset 32
	.cfi_offset 12, -32
	pushq	%rbp
	.cfi_def_cfa_offset 40
	.cfi_offset 6, -40
	pushq	%rbx
	.cfi_def_cfa_offset 48
	.cfi_offset 3, -48
	subq	$64, %rsp
	.cfi_def_cfa_offset 112
	movdqa	.LC24(%rip), %xmm0
	movq	%fs:40, %rax
	movq	%rax, 56(%rsp)
	xorl	%eax, %eax
	leaq	16(%rsp), %rdi
	movaps	%xmm0, 16(%rsp)
	movdqa	.LC25(%rip), %xmm0
	movups	%xmm0, 30(%rsp)
	call	mkdtemp@PLT
	testq	%rax, %rax
	je	.L32
	leaq	16(%rsp), %rdi
	call	chdir@PLT
	testl	%eax, %eax
	jne	.L33
	movl	$384, %edx
	movl	$1089, %esi
	leaq	.LC2(%rip), %rdi
	xorl	%eax, %eax
	call	open@PLT
	movl	%eax, %ebx
	testl	%eax, %eax
	js	.L34
	movl	%eax, %edi
	movl	$3, %esi
	xorl	%eax, %eax
	call	fcntl@PLT
	movl	$4, %esi
	movl	%ebx, %edi
	orb	$8, %ah
	movl	%eax, %edx
	xorl	%eax, %eax
	call	fcntl@PLT
	testl	%eax, %eax
	jne	.L35
	movl	$1025, %esi
	leaq	.LC2(%rip), %rdi
	xorl	%eax, %eax
	call	open@PLT
	movl	%eax, %ebp
	testl	%eax, %eax
	js	.L22
	movl	$1, %edx
	leaq	.LC6(%rip), %rsi
	movl	%eax, %edi
	call	write@PLT
	cmpq	$1, %rax
	jne	.L36
	movl	$1, %edx
	leaq	.LC8(%rip), %rsi
	movl	%ebx, %edi
	call	write@PLT
	cmpq	$1, %rax
	jne	.L37
	movl	%ebx, %edi
	call	close@PLT
	testl	%eax, %eax
	jne	.L12
	movl	%ebp, %edi
	call	close@PLT
	testl	%eax, %eax
	jne	.L12
	xorl	%esi, %esi
	leaq	.LC2(%rip), %rdi
	call	open@PLT
	movl	$2, %edx
	leaq	14(%rsp), %rsi
	movl	%eax, %edi
	movl	%eax, %ebx
	call	read@PLT
	cmpq	$2, %rax
	jne	.L13
	cmpw	$24930, 14(%rsp)
	jne	.L13
	movl	%ebx, %edi
	call	close@PLT
	testl	%eax, %eax
	jne	.L16
	leaq	.LC2(%rip), %rdi
	call	unlink@PLT
	testl	%eax, %eax
	jne	.L16
	movl	$384, %esi
	leaq	.LC13(%rip), %rdi
	call	mkfifo@PLT
	testl	%eax, %eax
	jne	.L38
	xorl	%eax, %eax
	movl	$2049, %esi
	leaq	.LC13(%rip), %rdi
	call	open@PLT
	cmpl	$-1, %eax
	jne	.L18
	call	__errno_location@PLT
	movq	%rax, %r14
	cmpl	$6, (%rax)
	jne	.L18
	movl	$2048, %esi
	leaq	.LC13(%rip), %rdi
	xorl	%eax, %eax
	call	open@PLT
	movl	%eax, %ebp
	testl	%eax, %eax
	js	.L21
	movl	$1, %edx
	leaq	14(%rsp), %rsi
	movl	%eax, %edi
	call	read@PLT
	testq	%rax, %rax
	jne	.L21
	movl	$3073, %esi
	leaq	.LC13(%rip), %rdi
	call	open@PLT
	movl	%eax, %ebx
	testl	%eax, %eax
	js	.L22
	xorl	%esi, %esi
	movl	$2, %edx
	movl	%eax, %edi
	call	lseek@PLT
	cmpq	$-1, %rax
	jne	.L23
	cmpl	$29, (%r14)
	jne	.L23
	movl	$1, %edx
	leaq	.LC18(%rip), %rsi
	movl	%ebx, %edi
	call	write@PLT
	cmpq	$1, %rax
	jne	.L26
	movl	$1, %edx
	leaq	14(%rsp), %rsi
	movl	%ebp, %edi
	call	read@PLT
	cmpq	$1, %rax
	jne	.L26
	cmpb	$120, 14(%rsp)
	jne	.L26
	movl	%ebp, %edi
	call	close@PLT
	testl	%eax, %eax
	jne	.L28
	movl	%ebx, %edi
	call	close@PLT
	testl	%eax, %eax
	jne	.L28
	leaq	.LC13(%rip), %rdi
	call	unlink@PLT
	testl	%eax, %eax
	jne	.L28
	leaq	.LC21(%rip), %rdi
	call	chdir@PLT
	testl	%eax, %eax
	jne	.L30
	leaq	16(%rsp), %rdi
	call	rmdir@PLT
	movl	%eax, %ebx
	testl	%eax, %eax
	jne	.L30
	leaq	.LC23(%rip), %rdi
	call	puts@PLT
.L1:
	movq	56(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L41
	addq	$64, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 48
	movl	%ebx, %eax
	popq	%rbx
	.cfi_def_cfa_offset 40
	popq	%rbp
	.cfi_def_cfa_offset 32
	popq	%r12
	.cfi_def_cfa_offset 24
	popq	%r13
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	ret
.L41:
	.cfi_restore_state
	call	__stack_chk_fail@PLT
	.cfi_endproc
	.section	.text.unlikely
	.cfi_startproc
	.type	main.cold, @function
main.cold:
.LFSB80:
.L30:
	.cfi_def_cfa_offset 112
	.cfi_offset 3, -48
	.cfi_offset 6, -40
	.cfi_offset 12, -32
	.cfi_offset 13, -24
	.cfi_offset 14, -16
	leaq	.LC22(%rip), %rdi
	call	perror@PLT
.L3:
	movl	$1, %ebx
	jmp	.L1
.L28:
	leaq	.LC20(%rip), %rdi
	call	perror@PLT
	jmp	.L3
.L26:
	leaq	.LC19(%rip), %rdi
	call	perror@PLT
	jmp	.L3
.L23:
	leaq	.LC17(%rip), %rdi
	call	perror@PLT
	jmp	.L3
.L21:
	leaq	.LC16(%rip), %rdi
	call	perror@PLT
	jmp	.L3
.L18:
	leaq	.LC15(%rip), %rdi
	call	perror@PLT
	jmp	.L3
.L38:
	leaq	.LC14(%rip), %rdi
	call	perror@PLT
	jmp	.L3
.L16:
	leaq	.LC12(%rip), %rdi
	call	perror@PLT
	jmp	.L3
.L13:
	leaq	.LC11(%rip), %rdi
	call	perror@PLT
	jmp	.L3
.L12:
	leaq	.LC10(%rip), %rdi
	call	perror@PLT
	jmp	.L3
.L37:
	leaq	.LC9(%rip), %rdi
	call	perror@PLT
	jmp	.L3
.L36:
	leaq	.LC7(%rip), %rdi
	call	perror@PLT
	jmp	.L3
.L22:
	leaq	.LC5(%rip), %rdi
	call	perror@PLT
	jmp	.L3
.L35:
	leaq	.LC4(%rip), %rdi
	call	perror@PLT
	jmp	.L3
.L34:
	leaq	.LC3(%rip), %rdi
	call	perror@PLT
	jmp	.L3
.L33:
	leaq	.LC1(%rip), %rdi
	call	perror@PLT
	jmp	.L3
.L32:
	leaq	.LC0(%rip), %rdi
	call	perror@PLT
	jmp	.L3
	.cfi_endproc
.LFE80:
	.section	.text.startup
	.size	main, .-main
	.section	.text.unlikely
	.size	main.cold, .-main.cold
.LCOLDE26:
	.section	.text.startup
.LHOTE26:
	.section	.rodata.cst16,"aM",@progbits,16
	.align 16
.LC24:
	.quad	7161117236431516719
	.quad	7308332182885527412
	.align 16
.LC25:
	.quad	8315722355161523564
	.quad	24866934413088813
	.ident	"GCC: (Ubuntu 15.2.0-16ubuntu1) 15.2.0"
	.section	.note.GNU-stack,"",@progbits
	.section	.note.gnu.property,"a"
	.align 8
	.long	1f - 0f
	.long	4f - 1f
	.long	5
0:
	.string	"GNU"
1:
	.align 8
	.long	0xc0000002
	.long	3f - 2f
2:
	.long	0x3
3:
	.align 8
4:
