USING: alien.libraries.finder tools.test ;
{ f } [ "factor-deliberately-missing" find-library* ] unit-test
