	.file	"gtk_file_picker.c"
	.text
	.section	.rodata.str1.1,"aMS",@progbits,1
.LC0:
	.string	"Save"
.LC1:
	.string	"Cancel"
.LC2:
	.string	"Save File"
.LC3:
	.string	"/tmp"
.LC4:
	.string	"nonexistent-new-file.txt"
.LC5:
	.string	"Open"
.LC6:
	.string	"Open File"
	.section	.rodata.str1.8,"aMS",@progbits,1
	.align 8
.LC7:
	.string	"C-CONTROL GTK open/save actions and new filename passed"
	.section	.rodata.str1.1
.LC8:
	.string	"/tmp/nonexistent-new-file.txt"
	.section	.text.startup,"ax",@progbits
	.p2align 4
	.globl	main
	.type	main, @function
main:
.LFB50:
	.cfi_startproc
	endbr64
	pushq	%r14
	.cfi_def_cfa_offset 16
	.cfi_offset 14, -16
	xorl	%esi, %esi
	xorl	%edi, %edi
	pushq	%rbx
	.cfi_def_cfa_offset 24
	.cfi_offset 3, -24
	subq	$24, %rsp
	.cfi_def_cfa_offset 48
	call	gtk_init_check@PLT
	testl	%eax, %eax
	jne	.L2
.L4:
	movl	$1, %edx
.L1:
	addq	$24, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 24
	movl	%edx, %eax
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	ret
.L2:
	.cfi_restore_state
	pushq	$0
	.cfi_def_cfa_offset 56
	leaq	.LC1(%rip), %rcx
	xorl	%esi, %esi
	movl	$1, %edx
	pushq	$-3
	.cfi_def_cfa_offset 64
	leaq	.LC0(%rip), %r9
	movl	$-6, %r8d
	xorl	%eax, %eax
	leaq	.LC2(%rip), %rdi
	call	gtk_file_chooser_dialog_new@PLT
	popq	%rcx
	.cfi_def_cfa_offset 56
	popq	%rsi
	.cfi_def_cfa_offset 48
	movq	%rax, %rbx
	testq	%rax, %rax
	je	.L4
	movq	%rax, %rdi
	call	gtk_file_chooser_get_action@PLT
	subl	$1, %eax
	jne	.L4
	leaq	.LC3(%rip), %rsi
	movq	%rbx, %rdi
	call	gtk_file_chooser_set_current_folder@PLT
	testl	%eax, %eax
	je	.L4
	leaq	.LC4(%rip), %rsi
	movq	%rbx, %rdi
	movl	$500, %r14d
	call	gtk_file_chooser_set_current_name@PLT
.L6:
	xorl	%esi, %esi
	xorl	%edi, %edi
	call	g_main_context_iteration@PLT
	movq	%rbx, %rdi
	call	gtk_file_chooser_get_filename@PLT
	movq	%rax, %rdi
	testq	%rax, %rax
	je	.L22
	leaq	.LC8(%rip), %rsi
	movq	%rax, 8(%rsp)
	call	strcmp@PLT
	testl	%eax, %eax
	jne	.L4
	movq	8(%rsp), %rdi
	call	g_free@PLT
	movq	%rbx, %rdi
	call	gtk_widget_destroy@PLT
	pushq	$0
	.cfi_def_cfa_offset 56
	xorl	%edx, %edx
	leaq	.LC5(%rip), %r9
	pushq	$-3
	.cfi_def_cfa_offset 64
	movl	$-6, %r8d
	xorl	%esi, %esi
	xorl	%eax, %eax
	leaq	.LC1(%rip), %rcx
	leaq	.LC6(%rip), %rdi
	call	gtk_file_chooser_dialog_new@PLT
	movq	%rax, %rbx
	popq	%rax
	.cfi_def_cfa_offset 56
	popq	%rdx
	.cfi_def_cfa_offset 48
	testq	%rbx, %rbx
	je	.L4
	movq	%rbx, %rdi
	call	gtk_file_chooser_get_action@PLT
	testl	%eax, %eax
	jne	.L4
	movq	%rbx, %rdi
	movl	%eax, 8(%rsp)
	call	gtk_widget_destroy@PLT
	leaq	.LC7(%rip), %rdi
	call	puts@PLT
	movl	8(%rsp), %edx
	jmp	.L1
.L22:
	movl	$10000, %edi
	call	usleep@PLT
	movl	%r14d, %eax
	subl	$1, %eax
	movl	%eax, %r14d
	jne	.L6
	jmp	.L4
	.cfi_endproc
.LFE50:
	.size	main, .-main
	.ident	"GCC: (Ubuntu 15.2.0-16ubuntu1) 15.2.0"
	.section	.note.GNU-stack,"",@progbits
	.section	.note.gnu.property,"a"
	.align 8
	.long	1f - 0f
	.long	4f - 1f
	.long	5
0:
	.string	"GNU"
1:
	.align 8
	.long	0xc0000002
	.long	3f - 2f
2:
	.long	0x3
3:
	.align 8
4:
