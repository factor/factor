	.file	"unix_file_flags.c"
	.text
	.globl	main                            # -- Begin function main
	.p2align	4
	.type	main,@function
main:                                   # @main
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r14
	.cfi_def_cfa_offset 24
	pushq	%rbx
	.cfi_def_cfa_offset 32
	subq	$48, %rsp
	.cfi_def_cfa_offset 80
	.cfi_offset %rbx, -32
	.cfi_offset %r14, -24
	.cfi_offset %rbp, -16
	movups	.L__const.main.directory+14(%rip), %xmm0
	movups	%xmm0, 30(%rsp)
	movaps	.L__const.main.directory(%rip), %xmm0
	movaps	%xmm0, 16(%rsp)
	leaq	16(%rsp), %rdi
	callq	mkdtemp@PLT
	testq	%rax, %rax
	je	.LBB0_32
# %bb.1:
	leaq	16(%rsp), %rdi
	callq	chdir@PLT
	testl	%eax, %eax
	jne	.LBB0_34
# %bb.2:
	leaq	.L.str.2(%rip), %rdi
	movl	$1089, %esi                     # imm = 0x441
	movl	$384, %edx                      # imm = 0x180
	xorl	%eax, %eax
	callq	open@PLT
	testl	%eax, %eax
	js	.LBB0_35
# %bb.3:
	movl	%eax, %ebx
	movl	%eax, %edi
	movl	$3, %esi
	xorl	%eax, %eax
	callq	fcntl@PLT
	orl	$2048, %eax                     # imm = 0x800
	movl	%ebx, %edi
	movl	$4, %esi
	movl	%eax, %edx
	xorl	%eax, %eax
	callq	fcntl@PLT
	testl	%eax, %eax
	jne	.LBB0_36
# %bb.4:
	leaq	.L.str.2(%rip), %rdi
	movl	$1025, %esi                     # imm = 0x401
	xorl	%eax, %eax
	callq	open@PLT
	testl	%eax, %eax
	js	.LBB0_47
# %bb.5:
	movl	%eax, %ebp
	leaq	.L.str.6(%rip), %rsi
	movl	$1, %edx
	movl	%eax, %edi
	callq	write@PLT
	cmpq	$1, %rax
	jne	.LBB0_39
# %bb.6:
	leaq	.L.str.8(%rip), %rsi
	movl	$1, %edx
	movl	%ebx, %edi
	callq	write@PLT
	cmpq	$1, %rax
	jne	.LBB0_42
# %bb.7:
	movl	%ebx, %edi
	callq	close@PLT
	testl	%eax, %eax
	jne	.LBB0_30
# %bb.8:
	movl	%ebp, %edi
	callq	close@PLT
	testl	%eax, %eax
	jne	.LBB0_30
# %bb.9:
	leaq	.L.str.2(%rip), %rdi
	xorl	%esi, %esi
	xorl	%eax, %eax
	callq	open@PLT
	movl	%eax, %ebx
	leaq	14(%rsp), %rsi
	movl	$2, %edx
	movl	%eax, %edi
	callq	read@PLT
	cmpq	$2, %rax
	jne	.LBB0_31
# %bb.10:
	cmpw	$24930, 14(%rsp)                # imm = 0x6162
	jne	.LBB0_31
# %bb.11:
	movl	%ebx, %edi
	callq	close@PLT
	testl	%eax, %eax
	jne	.LBB0_33
# %bb.12:
	leaq	.L.str.2(%rip), %rdi
	callq	unlink@PLT
	testl	%eax, %eax
	jne	.LBB0_33
# %bb.13:
	leaq	.L.str.14(%rip), %rdi
	movl	$384, %esi                      # imm = 0x180
	callq	mkfifo@PLT
	testl	%eax, %eax
	jne	.LBB0_45
# %bb.14:
	leaq	.L.str.14(%rip), %rdi
	movl	$2049, %esi                     # imm = 0x801
	xorl	%eax, %eax
	callq	open@PLT
	cmpl	$-1, %eax
	jne	.LBB0_37
# %bb.15:
	callq	__errno_location@PLT
	cmpl	$6, (%rax)
	jne	.LBB0_37
# %bb.16:
	movq	%rax, %r14
	leaq	.L.str.14(%rip), %rdi
	movl	$2048, %esi                     # imm = 0x800
	xorl	%eax, %eax
	callq	open@PLT
	testl	%eax, %eax
	js	.LBB0_40
# %bb.17:
	movl	%eax, %ebx
	leaq	14(%rsp), %rsi
	movl	$1, %edx
	movl	%eax, %edi
	callq	read@PLT
	testq	%rax, %rax
	jne	.LBB0_40
# %bb.18:
	leaq	.L.str.14(%rip), %rdi
	movl	$3073, %esi                     # imm = 0xC01
	xorl	%eax, %eax
	callq	open@PLT
	testl	%eax, %eax
	js	.LBB0_47
# %bb.19:
	movl	%eax, %ebp
	movl	%eax, %edi
	xorl	%esi, %esi
	movl	$2, %edx
	callq	lseek@PLT
	cmpq	$-1, %rax
	jne	.LBB0_43
# %bb.20:
	cmpl	$29, (%r14)
	jne	.LBB0_43
# %bb.21:
	leaq	.L.str.19(%rip), %rsi
	movl	$1, %edx
	movl	%ebp, %edi
	callq	write@PLT
	cmpq	$1, %rax
	jne	.LBB0_44
# %bb.22:
	leaq	14(%rsp), %rsi
	movl	$1, %edx
	movl	%ebx, %edi
	callq	read@PLT
	cmpq	$1, %rax
	jne	.LBB0_44
# %bb.23:
	cmpb	$120, 14(%rsp)
	jne	.LBB0_44
# %bb.24:
	movl	%ebx, %edi
	callq	close@PLT
	testl	%eax, %eax
	jne	.LBB0_41
# %bb.25:
	movl	%ebp, %edi
	callq	close@PLT
	testl	%eax, %eax
	jne	.LBB0_41
# %bb.26:
	leaq	.L.str.14(%rip), %rdi
	callq	unlink@PLT
	testl	%eax, %eax
	jne	.LBB0_41
# %bb.27:
	leaq	.L.str.22(%rip), %rdi
	callq	chdir@PLT
	testl	%eax, %eax
	jne	.LBB0_46
# %bb.28:
	leaq	16(%rsp), %rdi
	callq	rmdir@PLT
	testl	%eax, %eax
	jne	.LBB0_46
# %bb.29:
	leaq	.L.str.24(%rip), %rdi
	callq	puts@PLT
	xorl	%eax, %eax
	jmp	.LBB0_49
.LBB0_30:
	leaq	.L.str.10(%rip), %rdi
	jmp	.LBB0_48
.LBB0_31:
	leaq	.L.str.12(%rip), %rdi
	jmp	.LBB0_48
.LBB0_47:
	leaq	.L.str.5(%rip), %rdi
	jmp	.LBB0_48
.LBB0_32:
	leaq	.L.str(%rip), %rdi
	jmp	.LBB0_48
.LBB0_33:
	leaq	.L.str.13(%rip), %rdi
	jmp	.LBB0_48
.LBB0_34:
	leaq	.L.str.1(%rip), %rdi
	jmp	.LBB0_48
.LBB0_35:
	leaq	.L.str.3(%rip), %rdi
	jmp	.LBB0_48
.LBB0_36:
	leaq	.L.str.4(%rip), %rdi
	jmp	.LBB0_48
.LBB0_37:
	leaq	.L.str.16(%rip), %rdi
	jmp	.LBB0_48
.LBB0_39:
	leaq	.L.str.7(%rip), %rdi
	jmp	.LBB0_48
.LBB0_40:
	leaq	.L.str.17(%rip), %rdi
	jmp	.LBB0_48
.LBB0_41:
	leaq	.L.str.21(%rip), %rdi
	jmp	.LBB0_48
.LBB0_42:
	leaq	.L.str.9(%rip), %rdi
	jmp	.LBB0_48
.LBB0_43:
	leaq	.L.str.18(%rip), %rdi
	jmp	.LBB0_48
.LBB0_44:
	leaq	.L.str.20(%rip), %rdi
	jmp	.LBB0_48
.LBB0_45:
	leaq	.L.str.15(%rip), %rdi
	jmp	.LBB0_48
.LBB0_46:
	leaq	.L.str.23(%rip), %rdi
.LBB0_48:
	callq	perror@PLT
	movl	$1, %eax
.LBB0_49:
	addq	$48, %rsp
	.cfi_def_cfa_offset 32
	popq	%rbx
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end0:
	.size	main, .Lfunc_end0-main
	.cfi_endproc
                                        # -- End function
	.type	.L__const.main.directory,@object # @__const.main.directory
	.section	.rodata.str1.16,"aMS",@progbits,1
	.p2align	4, 0x0
.L__const.main.directory:
	.asciz	"/tmp/factor-file-flags-XXXXXX"
	.size	.L__const.main.directory, 30

	.type	.L.str,@object                  # @.str
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str:
	.asciz	"mkdtemp(directory)"
	.size	.L.str, 19

	.type	.L.str.1,@object                # @.str.1
.L.str.1:
	.asciz	"chdir(directory) == 0"
	.size	.L.str.1, 22

	.type	.L.str.2,@object                # @.str.2
.L.str.2:
	.asciz	"append"
	.size	.L.str.2, 7

	.type	.L.str.3,@object                # @.str.3
.L.str.3:
	.asciz	"first >= 0"
	.size	.L.str.3, 11

	.type	.L.str.4,@object                # @.str.4
.L.str.4:
	.asciz	"fcntl(first, F_SETFL, fcntl(first, F_GETFL) | O_NONBLOCK) == 0"
	.size	.L.str.4, 63

	.type	.L.str.5,@object                # @.str.5
.L.str.5:
	.asciz	"second >= 0"
	.size	.L.str.5, 12

	.type	.L.str.6,@object                # @.str.6
.L.str.6:
	.asciz	"b"
	.size	.L.str.6, 2

	.type	.L.str.7,@object                # @.str.7
.L.str.7:
	.asciz	"write(second, \"b\", 1) == 1"
	.size	.L.str.7, 27

	.type	.L.str.8,@object                # @.str.8
.L.str.8:
	.asciz	"a"
	.size	.L.str.8, 2

	.type	.L.str.9,@object                # @.str.9
.L.str.9:
	.asciz	"write(first, \"a\", 1) == 1"
	.size	.L.str.9, 26

	.type	.L.str.10,@object               # @.str.10
.L.str.10:
	.asciz	"close(first) == 0 && close(second) == 0"
	.size	.L.str.10, 40

	.type	.L.str.11,@object               # @.str.11
.L.str.11:
	.asciz	"ba"
	.size	.L.str.11, 3

	.type	.L.str.12,@object               # @.str.12
.L.str.12:
	.asciz	"read(first, bytes, 2) == 2 && memcmp(bytes, \"ba\", 2) == 0"
	.size	.L.str.12, 58

	.type	.L.str.13,@object               # @.str.13
.L.str.13:
	.asciz	"close(first) == 0 && unlink(\"append\") == 0"
	.size	.L.str.13, 43

	.type	.L.str.14,@object               # @.str.14
.L.str.14:
	.asciz	"pipe"
	.size	.L.str.14, 5

	.type	.L.str.15,@object               # @.str.15
.L.str.15:
	.asciz	"mkfifo(\"pipe\", 0600) == 0"
	.size	.L.str.15, 26

	.type	.L.str.16,@object               # @.str.16
.L.str.16:
	.asciz	"open(\"pipe\", O_WRONLY | O_NONBLOCK) == -1 && errno == ENXIO"
	.size	.L.str.16, 60

	.type	.L.str.17,@object               # @.str.17
.L.str.17:
	.asciz	"first >= 0 && read(first, bytes, 1) == 0"
	.size	.L.str.17, 41

	.type	.L.str.18,@object               # @.str.18
.L.str.18:
	.asciz	"lseek(second, 0, SEEK_END) == -1 && errno == ESPIPE"
	.size	.L.str.18, 52

	.type	.L.str.19,@object               # @.str.19
.L.str.19:
	.asciz	"x"
	.size	.L.str.19, 2

	.type	.L.str.20,@object               # @.str.20
.L.str.20:
	.asciz	"write(second, \"x\", 1) == 1 && read(first, bytes, 1) == 1 && bytes[0] == 'x'"
	.size	.L.str.20, 76

	.type	.L.str.21,@object               # @.str.21
.L.str.21:
	.asciz	"close(first) == 0 && close(second) == 0 && unlink(\"pipe\") == 0"
	.size	.L.str.21, 63

	.type	.L.str.22,@object               # @.str.22
.L.str.22:
	.asciz	"/"
	.size	.L.str.22, 2

	.type	.L.str.23,@object               # @.str.23
.L.str.23:
	.asciz	"chdir(\"/\") == 0 && rmdir(directory) == 0"
	.size	.L.str.23, 41

	.type	.L.str.24,@object               # @.str.24
.L.str.24:
	.asciz	"C-CONTROL append, nonblocking FIFO, FIFO appender passed"
	.size	.L.str.24, 57

	.ident	"Ubuntu clang version 21.1.8 (6ubuntu1)"
	.section	".note.GNU-stack","",@progbits
	.addrsig
