	.file	"gtk_file_picker.c"
	.text
	.globl	main                            # -- Begin function main
	.p2align	4
	.type	main,@function
main:                                   # @main
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%rbx
	.cfi_def_cfa_offset 40
	pushq	%rax
	.cfi_def_cfa_offset 48
	.cfi_offset %rbx, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	xorl	%edi, %edi
	xorl	%esi, %esi
	callq	gtk_init_check@PLT
	testl	%eax, %eax
	je	.LBB0_1
# %bb.2:
	leaq	.L.str(%rip), %rdi
	leaq	.L.str.1(%rip), %rcx
	leaq	.L.str.2(%rip), %r9
	movl	$1, %ebx
	xorl	%esi, %esi
	movl	$1, %edx
	movl	$-6, %r8d
	xorl	%eax, %eax
	pushq	$0
	.cfi_adjust_cfa_offset 8
	pushq	$-3
	.cfi_adjust_cfa_offset 8
	callq	gtk_file_chooser_dialog_new@PLT
	addq	$16, %rsp
	.cfi_adjust_cfa_offset -16
	testq	%rax, %rax
	je	.LBB0_12
# %bb.3:
	movq	%rax, %r14
	movq	%rax, %rdi
	callq	gtk_file_chooser_get_action@PLT
	cmpl	$1, %eax
	jne	.LBB0_12
# %bb.4:
	leaq	.L.str.3(%rip), %rsi
	movq	%r14, %rdi
	callq	gtk_file_chooser_set_current_folder@PLT
	testl	%eax, %eax
	je	.LBB0_12
# %bb.5:
	leaq	.L.str.4(%rip), %rsi
	movq	%r14, %rdi
	callq	gtk_file_chooser_set_current_name@PLT
	movl	$-1, %ebp
	.p2align	4
.LBB0_6:                                # =>This Inner Loop Header: Depth=1
	xorl	%edi, %edi
	xorl	%esi, %esi
	callq	g_main_context_iteration@PLT
	movq	%r14, %rdi
	callq	gtk_file_chooser_get_filename@PLT
	testq	%rax, %rax
	jne	.LBB0_8
# %bb.7:                                #   in Loop: Header=BB0_6 Depth=1
	movl	$10000, %edi                    # imm = 0x2710
	callq	usleep@PLT
	incl	%ebp
	cmpl	$499, %ebp                      # imm = 0x1F3
	jb	.LBB0_6
	jmp	.LBB0_12
.LBB0_1:
	movl	$1, %ebx
.LBB0_12:
	movl	%ebx, %eax
	addq	$8, %rsp
	.cfi_def_cfa_offset 40
	popq	%rbx
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.LBB0_8:
	.cfi_def_cfa_offset 48
	leaq	.L.str.5(%rip), %rsi
	movq	%rax, %r15
	movq	%rax, %rdi
	callq	strcmp@PLT
	testl	%eax, %eax
	jne	.LBB0_12
# %bb.9:
	movq	%r15, %rdi
	callq	g_free@PLT
	movq	%r14, %rdi
	callq	gtk_widget_destroy@PLT
	leaq	.L.str.6(%rip), %rdi
	leaq	.L.str.1(%rip), %rcx
	leaq	.L.str.7(%rip), %r9
	xorl	%esi, %esi
	xorl	%edx, %edx
	movl	$-6, %r8d
	xorl	%eax, %eax
	pushq	$0
	.cfi_adjust_cfa_offset 8
	pushq	$-3
	.cfi_adjust_cfa_offset 8
	callq	gtk_file_chooser_dialog_new@PLT
	addq	$16, %rsp
	.cfi_adjust_cfa_offset -16
	testq	%rax, %rax
	je	.LBB0_12
# %bb.10:
	movq	%rax, %r14
	movq	%rax, %rdi
	callq	gtk_file_chooser_get_action@PLT
	testl	%eax, %eax
	jne	.LBB0_12
# %bb.11:
	movq	%r14, %rdi
	callq	gtk_widget_destroy@PLT
	leaq	.L.str.8(%rip), %rdi
	callq	puts@PLT
	xorl	%ebx, %ebx
	jmp	.LBB0_12
.Lfunc_end0:
	.size	main, .Lfunc_end0-main
	.cfi_endproc
                                        # -- End function
	.type	.L.str,@object                  # @.str
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str:
	.asciz	"Save File"
	.size	.L.str, 10

	.type	.L.str.1,@object                # @.str.1
.L.str.1:
	.asciz	"Cancel"
	.size	.L.str.1, 7

	.type	.L.str.2,@object                # @.str.2
.L.str.2:
	.asciz	"Save"
	.size	.L.str.2, 5

	.type	.L.str.3,@object                # @.str.3
.L.str.3:
	.asciz	"/tmp"
	.size	.L.str.3, 5

	.type	.L.str.4,@object                # @.str.4
.L.str.4:
	.asciz	"nonexistent-new-file.txt"
	.size	.L.str.4, 25

	.type	.L.str.5,@object                # @.str.5
.L.str.5:
	.asciz	"/tmp/nonexistent-new-file.txt"
	.size	.L.str.5, 30

	.type	.L.str.6,@object                # @.str.6
.L.str.6:
	.asciz	"Open File"
	.size	.L.str.6, 10

	.type	.L.str.7,@object                # @.str.7
.L.str.7:
	.asciz	"Open"
	.size	.L.str.7, 5

	.type	.L.str.8,@object                # @.str.8
.L.str.8:
	.asciz	"C-CONTROL GTK open/save actions and new filename passed"
	.size	.L.str.8, 56

	.ident	"Ubuntu clang version 21.1.8 (6ubuntu1)"
	.section	".note.GNU-stack","",@progbits
	.addrsig
