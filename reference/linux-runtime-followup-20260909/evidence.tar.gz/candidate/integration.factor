USING: accessors assocs compiler.errors debugger io kernel namespaces
parser prettyprint sequences system tools.test vocabs.hierarchy ;
f restartable-tests? set-global
auto-use? off
{
    "io.files" "io.backend.unix" "io.launcher.unix" "unix.ffi"
    "unix.process" "linux.input-events.ffi" "file-picker.linux" "ping"
} [
    dup "Testing " write print flush [ load ] [ test ] bi
    test-failures get empty? compiler-errors get assoc-empty? and [
        :test-failures compiler-errors get values [ print-error ] each
        1 exit
    ] unless
] each
"TEST FAILURES " write test-failures get length .
"COMPILER ERRORS " write compiler-errors get assoc-size .
0 exit
