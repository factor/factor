USING: accessors alien alien.c-types alien.strings alien.syntax arrays
assocs compiler.errors debugger destructors file-picker glib.ffi
gobject-introspection.standard-types gtk3.ffi io io.encodings.utf8
kernel locals namespaces prettyprint sequences system tools.test
ui.gadgets.worlds ;
IN: picker-repro
f restartable-tests? set-global
TUPLE: picker-parent window ;
SYMBOL: observed-action
: inspect-picker ( data -- continue? )
    drop [
        gtk_window_list_toplevels [ 0 g_list_nth_data ] [ g_list_free ] bi
        dup gtk_file_chooser_get_action observed-action set-global
        GTK_RESPONSE_CANCEL gtk_dialog_response
    ] with-destructors f ;
: cancel-callback ( -- cb )
    gboolean { gpointer } cdecl [ inspect-picker ] alien-callback ;
f f gtk_init_check [ "GTK init failed" throw ] unless
{ t } [
    cancel-callback [| cb |
        10 cb f g_timeout_add drop
        world new picker-parent new >>handle world [
            "/tmp/factor-save-nonexistent.txt" save-file-dialog drop
        ] with-variable
    ] with-callback
    observed-action get GTK_FILE_CHOOSER_ACTION_SAVE =
] unit-test
:test-failures
compiler-errors get values [ print-error ] each
compiler-errors get assoc-empty? test-failures get empty? and 0 1 ? exit
