	.file	"linux_ping.c"
	.text
	.globl	main                            # -- Begin function main
	.p2align	4
	.type	main,@function
main:                                   # @main
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r14
	.cfi_def_cfa_offset 24
	pushq	%rbx
	.cfi_def_cfa_offset 32
	subq	$48, %rsp
	.cfi_def_cfa_offset 80
	.cfi_offset %rbx, -32
	.cfi_offset %r14, -24
	.cfi_offset %rbp, -16
	movl	$1, %ebx
	movl	$2, %edi
	movl	$2, %esi
	movl	$1, %edx
	callq	socket@PLT
	testl	%eax, %eax
	js	.LBB0_1
# %bb.2:
	movl	%eax, %ebp
	movups	.L__const.main.timeout(%rip), %xmm0
	movaps	%xmm0, 32(%rsp)
	leaq	32(%rsp), %rcx
	movl	%eax, %edi
	movl	$1, %esi
	movl	$20, %edx
	movl	$16, %r8d
	callq	setsockopt@PLT
	testl	%eax, %eax
	jne	.LBB0_8
# %bb.3:
	movups	.L__const.main.peer(%rip), %xmm0
	movaps	%xmm0, 16(%rsp)
	leaq	20(%rsp), %rdx
	leaq	.L.str.1(%rip), %rsi
	movl	$2, %edi
	callq	inet_pton@PLT
	movl	$4294377480, %eax               # imm = 0xFFF70008
	movq	%rax, 8(%rsp)
	leaq	8(%rsp), %rsi
	leaq	16(%rsp), %r8
	movl	$8, %edx
	movl	%ebp, %edi
	xorl	%ecx, %ecx
	movl	$16, %r9d
	callq	sendto@PLT
	movl	$1, %ebx
	cmpq	$8, %rax
	jne	.LBB0_8
# %bb.4:
	leaq	8(%rsp), %rsi
	movl	$8, %edx
	movl	%ebp, %edi
	xorl	%ecx, %ecx
	callq	recv@PLT
	movq	%rax, %r14
	movl	%ebp, %edi
	callq	close@PLT
	cmpq	$8, %r14
	jne	.LBB0_8
# %bb.5:
	cmpb	$0, 8(%rsp)
	jne	.LBB0_8
# %bb.6:
	cmpb	$0, 9(%rsp)
	jne	.LBB0_8
# %bb.7:
	leaq	.L.str.2(%rip), %rdi
	callq	puts@PLT
	xorl	%ebx, %ebx
	jmp	.LBB0_8
.LBB0_1:
	leaq	.L.str(%rip), %rdi
	callq	perror@PLT
	movl	$1, %ebx
.LBB0_8:
	movl	%ebx, %eax
	addq	$48, %rsp
	.cfi_def_cfa_offset 32
	popq	%rbx
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end0:
	.size	main, .Lfunc_end0-main
	.cfi_endproc
                                        # -- End function
	.type	.L.str,@object                  # @.str
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str:
	.asciz	"ICMP datagram socket"
	.size	.L.str, 21

	.type	.L__const.main.timeout,@object  # @__const.main.timeout
	.section	.rodata.cst16,"aM",@progbits,16
	.p2align	3, 0x0
.L__const.main.timeout:
	.quad	1                               # 0x1
	.quad	0                               # 0x0
	.size	.L__const.main.timeout, 16

	.type	.L__const.main.peer,@object     # @__const.main.peer
	.p2align	2, 0x0
.L__const.main.peer:
	.short	2                               # 0x2
	.short	0                               # 0x0
	.zero	4
	.zero	8
	.size	.L__const.main.peer, 16

	.type	.L.str.1,@object                # @.str.1
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str.1:
	.asciz	"127.0.0.1"
	.size	.L.str.1, 10

	.type	.L.str.2,@object                # @.str.2
.L.str.2:
	.asciz	"C-CONTROL Linux ICMP datagram reply excludes the IP header"
	.size	.L.str.2, 59

	.ident	"Ubuntu clang version 21.1.8 (6ubuntu1)"
	.section	".note.GNU-stack","",@progbits
	.addrsig
