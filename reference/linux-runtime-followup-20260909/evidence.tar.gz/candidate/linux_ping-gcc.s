	.file	"linux_ping.c"
	.text
	.section	.rodata.str1.1,"aMS",@progbits,1
.LC0:
	.string	"ICMP datagram socket"
.LC2:
	.string	"127.0.0.1"
	.section	.rodata.str1.8,"aMS",@progbits,1
	.align 8
.LC3:
	.string	"C-CONTROL Linux ICMP datagram reply excludes the IP header"
	.section	.text.unlikely,"ax",@progbits
.LCOLDB4:
	.section	.text.startup,"ax",@progbits
.LHOTB4:
	.p2align 4
	.globl	main
	.type	main, @function
main:
.LFB46:
	.cfi_startproc
	endbr64
	pushq	%r14
	.cfi_def_cfa_offset 16
	.cfi_offset 14, -16
	movl	$2, %esi
	movl	$2, %edi
	pushq	%rbp
	.cfi_def_cfa_offset 24
	.cfi_offset 6, -24
	pushq	%rbx
	.cfi_def_cfa_offset 32
	.cfi_offset 3, -32
	subq	$64, %rsp
	.cfi_def_cfa_offset 96
	movq	%fs:40, %rdx
	movq	%rdx, 56(%rsp)
	movl	$1, %edx
	call	socket@PLT
	testl	%eax, %eax
	js	.L8
	leaq	16(%rsp), %rcx
	movl	$16, %r8d
	movl	%eax, %edi
	movl	%eax, %ebp
	movdqa	.LC1(%rip), %xmm0
	movl	$20, %edx
	movl	$1, %esi
	movaps	%xmm0, 16(%rsp)
	call	setsockopt@PLT
	movl	%eax, %ebx
	testl	%eax, %eax
	jne	.L3
	xorl	%eax, %eax
	leaq	32(%rsp), %r8
	leaq	36(%rsp), %rdx
	movl	$2, %edi
	leaq	.LC2(%rip), %rsi
	movq	%rax, 34(%rsp)
	movq	%r8, 8(%rsp)
	movq	%rax, 40(%rsp)
	movw	$2, 32(%rsp)
	call	inet_pton@PLT
	movq	8(%rsp), %r8
	xorl	%ecx, %ecx
	movl	%ebp, %edi
	leaq	48(%rsp), %rsi
	movl	$4294377480, %eax
	movl	$16, %r9d
	movl	$8, %edx
	movq	%rsi, 8(%rsp)
	movq	%rax, 48(%rsp)
	call	sendto@PLT
	movq	8(%rsp), %rsi
	cmpq	$8, %rax
	jne	.L3
	xorl	%ecx, %ecx
	movl	%ebp, %edi
	movl	$8, %edx
	call	recv@PLT
	movl	%ebp, %edi
	movq	%rax, %r14
	call	close@PLT
	cmpq	$8, %r14
	jne	.L3
	movzbl	48(%rsp), %eax
	orb	49(%rsp), %al
	jne	.L3
	leaq	.LC3(%rip), %rdi
	call	puts@PLT
.L1:
	movq	56(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L11
	addq	$64, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 32
	movl	%ebx, %eax
	popq	%rbx
	.cfi_def_cfa_offset 24
	popq	%rbp
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	ret
.L11:
	.cfi_restore_state
	call	__stack_chk_fail@PLT
	.cfi_endproc
	.section	.text.unlikely
	.cfi_startproc
	.type	main.cold, @function
main.cold:
.LFSB46:
.L8:
	.cfi_def_cfa_offset 96
	.cfi_offset 3, -32
	.cfi_offset 6, -24
	.cfi_offset 14, -16
	leaq	.LC0(%rip), %rdi
	call	perror@PLT
.L3:
	movl	$1, %ebx
	jmp	.L1
	.cfi_endproc
.LFE46:
	.section	.text.startup
	.size	main, .-main
	.section	.text.unlikely
	.size	main.cold, .-main.cold
.LCOLDE4:
	.section	.text.startup
.LHOTE4:
	.section	.rodata.cst16,"aM",@progbits,16
	.align 16
.LC1:
	.quad	1
	.quad	0
	.ident	"GCC: (Ubuntu 15.2.0-16ubuntu1) 15.2.0"
	.section	.note.GNU-stack,"",@progbits
	.section	.note.gnu.property,"a"
	.align 8
	.long	1f - 0f
	.long	4f - 1f
	.long	5
0:
	.string	"GNU"
1:
	.align 8
	.long	0xc0000002
	.long	3f - 2f
2:
	.long	0x3
3:
	.align 8
4:
