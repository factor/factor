from importlib.machinery import SourceFileLoader
import os,json,subprocess,hashlib
from pathlib import Path
m=SourceFileLoader('runs','/home/sheeple/factor-workspaces/run-linux-followup.py').load_module()
results=[]
for case,fixture in [('append','basis/io/files/unix/fixtures/append.factor'),('fifo','basis/io/files/unix/fixtures/fifo.factor'),('fifo-append','basis/io/files/unix/fixtures/fifo-append.factor'),('ping','extra/ping/ping-tests.factor'),('picker','extra/file-picker/linux/fixtures/dialog.factor')]:
 for version in (['gtk3','gtk2'] if case=='picker' else ['default']):
  for label,r in [('baseline',m.base),('candidate',m.candidate)]:
   image='gtk2.image' if version=='gtk2' else 'factor.image'
   env=dict(os.environ,TMPDIR=str(m.out/'tmp'),FACTOR_REPRO_TESTS=str(m.root/fixture),LD_LIBRARY_PATH='/home/sheeple/factor/logs/linux-issues/libraries')
   cmd=(["xvfb-run","-a"] if case=='picker' else [])+[str(r/'factor'),'-i='+str(r/image),'-resource-path='+str(r),'-no-user-init','-no-monitors',str(m.candidate/'.github/ffi-compare.factor')]
   status=m.run('final-'+case+'-'+version+'-'+label,cmd,r,env,15)
   results.append(dict(case=case,version=version,workspace=label,exit=status,command=cmd))
(m.out/'final-comparisons.json').write_text(json.dumps(results,indent=2)+'\n')
