from importlib.machinery import SourceFileLoader
from pathlib import Path
import os,json,tempfile,shutil
m=SourceFileLoader('runs','/home/sheeple/factor-workspaces/run-linux-followup.py').load_module()
results=[]
def run(name,cmd,cwd=m.candidate,env=None,expected=0,timeout=90):
 rc=m.run(name,cmd,cwd,env,timeout)
 results.append(dict(name=name,command=cmd,cwd=str(cwd),environment={k:v for k,v in (env or {}).items() if k in ['TMPDIR','LD_LIBRARY_PATH','CC','FACTOR_BUILD_SCRIPT','FACTOR_REPRO_TESTS','G_DEBUG']},exit=rc,expected=expected,passed=rc==expected))
 return rc
libs='/home/sheeple/factor/logs/linux-issues/libraries'
with tempfile.TemporaryDirectory(prefix='fio-',dir='/home/sheeple') as tmp:
 env=dict(os.environ,TMPDIR=tmp,LD_LIBRARY_PATH=libs,G_DEBUG='fatal-criticals')
 for lane,cc in [('gcc','gcc'),('clang','/usr/lib/llvm-21/bin/clang')]:
  for test in ['unix_file_flags','linux_ping','gtk_file_picker']:
   source=m.root/'vm/tests'/f'{test}.c'
   saved=m.out/'sources'/source.name;saved.parent.mkdir(exist_ok=True);shutil.copy2(source,saved)
   flags=[cc,'-O2','-fno-lto','-fno-fast-math',str(source)]
   run(f'final-{test}-{lane}-assembly',flags+['-S','-o',str(m.out/f'{test}-{lane}.s')])
   for version in (['gtk2','gtk3'] if test=='gtk_file_picker' else ['native']):
    binary=str(m.out/f'final-{test}-{lane}-{version}')
    ldflags=[]
    if version.startswith('gtk'):
     ldflags=['-L'+libs,'-Wl,-rpath-link,'+libs,'-l:'+('libgtk-x11-2.0.so.0' if version=='gtk2' else 'libgtk-3.so.0'),'-l:libglib-2.0.so.0']
    if run(f'final-{test}-{lane}-{version}-build',flags+ldflags+['-o',binary])==0:
     run(f'final-{test}-{lane}-{version}',(['xvfb-run','-a'] if version.startswith('gtk') else [])+[binary],env=env)
  for label,r,expected in [('baseline',m.base,1),('candidate',m.candidate,0)]:
   run(f'final-library-probe-{lane}-{label}',['python3',str(m.root/'vm/tests/library_probe.py')],env=dict(env,CC=cc,FACTOR_BUILD_SCRIPT=str(r/'build.sh')),expected=expected)
 for label,r,image in [('baseline',m.base,'factor.image'),('candidate',m.candidate,'final.image')]:
  for case,path,bad in [('append','basis/io/files/unix/fixtures/append.factor',1),('fifo','basis/io/files/unix/fixtures/fifo.factor',124),('fifo-append','basis/io/files/unix/fixtures/fifo-append.factor',1),('ping','extra/ping/ping-tests.factor',1)]:
   run(f'fresh-{case}-{label}',[str(r/'factor'),'-i='+str(r/image),'-resource-path='+str(r),'-no-user-init','-no-monitors',str(m.candidate/'.github/ffi-compare.factor')],cwd=r,env=dict(env,FACTOR_REPRO_TESTS=str(m.root/path)),expected=bad if label=='baseline' else 0,timeout=15)
 run('fresh-integration',[str(m.candidate/'factor'),'-i=final.image','-no-user-init','-no-monitors',str(m.out/'integration.factor')],env=env,timeout=180)
 for label,image in [('gtk3','final.image'),('gtk2','gtk2-r2.image')]:
  run('fresh-'+label,['xvfb-run','-a',str(m.candidate/'factor'),'-i='+image,'-no-user-init','-no-monitors','.github/gtk-tests.factor'],env=env,timeout=60)
(m.out/'final-validation.json').write_text(json.dumps(results,indent=2)+'\n')
raise SystemExit(not all(r['passed'] for r in results))
